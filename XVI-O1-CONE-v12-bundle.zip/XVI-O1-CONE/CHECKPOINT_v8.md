# CHECKPOINT v8 (started 16:39 UTC 2026-10-18)
Task: v8 = revision of v7 (read-only copy). (0) run v7 embedded python, verify bug claims, fixes in code/v8/; (1a-e) close open list; (2) write v8.
Constraints: never edit XVI-P/Q/R; nothing pushed/site; no independent review; missing != zero; partial labelled.
## step 0: v7 copied chmod 444; frozen hashes logs/frozen_v8_before.sha (identical to v6 after)

## Step 0a (v7 program run) 
- v7 read fully (1-3994). Listing extracted to code/v8/cone_v7.py (848 lines).
- selftest: rc=0, all PASS (heat moments, cyclotomic N=2..8 all j, Mellin rational reduction, catalogue algebra, ST row, ghost eq, six-structure rank 6). logs/v8/v7_selftest.json
- logs logs/v4 --legacy: rc=0, polynomial_comparison PASS for all 9 graphs x CR,F; absent_legacy_keys listed. logs/v8/v7_logs_legacy.json
- tree --engine (ro P5): N=1, A_GH=1/2, lambda_pred=-2i. logs/v8/v7_tree.json
- replay all graphs x CR/F/UNIT launched (setsid, code/v8/run_replay.sh, logs/v8/replay/driver.log)

## Step 0b (replay + bug claims) 
- replay all 9 graphs x CR/F/UNIT rc=0 (logs/v8/replay). `logs logs/v8/replay` (non-legacy, explicit coverage) PASS all 18.
- Physical-branch values: NO change vs logs/v4 on any key. Excluded (mixed) keys: D01 8 vector keys, D06 (1,1),(2,2), D13 4 keys -- v4 logs had NO partial values on them (absent), so claim 4 real in code but no printed value affected.
- UNIT: retaining mixed pairs adds values on those keys (D01 8, D06 2, D13 4). v6 UNIT statements to be checked.
- Mixed pairs are only coarse (1,2)/(2,1) [D01] and (0,1),(1,2) [D06,D13].
- Ward scan claim 10 REAL: x=(0.1,rr,0.2,0.05) has r>=0.2. code/v8/ward_scan_radial.py (true radius): geom residual ~1e-28..1e-32 (still zero), fried residual GROWS toward apex: 0.0039 (r=1) -> 0.101 (r=0.003) (historical saturated at ~0.019 because r never < 0.2).
- tree: N=1, A_GH=1/2, lambda_pred=-2i.
## Step 1e (exact certificate) 
- code/v8/apex_exact.py (mechanical Q(i) port, make_apex_exact.py), apex_exact_run.py: sampled exact reproduces all mod-p counts (18/8/6/2, Z 8, B 6, H0 2, gh1 26/8, H1 0).
- code/v8/apex_certificate.py: COMPLETE evaluation (all relevant unit atoms, 6x6 q grid): gh0 18/8/6/2, ST rank 26, Z=8, K(constant-profile coords)=12, Ward combos supported on K = 6 = rank of m=0 rows. (B part running.)

## Step 1e/1a addendum (B results)
- Certificates 3/10 CR and 3/10 F complete: gh0 18/8/6/2, ST rank 26, Z=8, B=6 subset Z, H0=2, |K|=12, K-supported Ward combos 6 (m0 rows span), rank pi_K B=5, dim Z cap ker pi_K = 2. Supports HH2/HH+CK4/CB+CK2 identical.
- hh_map fix: nsimplify->simplify (nsimplify produced spurious radical forms at 3/10). Reran 3/10 CR,F and 7071 CR.
- hh sum Ward values [0,0] at all three; D01/D03 cancel (3/10: D01 [91/5760,-91/2880]).
- hh-sum engine HH-K coords 3/10 CR (0,0,0,7/60,-7/240,-131/3840); F (...,63/1280); CR-F = -1/12 = nu/16 in last coordinate only.
- 7071 F certificate still running; run_slice2 D04,D06 done.

## Step 1c/1b addendum (17:15)
- Box was restored (VM fork) ~17:09: 7071 F cert died -> restarted (setsid, logs/v8/cert/run_7071_10000_F.log). run_slice2 had completed all six graphs.
- Hidden mixed pairs (logs/v8/slice/hidden_mixed.json): D01 13 keys (8 already quarantined; NEW: (4,4),(4,7),(5,5),(7,4),(7,7), pairs (0,2)/(2,0), rho ∝ P^2(6x^2-10x+3), (6x^2-2x-1)); D03 8 = excluded vector keys. None in D02,D04,D05a,D06,D11,D12,D13.
  -> v6 hh branch difference keeps its printed value but becomes CONDITIONAL on the D01 (0,2) mixed-channel contribution 2∫rho02 C02 dx.
- evanescent_combine rerun: CR 86, F 86, UNIT 113 coefficients; unchanged per-graph counts.
- Registry quick check: new_oct18f/ written: 257 ids, 6 new (Hawk05-ST, I-B-ECHO, I-B-G-S-B, I-C, I-C-Ex, X-J-ST-2), 0 changed, 0 removed.

## Step 1d addendum (six exact values)
- code/v8/exact_values.py -> logs/v8/cert/exact_values.json: rank(B|hhK)=4 at 3/10 CR,F and 7071 CR; consistent; e1=(1-alpha)/4 (7/40, 2929/40000), e3=0, e2+2e5 and e4+e5 fixed; e5,e6 free (PARTIAL). CR-F only in e4+e5: -1/6 = nu/8 at 3/10.
- Correction to my earlier note: HH Ward combos are 2b1+b3=0 and b2=0 in v7's b-normalisation (engine y = (-b1, -b3/2, -b2, ., ., -b8/4)); D01 3/10: b1=-91/5760, b2=91/2880.
- hh-sum b8 CR-F = 1/3 = -nu/4 at 3/10, consistent with eq:branchdifference.
- Next: build_v8.py.
- RE-correction (verified from hh_map code: 4b = M^T y): y = (-b1,-2b3,-b2,b6,b7,-b8/4); Ward combos b1+2b3=0, b2=0 (original note was right).

## Step 1e complete (17:35)
- 7071/10000 F certificate: N=38 (21/8/7/2), ST rank 29, Z=9, B=6 subset Z, H0=3, 29 Ward-constrained, K=12, K-supported 6 (same split 2/4/2), rank piK Z 6, piK B 5, dim Z cap ker piK 3. 561 s. Matches historical modular counts.
- Historical modular table: N=34 on CR generic and F alpha<1/2; F alpha>1/2 gives 38; alpha=1/2 (42), 2/3 (CR 35, F 39) resonant.
- hh_map 7071 F: Ward [0,0] on sum; D01/D03 cancel. exact_values 7071 F: e1=2929/40000, e3=0; CR-F in e4+e5 = 4142/56568 = nu/8 exactly.
- v8src fragments written: abstract, whatv8, response, sec_map, sec_mixed, sec_evan; code/build_v8.py written. Next: opentable, boundary, bibmarks, artifacts_v8.py, build, compile.

## Step 2 DONE (~17:55 UTC)
- v8src fragments + code/build_v8.py (v7 + asserted replacements) + code/artifacts_v8.py (102-file sha table, rerun commands, tree hashes, env).
- XVI-O1-CONE-v8.tex sha 153e4e9d...85f8 (4836 lines); PDF sha 04c04756...9747, 57 pages. pdflatex x2 rc=0, no undefined refs/cites; 5 overfull boxes, all in inherited v7 text (ledger table, pipeline eq).
- Status: overall NOT_CLOSED, bulk_symmetry_restored=false; CLOSED_PENDING_INDEPENDENT_REVIEW only for Theorem 14.1 (exact cert, 4 (alpha,branch) points, declared functionals).
- Frozen trees before==after (logs/frozen_v8_after.sha). v2/v3/v4/v6 SHA256SUMS verify; v7 unchanged (d0ba7b9c). SHA256SUMS_v8 written. Nothing pushed/posted; no review.
