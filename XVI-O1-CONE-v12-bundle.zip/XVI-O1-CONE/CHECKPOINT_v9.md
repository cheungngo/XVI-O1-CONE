# CHECKPOINT v9 (started 17:35 UTC 2026-10-18)
Task: v9 = revision of v8 (v8 tex/pdf chmod 444, hashes logs/v9/v8_hashes_before.sha). Code in code/v9/, logs logs/v9/.
Items: (1) hidden D01 mixed (0,2) terms; (2) r^2 mixed mode sum / D04; (3) CK/CB dictionary, e5,e6, closed forms e1,e4+e5;
(4) higher-jet Ward combos, 34-proj at several angles; (5) 18-dim map beyond 6; (6) evanescent vs frozen g~; (7) vector keys;
(8) generic-alpha rank cert over Q(alpha); (9) new sheets + registry check (new_oct18g if changed).
Constraints: never edit XVI-P/Q/R or v1-v8; nothing pushed/site; no independent review; missing != zero; partial labelled; resumable setsid jobs.
## step 0: frozen trees before = v8 values (logs/frozen_v9_before.sha)

## Step 1 (item 1, hidden mixed D01 terms) -- DONE structurally
- Closed form g(x;mu,nu) = G(h)G(h+1)/(4G(mu+1)G(nu+1)) 2F1(d/2+1,d/2;mu+1;x) 2F1(1-d/2,-d/2;nu+1;1-x) verified (logs/v9/g_formula_check.json); int_0^1 g = 1/(2(mu+nu)) exact.
- Hidden pairs enter keys (4,4),(4,7),(7,4),(7,7),(5,5) only as -(k^2P^2 J/8pi)[(h11-h22)(h11'-h22')+4h12h12'] = pure TT; vanishes identically on the v6 lattice (h11=h22, no h12) => v6 hh branch difference RESTORED (proof).
- IR log: same-k pairing gives a1+b1=1/15 => (alpha/15) sum 1/k log divergence; absolute TT values scheme-dependent; CR-F difference finite: DeltaJ = I_minus(1/a) - I_gen(1/a, 2-1/a).
- modefun.I_F is WRONG (x^{1-mu} vs x^{mu-1}); use I_gen only.
## Step 2 (item 3) -- DONE (with one-dimensional kernel)
- code/v9/cbck_map.py, ck_free.py, e_solve.py; logs/v9/cbck_map_*.json, ck_free_*.json, e_solve.json.
- CB dictionary exact (cb0 c0 opposite i-signs); y_CB = i(-R/8, 0); CK dictionary unique: K^00=-LL_tt, K^03=-2 si i LL_tz; y_CK = i((1-a)/16, R/8, 0)   [kappa^2/pi], R=3z0+4z1=(17a-7)(a-1)/(12a).
- Ghost normalisations lambda_CB=-4i, lambda_CK=-8 fitted (alpha-independent) -> all 6 K-Ward functionals vanish at all 4 certified points (3/10, 7071/10000; CR, F).
- e1=(1-a)/4 (now ALSO from CK coordinate 26, independent of HH), e3=0, e6-e2=-R/2, e5+e6/2=(a^2-1)/(48a), e4-e6/2 = (119a^2-120a+25)/(192a) CR, 7R/16 F.
- e5,e6 individually NOT fixable at constant profile: ker pi_K B = span(0,1,0,1/2,-1/2,1) exactly.
## Step 3 (item 1 numbers) -- DONE: logs/v9/hidden/dJ_*.json (14 angles, 25 digits; series==quad to 1e-31; DeltaJ(1/2)=0)
## Step 4 (item 8) -- chamber scan logs/v9/chamber_cache2.json: walls in (1/4,1) = {1/3,1/2,2/3} (structural keys, q<=40 exhaustive by integrality bound M<=12);
   modular scan logs/v9/scan/ (q<=20, both branches; two setsid drivers code/v9/scan_driver*.sh, resumable) RUNNING
## Step 5 (item 7) -- logs/v9/vector_logs.json: vector keys (1,6),(2,8),(6,1),(8,2) log-free; (1,1),(2,2) +c, (6,6),(8,8) -c, c=iP^2/(30pi); TT keys as predicted.
## Step 6 (item 6) -- logs/v9/evan_match.json: 164/285 keys have nonlinear Gt (deg<=3); 31/285 linear parts of partial-trace form; frozen dred.py admits only full trace -> obstruction.
## Step 7 (item 9) -- sheets read (extracts logs/v9/sheets_extract.txt); registry 258 ids, new: I-C-Ex2 -> new_oct18g/ written (SHA256SUMS).
## Step 8 -- v9 writing: v9src/{abstract,sec_v9,opentable,bib_v9}.tex, code/build_v9.py, code/artifacts_v9.py; test build 67 pp, refs ok. Final build waits for scan completion.
## Step 9 -- scan complete 192/192, no failures; final build
## Step 10 -- DONE: v9 compiled twice (67 pp, no undefined refs), SHA256SUMS_v9 written, frozen trees and v1-v8 unchanged
