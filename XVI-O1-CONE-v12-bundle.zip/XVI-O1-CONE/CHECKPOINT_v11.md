# CHECKPOINT v11 (started 2026-10-19 01:03 UTC)
## Step 0: frozen hashes logs/frozen_v11_before.sha; v9/v10 hashes logs/v10_hashes_before_v11.sha; v10 chmod 444.
## Step 1 (item 7): registry page byte-identical to new_oct18g/browse.html (same sha); no new_oct19 written.
## Step 1 (item 7) DONE: registry fetch 01:03 UTC differs from new_oct18g/browse.html only in 14 bytes of SSR timestamps; all 258 ids present, no new id tokens -> no new_oct19 written. sha in logs/v11/registry_oct19.sha
## Step 2 (item 1) running: FOUND v10 BUG: code/v10/t1_fp.py fixed Cauchy radius r=0.04 exceeds the t-convergence radius
 |t2|=2sqrt(x(1-x))/|1-2x| near endpoints -> v10 phi values (e.g. phi(3/2)=2.327852...) wrong; corrected phi(3/2)=2.32745055013616983 (dps40 tanh-sinh, GL agrees).
 v10 t1_fp_check points (x=0.3..0.8) unaffected. code/v11/t1v11.py (adaptive radius), m10_eval.py (cache logs/v11/M10/cache),
 m10_jobs.py (P0 same-k; P1 unit-shift intertwined pairing; alphas 3/10,7071/10000,1/2,1), m10_driver.sh setsid xargs -P7 (464 jobs).
## Step 3 (item 4) DONE: code/v11/degree_check.py (sympy, symbolic t=1/alpha, all h,c,b unit atoms DM=6, 8 chambers):
 max degree K2c 1, E(-q)h 2, C2T b 1 (0 in CR_c1/F_c1 at DM=4) -> bound (D) holds; logs/v11/degree_check.json.
 code/v11/degree_crosscheck.py: symbolic outputs at t=1/alpha0 == exact numeric engine, cumulative 3744 coefficients, 0 mismatch.
 Argument: basis = pivot selection of candidates (alpha-free); eval_cand multilinear, q-polynomial only.
## Step 4 (item 5) PARTIAL: code/v11/fmode_reduce.py: exact reduction for nu=2-mu: g = W(W1-W)/(4 W1 x(1-x) w), W incomplete Beta B_x(mu,2-mu);
 A=int(3-2x)W/w = (1/mu) sum (n+1)! K_n/(mu+1)_n = -I_CR/(mu-1) (same K_n as v10) => I_F = I_CR + (mu-1) B/W1, Delta J = -(mu-1) B/W1,
 B = int_0^1 (3-2x) W^2/w dx, W1=Gamma(mu)Gamma(2-mu). Numerically exact (<=1e-31 at 7/4,5/4,3/2). Closed form of B not derived.
## Step 5 (item 1) M10: first driver run superseded (diag test showed loss ~1.3 digits/unit h: mu=nu=7 err 2.6e-10). Fix: Cauchy radius
 r=min(0.25,|t2|/4,1/(1+h)) (test mu=nu=60: 1e-24). Old cache -> logs/v11/M10/cache_superseded/. Relaunched setsid code/v11/m10_driver.sh.
 code/v11/m10_sum.py written (P0/P1 x pos/neg x R_k/R_h; QR fit orders 10-13; Hurwitz tail). alpha=1 P1 check (exact diag data):
 R_k -> -19/180 (=-0.1055...56, err 1.9e-15), R_h -> 11/180 = D^Z_0(1) (err 2.3e-15). Regulator choice matters (difference 1/6).
## Step 6 (item 5) DONE: code/v11/fmode_derive.py -> logs/v11/fmode_derive.json. I_F DERIVED (0<mu<2): I_F = I_CR + (mu-1)B/W1,
 B = -2 W1 E + (1+mu) C, C/W1 = (mu-2)(5mu-3)/3 + (mu-1)^2[psi1(mu-1) - pi^2/6] (via a_n sums = v10 G_b and two rational sums);
 sympy: I_F - v10 PSLQ form = 0 exactly; C/W1 vs quadrature <=1.2e-30 at 7/4, 4/3, 10/7.
## Step 7 (item 1) second run superseded too: for large h, x->1 nodes lost all digits at dps 30 (e.g. F(77/3,70/3) printed -6.96e11).
 Fix 3 in m10_eval.py: x>1/2 via symmetry T1(x;mu,nu)=T1(1-x;nu,mu) (checked 25 digits), workdps 30+1.5*decades+5 near endpoints,
 K=56 (K=56 vs 110: 1e-28). Old cache -> logs/v11/M10/cache_superseded2/. Jobs deduped (unordered pairs, no diagonals): jobs_dedup.txt (404).
 Relaunched. F(77/3,70/3)=4916.1078182944833688 (10 s).
 Drafts written: v11src/{abstract,sec_v11,opentable,bib_v11}.tex, code/build_v11.py, code/artifacts_v11.py; trial compile OK (81 pp).
## Step 8: maxdegree=4 in m10_eval quad (degree 3/4/5 agree to 3e-23 rel at (97/3,100/3)); entries done before keep default degree. Relaunched (resume from cache).
## Step 9 (resume after interruption 01:53): third run had 125/368 entries outside endpoint bounds for h>~60 (endpoint aliasing,
 deterministic across dps). Fix 4: r=min(0.25,|t2|/4,1/(1+h),|t2|/(1+h)) (K=56 vs K=80 & half radius agree to 15 digits; endpoint
 limits reproduced). Cache -> logs/v11/M10/cache_superseded3/. Relaunched full 404 jobs (~30 s for h~130). F(61,60)=73804.958126737886508.
## Step 10 (item 1) DONE (partial-status): 404/404 F values (fix 4), m10_sum.py -> logs/v11/M10/m10.json, m10_pslq.json; m10_post.py ->
 m10_text.tex, m10_leading.json (c0=alpha^-3/3 to 1.7e-15), m10_sanity.json (403/404 within endpoint bounds; exception F(1,0), both ends 0).
 Checks: alpha=1 P1 -19/180 (R_k), 11/180 (R_h); alpha=1/2 P0=P1 under R_h to 5.1e-12; P0 pole = -alpha/40 (9.7e-12). Precision ~1e-7..1e-9 abs.
 PSLQ: only basis degeneracies or non-credible relations. D04 stays PARTIAL (pairing/regulator declared).
## Step 11: final append before hashing: run artifacts_v11.py, build_v11.py, pdflatex until stable; SHA256SUMS_v11. No append after this line.
