# CHECKPOINT v4 (started 14:14 UTC)
- tree hashes before: see logs/frozen_v4_before.sha
- step0: registry recheck running in /tmp/oct18d_check (fetch of 249 ids); will compare to new_oct18c.
- sources (read-only /tmp/o1cone_ro): D06 = "D06_cc_ghost_two_point" (cbar c two-point, two V_cb_c_h; graviton+ghost lines) -> v2/v3 described D06 as "D01+D03 channel": ERROR to correct in v4.
- D05a normalisation: XVI-Q Q02 bulk_graphs symmetry factor D05a = 1/2 (and D12 = 1/2); AR rule pattern for one-propagator tadpole S_f*loop*(i k^2)*i^phase*i -> -kappa^2/2: v3 analogy prefactor CONFIRMED from sources.
- item(1) plan: spectral apex reduction: apex part of Tr_perp f(-Lap_b) = C_b f(0), C_b=(1/12)(1/a-a)-b(1-b)/(2a) (cone heat-trace constant, t-independent by scale invariance). For constant-profile (n=0,m=0) externals and intertwining (H_I): apex pole = sum_S C_S * UVpole of (d-2)-dim longitudinal integral of flat integrand at k_perp=0. Calibrate/test on D05a, D02 vs tadpole2 (coincidence route).
- item(1): code/spectral_apex.py VALIDATED: D05a CR,F reproduce coincidence-route (v3 tadpole2) EXACTLY with no fitted constant; D02 CR,F: all 24 constant-profile (a0,b0,c0,f0) coefficients agree exactly with v3 tad2fast; D12 constant-profile = 0 both.
- item(1): D04 (constant profile, CR=F): Gamma_pole = kappa^2 (a^2-1)(p0^2-p3^2)/(48 pi a); phi-phi total D04+D05a: CR (-23a^2+12a-1)/(48 pi a) kappa^2 p_par^2 ; F kappa^2 (a-1)(13-23a)/(48 pi a); equal at a=1/2; F->0 at a=1; CR -> -kappa^2/(4pi) at a=1. D11 const-profile computed (C_0 only, CR=F).
- launched D03, D06, D13, D01 spectral (CR,F).
- step0: registry recheck: browse option ids = same 249 set; all 249 re-fetched, sha256 identical to new_oct18c -> 0 new, 0 changed; new_oct18d/ NOT created (per instruction). Scratch in /tmp/oct18d_check.
- step0 CORRECTION: browse <option> ids = 251: 2 NEW sheets I-B-VP-5-Ex1-B (sha 24b8ddd8...), I-B-VP-5-Ex2-B (sha db580cd7...); 249 old unchanged. Saved to /workspace/XVI-R-companion-intake/new_oct18d/ (all/, SHA256SUMS, index.json, browse.html). Content: Ex1-B scalar smooth-core finite parts non-universal (finite constants profile-dependent, even at equal minimal radius); Ex2-B smooth flux cores select Friedrichs for (twisted) scalars, Dirac critical-window selection. Use: cited caution only (finite parts non-universal; smooth-core limit selects F for decoupled twisted scalars; spin-2 CR not addressed -> CR stays input).
- item(1): D03 (CR=F) const-profile done; D06 (CR=F): Gamma_{cb c} = i k^2 (a-1)(17a-7)/(96 pi a) delta p_par^2; D13 (CR=F) done. Ghost-equation (antighost) row D06 = -2 eta F.D13 holds EXACTLY for all alpha (both branches). Mixed-helicity terms cancel for all lattice (S=0) externals; nonzero only on non-lattice constant S=+-1 externals (excluded).

## 14:40 D01 done (CR,F; CR != F on f0 keys, e.g. (4,4) CR k^2(q0^2-q3^2)(a^2+6a-1)/(96 pi a)). hh ST-row test
- st_test_const.py: no alpha-independent lam on CR/F (residuals prop. (alpha-1), identical CR/F).
- CONTROL: branch UNIT (all C_S=1 = k_perp=0 reduction of flat integrand; pointwise Ward identities) run for D01,D02,D03,D06,D11,D12,D13 (logs/v4/spec_*_UNIT.json).
  UNIT: B_hh(K2c,h)=0 identically (hh lattice pole transverse) but G_Kc(Eh,c)!=0 -> only lam=0 fits; i.e. my row implementation FAILS ITS OWN CONTROL
  in all 72 conventions scanned (code/st_scan.py, logs/v4/st_scan.json). => test NOT validated; no H_reg conclusion. Diagnostic: CR/F non-transverse hh part prop. (alpha-1), branch independent => comes from C_1-C_0 = -b(1-b)/(2a) (b=alpha both branches), C_2 parts transverse on lattice.
- Next: write v4 tex.

## 14:50 DONE. v4 written+compiled (8 pp). tex 0d9fef7c...053ea, pdf 17a4fdd4...c965 (SHA256SUMS_v4). Frozen hashes after == before (Q 0df9a0d1, P ec965c15, R 57187bc6). v1-v3 unchanged. Nothing pushed/site.

## 14:41+ appendix fix: analogy appendix rewritten with the user's actual six statements (record-recovery bound; Shannon record entropy/Page; heat ledger; exterior-record insufficiency; endpoint indeterminacy; classical persistence) and per-item assessment. Cone verdict kept. Physics untouched. Recompiled (8 pp).
tex f79bf4d6186582c7f63a43e65d9bde099de5453d7e747b16dd414d6ca5584b7e ; pdf 53a3c5a68425de271d6b145bf71713fec40d3aaac112267ffb8b914c129e8352 (SHA256SUMS_v4 updated). Frozen hashes unchanged.
