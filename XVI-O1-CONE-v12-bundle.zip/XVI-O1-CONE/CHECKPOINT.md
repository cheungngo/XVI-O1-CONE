# XVI-O1-CONE checkpoint

- 11:04Z task start: scoped O.1 on the cone, stage 1. Read-only on XVI-Q/XVI-P/XVI-R.
- Sources: spin-2 authority = site I-B-G-S-v2 (new_oct18b/I-B-G-S.tex): def:geo, thm:selection, thm:closed (labels b_sigma, flip eq.), thm:transfer, prop:obstruction.
  Kernels copied (not modified) from /workspace/I-B-G-S/code/{kernel,tensor}.py into code/ (path line edited only).
- O.1 scope to transport (XVI-Q certificates/Q03_O1_record.json): one-loop kappa^2 bulk two-point retained sector of S_inv,
  m=0, frozen gauge fermion, XVI-P DRED + MS-bar + p22 evanescent CTs; domain 11 p14r + 10 p22 (Q02_bulk_identity.json coefficients).
- Plan: (1) locality thm: W_b = W_flat + R_b, R_b real-analytic near diagonal (S_b odd in u) -> poles on M_reg^2 = flat;
  numerics: smoothness of R_b, log-coefficients of G^2 and d2G d2G shell moments = flat. (2) apex jet algebra:
  channels (sigma,n), exponents e=+-nu+2j, U(1) charge n, O(2)_par; inventory per sector & alpha-interval, both branches;
  sigma0 rows c.h / c.b, exact Xi, H^0, H^1 (anomaly). Note E=1 row nonzero on cone -> kappa^1 apex one-point CTs.
  (3) Ward numerics (regular region + boundary flux at r=eps). (4) a1 conical per label: a(b)=B2(b)/(2alpha)-alpha/12 check vs Dowker/Kabat/FM.
- 11:20Z XVI-Q copied to /tmp/o1cone_ro (read-only source); tools/build.py running in copy (log logs/xviq_build_copy.log)
- 11:30 apex_run fixed (DM caps for gh1 samples; odd-swap signs in X1/X2; polarization 1/2 in HH image). 7071/10000 CR p0: Z=8, B=6 ⊂ Z, H0=2 (=PP only, gravity H0=0), gh1 Z=26=exact, images WZ-closed, H1=0. Batch launched: logs/apex_batch.log
- 11:31 XVI-Q copy build (/tmp/o1cone_ro): all engine stages rc=0 incl. certificates_q02/q03/q04, gates accepted 'CLOSED (scoped)'; tests stage 16 failed in copy (Q05/Q06 fixtures FileNotFound Q06_ghost_rows.json, path/order artefact of copy). Regenerated Q02_bulk_identity, Q03_O1_record, Q02_O1 byte-identical to frozen; Q02_bulk_graphs differs only in 'seconds'. Copied to xviq_regen/. Frozen tree hashes logs/frozen_tree_*.sha
- 11:36 apex batch (8 alphas x CR/F x 2 primes) summary logs/apex_summary.txt. CR: H0=2 (phi only), H1=0 all alphas; F, alpha>1/2: foreign atoms (s leaves domain), truncated H1=2 diagnostic. Ward radial scan logs/wardscan_*: CR <=1e-31 down to r=0.01; F residual O(1e-2), nonvanishing. heatcoef.py: vec=Kabat, CR=FM exactly all alpha; F-FM = -2(2-1/alpha) for alpha>1/2. Lit verified: IM hep-th/9703088, LW hep-th/9506066 NPB458, Dowker JPA10(1977)115.
- 11:38 XVI-O1-CONE.tex written, compiled (pdflatex x2, rc=0, 7 pages)
