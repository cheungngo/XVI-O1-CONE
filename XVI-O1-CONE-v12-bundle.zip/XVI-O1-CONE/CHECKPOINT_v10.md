# CHECKPOINT v10 (started 2026-10-18 18:53 UTC)
Task: v10 = revision of v9 (read-only, chmod 444). Items (1) transverse-jet extension, (2) consequences, (3) lambda derivation,
(4) PSLQ DeltaJ, (5) minor polynomial / 9th cocycle, (6) vector finite parts, (7) registry.
## Step 0 -- frozen hashes logs/frozen_v10_before.sha (= v8/v9 values); v9 hashes logs/v9_hashes_before_v10.sha; dirs code/v10 logs/v10 v10src.
## Step 1 (item 7 registry) -- 258 ids, none new/gone vs new_oct18g -> no new_oct18h written.
## Step 2 (item 4) -- DONE. code/v10/cr_mode_closed.py: I_CR(mu)=(mu-1)(6mu^2+3mu-2)/6-(mu-1)^3(mu+1)psi1(mu-1) DERIVED (34-digit checks).
   code/v10/f_mode_pslq.py + PSLQ: I_F(mu)=(mu-1)(59mu^3-57mu^2-62mu+48)/36-(mu-1)^3(mu+1)pi^2/6 (fit 7 pts, check 2) ;
   code/v10/dJ_closed_verify.py: 9 fresh angles (incl. sqrt2, golden, pi/2, alpha=2/5,10/29) agree to <=1.5e-52; v9 table to 4e-27.
## Step 3 (item 5) -- code/v10/minor_poly.py, minor_driver.sh (finished), minor_entries.py. CR_c4: 3 minors, entries alpha-independent.

## Step 4 (item 5, F above 1/2) DONE
cocycle9.py: F_c3 (8 angles in (1/2,2/3)) and F_c4 (8 angles in (2/3,1)): dimZ=9 at every angle, entries degree <=1 in 1/alpha,
common Z over the 8 angles = 8-dim. => 8 cocycles are alpha-constant vectors; the 9th exists at every alpha (rank=29 everywhere:
<=29 by semicontinuity of generic rank, >=29 by the constant nonzero minor 2) but its direction moves with alpha (rational in alpha by Cramer).
Logs: logs/v10/minor/F_c{3,4}/cocycle9.json, cocycle9_F_c{3,4}.log.

## Step 5 (item 3) DONE
code/v10/lambda_derive.py -> logs/v10/lambda_derive.json: tree operator ratios rho=-i (K2c vs delta_c h), eps=1 (E vs coordinate E^{mn}),
tau=-i/2 (C2T b vs -2 eta F_L^T b), each single-valued over 9 momenta x all atoms. lambda_CK = 4 rho lambda_pred/eps = -8,
lambda_CB = -tau lambda_CK = -4i. Both equal v9 fitted values. (Signs s_i,s_c,s_cb of the dictionaries are the v9 ones.)

## Step 6 (item 1) running
code/v10/jet_replay.py (+ jet_driver.sh, setsid, resumable per graph) -> logs/v10/jet/jet_<G>.json: exact slice poles with p1,p2 kept.
code/v10/r2_scheme.py -> logs/v10/jet/r2_scheme.json: scheme Z (radial Mellin w + Hurwitz zeta): per mode s mu(mu^2-1)/3;
 D^Z_b = D_b + 11 alpha/180 exactly (scheme difference = bulk term, linear in alpha); flip reproduces Prop Dflip; d_s vanish at alpha=1; CR=F at 1/2.
D04: order-0 reproduces v8; the p_perp^2 term sits ONLY in mixed pair (1,0) with coefficient kappa^2/(4 pi); UNIT sum is -kappa^2 P^2/(4pi) (covariance check).
code/v10/mixed_r2.py running (per-mode mixed r^2 trace, scheme Z, numeric).
- jet_replay ALLDONE (9 graphs). jet_analyse: order-0 reproduces v8 on all computed keys (684 key-branch checks, 0 mismatches);
  same-channel p+p- dressed with d_s (scheme A) vanish at alpha=1 (F) and CR=F at 1/2; census in logs/v10/jet/jet_analysis.json.
- t1_fp.py: closed finite part of mixed r^2 trace (Bailey + Euler operator + t=(1-lam)^{1/2} expansion), agrees with independent
  shell continuation to 1e-19..1e-24; endpoints T1(0)=mu(mu^2-1)/3, T1(1)=nu(nu^2-1)/3.
- D04 density for pair (1,0) p_perp^2 is constant kappa^2/(4pi). phi(n)=int T1(x;n+1,n)dx running: code/v10/phi_driver.sh (resumable cache logs/v10/jet/phi/).

## Step 7 (item 6) DONE (declared scheme)
code/v10/vector_fp.py + vector_driver.sh + vector_combine.py -> logs/v10/vector_fp/{3_10,41_100,3_5,7071_10000,combined}.json.
k-zeta (|k|^-eps) on same-k mode sums, per-mode scheme Z. Pole residues = v9 log prediction to <=1e-20 at all 4 angles.
FP (D01+D03): (1,1),(2,2): +c kappa^2 P_L^2 ; (6,6),(8,8): -c kappa^2 P_L^2 ; (1,6),(2,8),(6,1),(8,2): 0 (D01 and D03 cancel digit for digit).
c(3/10)=0.0206627201453, c(41/100)=0.0204800603712, c(3/5)=0.0203890448352, c(7071/10000)=0.020476362628; pole = -(alpha/(60 pi)) kappa^2 P_L^2 /eps.
Branch independent (channels 0,1 only).
## Step 8 running: phi grid (phi_driver2.sh) for D04 mixed candidate sum.

## Step 8 stopped: phi large-n runs killed for time (27 cached values); M10 not evaluated (PARTIAL).
## Step 9 DONE: v10src/*, code/build_v10.py, code/artifacts_v10.py; XVI-O1-CONE-v10.tex/.pdf built (pdflatex x3, no undefined refs);
SHA256SUMS_v10 written; frozen trees and v1-v9 unchanged.
