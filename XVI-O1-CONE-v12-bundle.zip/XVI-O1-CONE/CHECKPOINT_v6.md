# CHECKPOINT v6 (started 15:06 UTC 2026-10-18)
Task: v6 = expanded revision of v5 (copied read-only to XVI-O1-CONE-v5.tex). Items (a)-(g) + artifact appendix + analogy section.
Constraints: never edit XVI-P/Q/R; nothing pushed/site; no independent review; NOT_CLOSED unless earned; missing != zero.
## step 0: v5 copied (chmod 444); frozen hashes in logs/frozen_v6_before.sha
## 15:25 item (a) BREAKTHROUGH (pending validation)
- Read all of v5. Derived ST row conventions from XVI-P K-vertex closed form "K'_(mn) a (d_m c_n + d_n c_m)" summed over independent (mn):
  antifield term = sum_(mn) Gamma_{K'_(mn) c} * dS/dh_(mn), dS/dh_(03) = 2 E^{03} = -2 E_{03} (mostly minus) => K-coordinate weight w=-2 (v4 scan used only w>0).
- With w=-2: CR and F close with alpha-INDEPENDENT lam=-4i, residuals 0 on 8 random samples (exact in alpha). UNIT: both terms vanish identically (trivial closure).
- Next: independent validation of lam=-4i via FLAT 4D bulk poles (code/flat_pole.py), where O.1 is known closed.
## 15:45 item (a) VALIDATED
- code/st_norm.py: lam predicted from XVI-P tree data (A_GH=1/2, V2 h = 1*Eup on de Donder h) => lam_pred = N/(i a) = -2i.
- code/st_v6.py exact symbolic: CR and F: lam_fit = -2i (alpha-independent) == lam_pred; residuals 0; matter (D11+D12) transverse alone.
- UNIT and FLAT4D (code/flat_pole.py, logs/v6/flat_*.json): both terms vanish identically on lattice (trivial closure).
- v4 bug: K'_(03) weight must be -2 (independent-coordinate derivative x eta raising); v4 scanned only w in {1,2,1/2}.
## 16:00 item (c) computed
- code/hi_d01.py: S=2->3 composite trace X(K^- - K^+)X^dag, X=(d_r - nu/r), flipped channel: diagonal ~ c0 r^(-2nu-2) (checked to 1e-7), not integrable;
  unique Mellin/homogeneous extension (no resonance for 0<nu<1): s*R(0) = 0 to <2e-21 at alpha=0.6,0.7,0.75,0.8,0.9 (dps 60); s-independent (s=3 check).
  => (H_I,D01) holds in the H_reg (homogeneous-extension) sense; fails as an L^2 statement. Analytic proof of zero open.
## 16:25 items (b),(e), validation
- (b) code/weighted_apex.py: D_b = -11a/180 + B2(b)/(3a) - B4(b)/(6a^3) (r^2-weighted Abel apex coefficient, ApTr[r^2 e^{-sA}] = D_b s);
  checked exactly vs orbifold image sums a=1/2,1/3,1/4,1/5,1/7 (b=0) and twisted (N,j)=(3,1),(4,1),(5,2); flip shift 2nu(1-nu^2)/3; D(b=2a)=D_F(2a-1)+shift.
  D05a m=2 part: integrand p^2 * D/l^4 has no longitudinal UV log -> 0 pole (computed). D04 m=2 part: OPEN (mixed-channel x_i insertions).
- (e) code/hh_structures.py: 6 invariant structures; hh total CR/F: S1=S2=S3=0, b6,b7,b8 exact; gauge variance only via b6+b7 = -k^2(a-1)/(8 pi).
- flat route validated: code/flat_vs_p18.py -> flat D11 covariant ratios [6,1,-6,-1,8] == frozen P18_D11 (up, offdiag 2).
- registry: 251 ids, same set as oct18c+oct18d; content fetch running (/tmp/oct18e_check).
## 16:50 writing-phase verifications
- code/catalogue_check.py -> logs/v6/catalogue_check.json: ALL printed v5 catalogue entries (D01,D02,D03,D04,D05a,D06,D11,D12,D13; CR,F) match executed logs exactly;
  NEW entry not in v4/v5 table: D01(5,5)=D03(5,5)= -8 c1 P^2 * k^2/(16pi). D02 = (k^2/pi) W x pattern, W=(c0+2c1+c2)/2; D12 = 0 exactly.
  Mixed-helicity monomials dropped only on vector-type keys (one transverse index): D01 {11,16,22,28,61,66,82,88}, D06 {11,22}, D13 {11,22,61,82}. These keys are EXCLUDED (not zero).
- hh structure coefficients branch-uniform in c-form: totals S6=(3/4)(c0+c1), S7=-(1/2)c0-c1, S8=-(3/8)c0-2c1-(1/4)c2 (units k^2/pi); b6+b7=-V/4.
- code/weighted_checks.py: D_b vs log exact; D_0(1/N) = (1/4N) sum csc^4(pi k/N) for N=2..8 exact; D_CR(S=2)->0 at alpha->1 (no r^2 flat remnant).
- code/hi_d01_exact.py: CLOSED FORM Mellin R(0) = 0 symbolically in nu (gammasimp), via int x^{mu-1}e^{-x}K_m = sqrt(pi)G(mu+m)G(mu-m)/(2^mu G(mu+1/2)). (H_I,D01) upgraded: Mellin sense exact.
## 17:30 v6 written and compiled
- v6src/*.tex fragments + code/build_v6.py (v5 -> v6 with asserted replacements) + code/artifacts_v6.py (manifest appendix).
- v6build: pdflatex x2 (after aux settle), no undefined refs, 43 pages. Copied XVI-O1-CONE-v6.{tex,pdf} to top; SHA256SUMS_v6 written.
- frozen trees after == before (logs/frozen_v6_after.sha). v4 files unchanged. v5 copy read-only.
