"""Exact coincidence (Synge) data of the subtracted twisted cone kernel R_b = G_b - G_flat, from the Bernoulli
generating function  f_b(z) = (1/z) sum_n B_n(1-b) z^n/n!  (independent of the closed-form numerics in kernel.py).
R_b(x,x') = Phi_b(eta, eps) / (8 pi^2 r r'),  eps = developed angle difference theta'-theta,
cosh eta = (r^2 + r'^2 + s_t dt^2 + dz^2)/(2 r r'),  s_t=+1 Euclidean, s_t=-1 Lorentzian (time-ordered = continued G_E).
Returns A(x), B_i(x), C_ij(x) with R(x, x+d) = A + B.d + d.C.d + O(d^3), in coordinates (t, X, Y, z)."""
import sympy as sp
b, al = sp.symbols('b alpha', positive=True)
eta, eps, rho, ph = sp.symbols('eta epsilon rho phi')
def tail(bb, aa, order):
    t = 0
    for n in range(2, order + 3):
        Bn = sp.bernoulli(n, bb)
        t += Bn / (sp.factorial(n) * aa ** n) * ((-1) ** n * (eta - sp.I * eps) ** (n - 1) + (eta + sp.I * eps) ** (n - 1))
    return sp.expand(sp.expand(t / eta) * sp.series(eta / sp.sinh(eta), eta, 0, order + 1).removeO())
def Phi_series(order=2):
    """Phi_b = T(b,alpha) - T(0,1), T(b,alpha) = sum_{n>=2} B_n(b)/(n! alpha^n) [(-1)^n (eta-i eps)^{n-1} + (eta+i eps)^{n-1}]/sinh eta.
    Exact because the n=0 (Hadamard) term is alpha,b-independent in (eta,eps) and Phi_{b=0,alpha=1} = 0 identically;
    the n=1 term vanishes.  Truncated at total degree <= order in (eta, eps)."""
    tot = sp.expand(tail(b, al, order) - tail(0, 1, order))
    out = 0
    for term in sp.Add.make_args(tot):
        if sp.Poly(term, eta, eps).total_degree() <= order: out += term
    return sp.expand(out)
def synge(Phi, lorentz=True):
    t, X, Y, z, lam = sp.symbols('t X Y z lam')
    d = sp.symbols('d0:4')
    r = sp.sqrt(X ** 2 + Y ** 2); Xp = X + lam * d[1]; Yp = Y + lam * d[2]
    rp = sp.sqrt(Xp ** 2 + Yp ** 2)
    st = -1 if lorentz else 1
    w = ((r - rp) ** 2 + st * (lam * d[0]) ** 2 + (lam * d[3]) ** 2) / (2 * r * rp)   # cosh(eta) - 1
    eta2 = 2 * w - w ** 2 / 3
    ep = sp.atan((X * Yp - Y * Xp) / (X * Xp + Y * Yp))
    E2, EP = sp.symbols('E2 EP')
    # Phi is polynomial in eta (even) and eps: substitute eta^2 -> E2
    P2 = sp.expand(Phi).subs(eta ** 2, E2)
    assert not P2.has(eta), P2
    expr = P2.subs({E2: eta2, eps: ep}) / (8 * sp.pi ** 2 * r * rp)
    ser = sp.series(expr, lam, 0, 3).removeO()
    ser = sp.expand(ser)
    A = sp.simplify(ser.coeff(lam, 0)); B1 = ser.coeff(lam, 1); C2 = ser.coeff(lam, 2)
    Bv = [sp.simplify(sp.diff(B1, d[i])) for i in range(4)]
    Cm = [[sp.simplify(sp.diff(C2, d[i], d[j]) / (1 if i == j else 1) / 2) for j in range(4)] for i in range(4)]
    # C2 = sum_ij Cm_ij d_i d_j with Cm symmetric:  d^2/dd_i dd_j C2 = 2 Cm_ij
    return (t, X, Y, z), A, Bv, Cm
if __name__ == '__main__':
    import pickle, time
    T0 = time.time()
    Ph = Phi_series(2)
    print('Phi_b to order 2:', Ph, round(time.time() - T0, 1), flush=True)
    for lor in (True, False):
        co, A, Bv, Cm = synge(Ph, lor)
        print('lorentz', lor, 'A=', sp.simplify(A), flush=True)
        pickle.dump({'Phi': Ph, 'coords': co, 'A': A, 'B': Bv, 'C': Cm}, open('/workspace/XVI-O1-CONE/logs/v2_coinc_%s.pkl' % ('L' if lor else 'E'), 'wb'))
    print('done', round(time.time() - T0, 1))
