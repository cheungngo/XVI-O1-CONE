"""v8 item (c): combine slice-DRED evanescent pole coefficients with the branch weights (same-channel pairs only;
keys with a mixed-channel circle OR evanescent pole are quarantined, as in v7's replay rule)."""
import json, sys; sys.path.insert(0, '/workspace/XVI-O1-CONE/code/v8')
import sympy as sp
import cone_v7 as V7
G00, G03, G33 = sp.symbols('Gt00 Gt03 Gt33')
I = sp.I
loc = {'alpha': V7.alpha, 'kappa': V7.kappa, 'q0': V7.q0, 'q3': V7.q3, 'I': I, 'pi': sp.pi, 'Gt00': G00, 'Gt03': G03, 'Gt33': G33}
out = {}
for g in V7.GRAPHS:
    d = json.load(open(f'/workspace/XVI-O1-CONE/logs/v8/slice/slice_{g}.json'))
    pref = sp.sympify(d['pref'], locals=loc)
    for br in ('CR', 'F', 'UNIT'):
        cs = V7.physical_cs(br); vals = {}; quarantined = []
        for key, rec in d['keys'].items():
            mixed = [st for st, r in rec.items() if eval(st)[0] != eval(st)[1]] if False else \
                    [st for st in rec if (lambda t: t[0] != t[1])(tuple(int(c) for c in st.strip('()').split(',')))]
            if mixed and br != 'UNIT':
                if any(rec[st]['evanescent_pole'] != '0' or rec[st]['circle_pole'] != '0' for st in mixed):
                    quarantined.append(key); continue
            tot = 0
            for st, r in rec.items():
                s = int(st.strip('()').split(',')[0])
                ev = sp.sympify(r['evanescent_pole'], locals=loc)
                tot += ev if br == 'UNIT' else ev*cs[s]
            v = sp.factor(sp.expand(-I*pref*tot))
            if v != 0: vals[key] = str(v)
        out[f'{g}_{br}'] = {'evanescent_pole_coefficients': vals, 'quarantined_mixed_keys': quarantined}
    print(g, {br: len(out[f'{g}_{br}']['evanescent_pole_coefficients']) for br in ('CR', 'F', 'UNIT')}, 'quarantined', out[f'{g}_CR']['quarantined_mixed_keys'])
out['_status'] = 'slice-DRED prescription (ghat_L = eta_L - Gt, Gt formal, d_L=2 at pole level); ALGEBRAIC_SLICE_ONLY; R2-R5 NOT certified'
json.dump(out, open('/workspace/XVI-O1-CONE/logs/v8/slice/evanescent_combined.json', 'w'), indent=1)
