"""exact Q(i) rank (row elimination) shared by v8 analysis scripts."""
import sys; sys.path.insert(0, '/workspace/XVI-O1-CONE/code/v8')
from gq import GQ, inv
def rank(rows):
    R = []
    for r in rows:
        v = list(r)
        for (pc, prow) in R:
            f = v[pc]
            if f: v = [x - f * y for x, y in zip(v, prow)]
        nz = next((j for j, x in enumerate(v) if x), None)
        if nz is not None:
            iv = inv(v[nz]); R.append((nz, [x * iv for x in v]))
    return len(R)
def nullspace(A, ncols):
    M = [list(r) for r in A]; pivc = []; r = 0
    for c in range(ncols):
        pr = next((i for i in range(r, len(M)) if M[i][c]), None)
        if pr is None: continue
        M[r], M[pr] = M[pr], M[r]
        iv = inv(M[r][c]); M[r] = [x * iv for x in M[r]]
        for i in range(len(M)):
            if i != r and M[i][c]:
                f = M[i][c]; M[i] = [x - f * y for x, y in zip(M[i], M[r])]
        pivc.append(c); r += 1
        if r == len(M): break
    free = [c for c in range(ncols) if c not in pivc]; B = []
    for fc in free:
        x = [GQ(0)] * ncols; x[fc] = GQ(1)
        for i, pc in enumerate(pivc): x[pc] = -M[i][fc]
        B.append(x)
    return B
