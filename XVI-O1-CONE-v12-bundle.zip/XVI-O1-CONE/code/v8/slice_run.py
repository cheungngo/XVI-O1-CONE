"""v8 items (c) and (a)-vector-keys / (b)-mixed: per graph, key and channel pair:
circle pole (replay reference), slice-DRED pole with Gt (evanescent coefficients), and for bubbles the Feynman
density rho(x).  Physical-branch combination: same-channel pairs weighted by c_s; mixed pairs NOT combined (open).
v8.1: mixed pairs are recorded whenever their Feynman density is nonzero (hidden mixed pairs).
usage: python3 slice_run.py G"""
import sys, json, time; sys.path.insert(0, '/workspace/XVI-O1-CONE/code/v8')
import slice_engine as SE, sympy as sp
AR = SE.V7.load_engine('/tmp/o1cone_ro/XVI-P/code/p5_entry')
g = sys.argv[1]; T0 = time.time()
N, dens, pref, u, v, LS = SE.numerators(AR, g)
Gs = (SE.G00, SE.G03, SE.G33)
out = {'graph': g, 'status': 'ALGEBRAIC_SLICE_ONLY; slice-DRED evanescent prescription (Gt formal, longitudinal); R2-R5 NOT certified',
       'pref': str(pref), 'keys': {}}
for key, e in sorted(N.items()):
    pairs = SE.split_pairs(sp.expand(e), u, v, dens)
    rec = {}
    for st, cf in pairs.items():
        c = sp.factor(SE.circle_pole(cf, LS, dens))
        d = SE.dred_pole(cf, LS, dens)
        ev = sp.expand(d - d.subs({G: 0 for G in Gs}))
        r = {'circle_pole': str(c), 'dred_4d_part_matches_circle': bool(sp.simplify(d.subs({G: 0 for G in Gs}) - c) == 0),
             'evanescent_pole': str(sp.factor(ev)) if ev != 0 else '0'}
        rho = 0
        if dens != 'tadpole' and st[0] != st[1]:
            rho, x = SE.x_density(cf, LS)
            r['rho_x'] = str(sp.factor(rho))
            r['rho_integrates_to_circle'] = bool(sp.simplify(sp.integrate(rho, (x, 0, 1)) - c) == 0)
            r['hidden_mixed'] = bool(c == 0 and sp.expand(rho) != 0)
        if c != 0 or ev != 0 or rho != 0: rec[str(st)] = r
    if rec: out['keys'][str(key)] = rec
out['seconds'] = round(time.time() - T0, 1)
json.dump(out, open(f'/workspace/XVI-O1-CONE/logs/v8/slice/slice_{g}.json', 'w'), indent=1)
print(g, 'keys', len(out['keys']), out['seconds'])
