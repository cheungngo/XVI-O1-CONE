#!/bin/bash
cd /workspace/XVI-O1-CONE
ENG=/tmp/o1cone_ro/XVI-P/code/p5_entry
python3 code/v8/cone_v7.py tree --engine $ENG > logs/v8/v7_tree.json 2> logs/v8/v7_tree.err; echo "tree rc=$?"
for g in D04 D05a D11 D12 D02 D06 D13 D03 D01; do for b in CR F UNIT; do
  python3 code/v8/cone_v7.py replay $g $b --engine $ENG --out logs/v8/replay > logs/v8/replay/run_${g}_${b}.out 2> logs/v8/replay/run_${g}_${b}.err
  echo "$g $b rc=$?"
done; done
echo ALLDONE
