"""v8: genuinely radial Ward scan (fixes v7 claim 10).
Historical ward_scan.py used x=(0.1, rr, 0.2, 0.05): r=sqrt(rr^2+0.04) >= 0.2, so it never approached the apex.
Here x=(0.1, rr*cos th, rr*sin th, 0.05) with fixed th, so r = rr exactly. Same kernels/residual otherwise (read-only import of tensor.py)."""
import mpmath as mp, sys, json
mp.mp.dps = 30
sys.path.insert(0, '/workspace/XVI-O1-CONE/code')
from tensor import ten_kernel, vec_kernel, bgeom, bfried
al = mp.mpf(sys.argv[1]); mode = sys.argv[2]
br = {'geom': bgeom, 'fried': bfried}[mode]
xp = (mp.mpf("0.35"), mp.mpf("0.8"), mp.mpf("0.45"), mp.mpf("0.2"))
th = mp.atan2(mp.mpf("0.2"), mp.mpf("0.1"))
def dx(fun, i, pt): return mp.diff(lambda s: fun(tuple(pt[k]+(s if k == i else 0) for k in range(4))), 0)
half = mp.mpf(1)/2
out = {'alpha': str(al), 'mode': mode, 'theta': mp.nstr(th, 12), 'note': 'r is the true radius of x', 'scan': []}
for rr in ["1.0", "0.3", "0.1", "0.03", "0.01", "0.003"]:
    r = mp.mpf(rr)
    x = (mp.mpf("0.1"), r*mp.cos(th), r*mp.sin(th), mp.mpf("0.05"))
    def hbar(y, mu, nu, rho, sg):
        W = ten_kernel(al, y, xp, br); val = W[((mu, nu), (rho, sg))]
        if mu == nu: val -= half*sum(W[((l, l), (rho, sg))] for l in range(4))
        return val
    row = {'r': rr, 'r_true': mp.nstr(mp.sqrt(x[1]**2+x[2]**2), 8)}
    for (nu, rho, sg) in [(1, 1, 1), (2, 2, 2), (1, 1, 2)]:
        lhs = sum(dx(lambda y: hbar(y, mu, nu, rho, sg), mu, x) for mu in range(4))
        rhs = dx(lambda y: vec_kernel(al, x, y)[nu][sg], rho, xp)+dx(lambda y: vec_kernel(al, x, y)[nu][rho], sg, xp)
        row[str((nu, rho, sg))] = [mp.nstr(abs(lhs+rhs), 6), mp.nstr(abs(rhs), 6)]
    out['scan'].append(row); print(row, flush=True)
json.dump(out, open('/workspace/XVI-O1-CONE/logs/v8/ward/wardscan_radial_%s_%s.json' % (sys.argv[1], mode), 'w'), indent=1)
