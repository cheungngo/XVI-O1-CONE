#!/usr/bin/env python3
"""Scoped cone v7 checker.

Status:
  Source supplied for review; no execution is asserted by the paper.

selftest:
  Exact identities of the printed formulas, not a vertex rebuild.

logs:
  Compare explicit retained coordinates. New logs require coverage.
  --legacy permits polynomial comparison with uncertified zero coverage.

replay:
  Frozen-engine zero-transverse-momentum algebra only.
  Entire physical-branch keys with mixed poles are quarantined.
  UNIT retains all pairs. This is NOT an R2--R5 certificate.

tree:
  Check the declared tree normalization using a supplied engine.

manifest:
  Byte hashes with explicit path serialization. This is not the
  historical find/sort/xargs tree-hash algorithm.
"""
import argparse
import ast
import hashlib
import importlib
import json
import sys
import time
from pathlib import Path

import sympy as sp

I = sp.I
Q = sp.Rational
alpha = sp.Symbol("alpha", positive=True)
kappa, q0, q3 = sp.symbols("kappa q0 q3")
c0, c1, c2 = sp.symbols("c0 c1 c2")
P2 = q0**2 - q3**2
ETA = (1, -1, -1, -1)
HC = ((0, 0), (0, 1), (0, 2), (0, 3), (1, 1),
      (1, 2), (1, 3), (2, 2), (2, 3), (3, 3))
LAT = (0, 3, 9, 4, 7)
DIAGNOSTIC = (0, 3, 9, 4, 7, 5)
GRAPHS = ("D01", "D02", "D03", "D04", "D05a",
          "D06", "D11", "D12", "D13")


def zero(expr, label):
    v = sp.factor(sp.cancel(sp.expand(expr)))
    if v != 0:
        raise AssertionError(label + ": " + str(v))


def no_duplicate_pairs(pairs):
    out = {}
    for k, v in pairs:
        if k in out:
            raise ValueError("duplicate JSON key: " + str(k))
        out[k] = v
    return out


def read_json(path):
    with Path(path).open(encoding="utf-8") as f:
        return json.load(f, object_pairs_hook=no_duplicate_pairs)


def write_json(path, data):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, sort_keys=True)
        f.write("\n")


def key_parse(text):
    obj = ast.literal_eval(text)
    if not (isinstance(obj, tuple) and len(obj) == 2
            and all(type(x) is int and 0 <= x < 10 for x in obj)):
        raise ValueError("invalid component key: " + text)
    return obj


# Restricted expression parser: no eval, attributes, function calls,
# comprehensions, or implicit imports. Serialized logs are arithmetic.
NAMES = {"alpha": alpha, "kappa": kappa, "q0": q0, "q3": q3,
         "I": I, "pi": sp.pi}


def expression(text):
    if len(text) > 100000:
        raise ValueError("expression exceeds declared input bound")

    def walk(n):
        if isinstance(n, ast.Expression):
            return walk(n.body)
        if isinstance(n, ast.Constant) and type(n.value) is int:
            return sp.Integer(n.value)
        if isinstance(n, ast.Name) and n.id in NAMES:
            return NAMES[n.id]
        if isinstance(n, ast.UnaryOp):
            if isinstance(n.op, ast.UAdd):
                return walk(n.operand)
            if isinstance(n.op, ast.USub):
                return -walk(n.operand)
        if isinstance(n, ast.BinOp):
            a, b = walk(n.left), walk(n.right)
            if isinstance(n.op, ast.Add):
                return a + b
            if isinstance(n.op, ast.Sub):
                return a - b
            if isinstance(n.op, ast.Mult):
                return a * b
            if isinstance(n.op, ast.Div):
                return a / b
            if isinstance(n.op, ast.Pow):
                if not (b.is_Integer and abs(int(b)) <= 100):
                    raise ValueError("undeclared power")
                return a**b
        raise ValueError("unsupported symbolic syntax")

    return sp.expand(walk(ast.parse(text, mode="eval")))


def C(a, b):
    return (1/a - a)/12 - b*(1-b)/(2*a)


def D(a, b):
    B2 = b*b - b + Q(1, 6)
    B4 = b**4 - 2*b**3 + b*b - Q(1, 30)
    return -11*a/180 + B2/(3*a) - B4/(6*a**3)


def physical_cs(branch):
    a = alpha
    z0 = (1-a*a)/(12*a)
    z1 = (5*a*a-6*a+1)/(12*a)
    if branch == "CR":
        z2 = (23*a*a-12*a+1)/(12*a)
    elif branch == "F":
        z2 = (23*a*a-36*a+13)/(12*a)
    elif branch == "UNIT":
        return (sp.Integer(1),)*3
    else:
        raise ValueError("unknown branch")
    return z0, z1, z2


def put(out, key, val):
    val = sp.expand(val)
    if key in out:
        zero(out[key]-val, "inconsistent duplicate " + str(key))
    out[key] = val


def symmetric(d):
    out = {}
    for (a, b), v in d.items():
        put(out, (a, b), v)
        put(out, (b, a), v)
    return out


def tensor_images(d):
    # Exchange transverse coordinates 1 and 2, then transpose slots.
    exch = {1: 2, 2: 1, 4: 7, 7: 4, 6: 8, 8: 6}
    out = dict(d)
    for (a, b), v in d.items():
        put(out, (exch.get(a, a), exch.get(b, b)), v)
    return symmetric(out)


def catalogue(cs):
    z0, z1, z2 = cs
    A, B = z0+2*z1+4*z2, -z0+2*z1
    R, T, V = 3*z0+4*z1, 4*z0+3*z1, z1-z0
    W = (z0+2*z1+z2)/2
    k16 = kappa**2/(16*sp.pi)
    out = {}
    out["D04"] = {(0, 0): -kappa**2*z0*P2/(4*sp.pi)}
    out["D05a"] = {(0, 0): -kappa**2*(z2-z0)*P2/(4*sp.pi)}
    out["D11"] = symmetric({
        (4, 4): z0*P2*k16/2,
        (4, 7): z0*P2*k16/2,
        (7, 7): z0*P2*k16/2})
    d03 = {
        (0, 0): -z0*P2, (0, 9): -z0*P2, (9, 9): -z0*P2,
        (3, 3): 4*z0*P2,
        (0, 4): z0*(q0**2-3*q3**2),
        (3, 4): 4*z0*q0*q3,
        (4, 9): -z0*(3*q0**2-q3**2),
        (4, 4): -(z0+4*z1)*P2,
        (4, 7): -z0*P2, (5, 5): -8*z1*P2}
    d01 = {
        (0, 0): z0*P2, (0, 9): z0*P2, (9, 9): z0*P2,
        (3, 3): -4*z0*P2,
        (4, 4): (z0-4*z1+z2)*P2,
        (4, 7): (z0+z2)*P2,
        (3, 4): -4*(z0+2*z2)*q0*q3,
        (4, 9): A*q0**2-B*q3**2,
        (0, 4): -B*q0**2+A*q3**2,
        (5, 5): -8*z1*P2}
    out["D03"] = {k: v*k16 for k, v in tensor_images(d03).items()}
    out["D01"] = {k: v*k16 for k, v in tensor_images(d01).items()}
    d02 = {
        (1, 1): q3**2, (2, 2): q3**2, (5, 5): P2,
        (6, 6): q0**2, (8, 8): q0**2,
        (1, 6): -q0*q3, (2, 8): -q0*q3,
        (0, 4): -q3**2/2, (0, 7): -q3**2/2,
        (3, 4): q0*q3, (3, 7): q0*q3,
        (4, 7): -P2/2,
        (4, 9): -q0**2/2, (7, 9): -q0**2/2}
    out["D02"] = {k: kappa**2*W*v/sp.pi
                  for k, v in symmetric(d02).items()}
    out["D12"] = {}
    out["D06"] = {
        (0, 0): I*kappa**2*R*P2/(8*sp.pi),
        (3, 3): I*kappa**2*R*P2/(8*sp.pi)}
    out["D13"] = {
        (0, 0): -2*T*q0, (0, 3): 2*V*q3,
        (3, 0): -R*q3, (3, 3): R*q0,
        (9, 0): -2*V*q0, (9, 3): 2*T*q3}
    out["D13"] = {k: I*kappa**2*v/(16*sp.pi)
                  for k, v in out["D13"].items()}
    return out


def invariant_data():
    x = sp.symbols("x00 x03 x33 xf")
    y = sp.symbols("y00 y03 y33 yf")

    def tr(v):
        return v[0]-v[2]

    def php(v):
        return q0**2*v[0]-2*q0*q3*v[1]+q3**2*v[2]

    dot = x[0]*y[0]-2*x[1]*y[1]+x[2]*y[2]
    S = (P2*tr(x)*tr(y), P2*dot,
         php(x)*tr(y)+tr(x)*php(y),
         P2*(x[3]*tr(y)+tr(x)*y[3]),
         php(x)*y[3]+x[3]*php(y), P2*x[3]*y[3])
    idx = {0: 0, 3: 1, 9: 2, 4: 3, 7: 3}
    return x, y, S, idx


def structure_table(cs):
    a, b, c = cs
    W = (a+2*b+c)/2
    return {
        "D01": (-a/16, a/8, 0, -a/8-b/4-c/2,
                a/4+c/2, a/4-b/2+c/4),
        "D02": (0, 0, 0, W, -W, -W),
        "D03": (a/16, -a/8, 0, 3*a/8, -a/4, -a/4-b/2),
        "D11": (0, 0, 0, 0, 0, a/8),
        "D12": (0, 0, 0, 0, 0, 0)}


def bilinear(d, x, y, idx):
    return sp.expand(sum(v*x[idx[a]]*y[idx[b]]
                         for (a, b), v in d.items()
                         if a in idx and b in idx))


def einstein_coordinates(hv):
    p = (q0, 0, 0, q3)
    pu = tuple(ETA[i]*p[i] for i in range(4))
    h = sp.zeros(4)
    for a, (m, n) in enumerate(HC):
        h[m, n] = h[n, m] = hv.get(a, 0)
    tr = sum(ETA[i]*h[i, i] for i in range(4))
    ph = [sum(pu[r]*h[r, n] for r in range(4)) for n in range(4)]
    pph = sum(pu[n]*ph[n] for n in range(4))
    E = sp.Matrix(4, 4, lambda m, n:
        P2*h[m, n]-p[m]*ph[n]-p[n]*ph[m]+p[m]*p[n]*tr
        +(ETA[m] if m == n else 0)*(pph-P2*tr))
    for n in range(4):
        zero(sum(pu[m]*E[m, n] for m in range(4)), "E transverse")
    return {a: (2-int(m == n))*ETA[m]*ETA[n]*E[m, n]
            for a, (m, n) in enumerate(HC)}


def check_catalogue_algebra():
    cat = catalogue((c0, c1, c2))
    x, y, S, idx = invariant_data()
    table = structure_table((c0, c1, c2))
    for g, coeff in table.items():
        lhs = bilinear(cat[g], x, y, idx)
        rhs = kappa**2/sp.pi*sum(a*b for a, b in zip(coeff, S))
        zero(lhs-rhs, "structure " + g)

    variables = x+y+(q0, q3)
    polys = [sp.Poly(sp.expand(s), *variables) for s in S]
    mons = sorted(set(m for p in polys for m in p.monoms()))
    matrix = sp.Matrix([[p.coeff_monomial(m) for p in polys]
                        for m in mons])
    if matrix.rank() != 6:
        raise AssertionError("six-structure independence failed")

    h00, h03, h33, f = sp.symbols("h00 h03 h33 f")
    g0, g3 = sp.symbols("ghost0 ghost3")
    hv = {0: h00, 3: h03, 9: h33, 4: f, 7: f}
    dh = {0: 2*q0*g0, 3: -q0*g3+q3*g0,
          9: -2*q3*g3, 4: 0, 7: 0}
    E = einstein_coordinates(hv)
    bterm = 0
    for g in ("D01", "D02", "D03", "D11", "D12"):
        bterm += sum(v*dh.get(a, 0)*hv.get(b, 0)
                     for (a, b), v in cat[g].items())
    gterm = sum(v*E[a]*({0: g0, 3: g3}[n])
                for (a, n), v in cat["D13"].items())
    core = kappa**2*(c1-c0)*P2*f*(q0*g0+q3*g3)/sp.pi
    zero(bterm+core/2, "hh gauge variation")
    zero(gterm-I*core/4, "antifield contraction")
    lam = 1/(I*Q(1, 2))  # Declared tree input N=1, A_GH=1/2.
    zero(lam+2*I, "a-priori lambda arithmetic")
    zero(bterm+lam*gterm, "ST row")

    # Ghost equation, separately for each upper ghost column.
    for n in (0, 3):
        Y00 = cat["D13"].get((0, n), 0)
        Y03 = cat["D13"].get((3, n), 0)
        Y33 = cat["D13"].get((9, n), 0)
        F0 = q0*(Y00+Y33)/2-q3*Y03
        F3 = q0*Y03-q3*(Y00+Y33)/2
        zero(cat["D06"].get((0, n), 0)+2*F0, "ghost row 0")
        zero(cat["D06"].get((3, n), 0)-2*F3, "ghost row 3")

    # Endpoint and branch checks are polynomial checks only.
    for branch in ("CR", "F"):
        vals = catalogue(physical_cs(branch))
        if branch == "F":
            for d in vals.values():
                for v in d.values():
                    zero(v.subs(alpha, 1), "F flat catalogue")
    cr = catalogue(physical_cs("CR"))
    fr = catalogue(physical_cs("F"))
    for g in GRAPHS:
        for key in set(cr[g]) | set(fr[g]):
            zero((cr[g].get(key, 0)-fr[g].get(key, 0))
                 .subs(alpha, Q(1, 2)), "CR=F at half")
    bhcr = sum((bilinear(cr[g], x, y, idx)
                for g in table), sp.Integer(0))
    bhf = sum((bilinear(fr[g], x, y, idx)
               for g in table), sp.Integer(0))
    nu = 2-1/alpha
    zero(bhcr-bhf+nu*kappa**2*P2*x[3]*y[3]/(4*sp.pi),
         "complete branch difference")

    if len(cat["D02"]) != 23:
        raise AssertionError("D02 entry count")
    zero(sum(table[g][0] for g in table), "longitudinal S1")
    zero(sum(table[g][1] for g in table), "longitudinal S2")
    return {"catalogue_algebra": "PASS",
            "tree_normalization": "DECLARED_INPUT_NOT_REBUILT"}


def check_heat_and_mellin():
    u = sp.Symbol("u", positive=True)
    b = sp.Symbol("b")
    T = sp.cosh((Q(1, 2)-b)*u/alpha) / (
        2*sp.sinh(u)*sp.sinh(u/(2*alpha)))
    bulk = alpha/(2*(sp.cosh(u)-1))
    cser = sp.series(T-bulk, u, 0, 2).removeO()
    zero(sp.expand(cser).coeff(u, 0)-C(alpha, b), "C coefficient")

    weighted = -2*sp.diff(T, u)/sp.sinh(u)
    wbulk = alpha/(sp.cosh(u)-1)**2
    wser = sp.expand(sp.series(weighted-wbulk, u, 0, 2).removeO())
    for k in range(1, 5):
        zero(wser.coeff(u, -k), "weighted pole cancellation")
    zero(wser.coeff(u, 0)-D(alpha, b), "D coefficient")
    nu = 2-1/alpha
    zero(D(alpha, 2*alpha)-D(alpha, 2*alpha-1)
         -2*nu*(1-nu**2)/3, "weighted flip")
    zero(D(alpha, 2*alpha).subs(alpha, 1), "weighted CR flat")

    # Exact finite checks in Q[zeta_N], not numerical nsimplify.
    x = sp.Symbol("x")
    for N in range(2, 9):
        cyclo = sp.cyclotomic_poly(N, x)
        for j in range(N):
            acc = 0
            for k in range(1, N):
                inv = sp.invert((x**k-1)**4, cyclo, x)
                phase = x**(((j+2)*k) % N) + x**(((2-j)*k) % N)
                acc = sp.rem(acc+Q(2, N)*phase*inv, cyclo, x)
            target = D(Q(1, N), Q(j, N))
            zero(sp.rem(acc-target, cyclo, x), "cyclotomic moment")

    # Finite rational algebra underlying the closed Mellin proof.
    t, n = sp.symbols("t nu")
    ratio = (t*t-n*n)/(2*t+1)
    bracket = (t+1)*ratio+n*(n+t)
    zero(bracket-t*(t+n)*(t+n+1)/(2*t+1),
         "Mellin recurrence reduction")
    # Gamma reflection gives M'_z(0)=-(nu+1)/(2s).
    return {"heat_moments": "PASS",
            "finite_cyclotomic_checks": "PASS",
            "Mellin_rational_reduction": "PASS",
            "Mellin_integral_and_continuation":
                "ANALYTICAL_PROOF_IN_PAPER"}


def retained_keys(g):
    if g in ("D04", "D05a"):
        return [(0, 0)]
    if g == "D06":
        return [(a, b) for a in (0, 3) for b in (0, 3)]
    if g == "D13":
        return [(a, b) for a in LAT for b in (0, 3)]
    if g in ("D01", "D03"):
        return [(a, b) for a in DIAGNOSTIC for b in DIAGNOSTIC]
    return [(a, b) for a in range(10) for b in range(10)]


def compare_logs(root, legacy):
    root = Path(root)
    report = {}
    for branch in ("CR", "F"):
        expected = catalogue(physical_cs(branch))
        for g in GRAPHS:
            path = root/("spec_" + g + "_" + branch + ".json")
            data = read_json(path)  # Missing files are errors.
            if data.get("graph") != g or data.get("branch") != branch:
                raise ValueError("graph/branch metadata mismatch: " + str(path))
            got = {key_parse(k): expression(v)
                   for k, v in data[
                       "Gamma_pole_coeff_of_1/(4-d)"].items()}
            status = data.get("key_status", {})
            unverified = []
            for key in retained_keys(g):
                skey = str(key)
                if not legacy:
                    st = status.get(skey)
                    if st not in ("COMPUTED_ZERO_SLICE",
                                  "COMPUTED_NONZERO_SLICE"):
                        raise ValueError("missing/excluded coverage "
                                         + str(path) + " " + skey)
                    if st == "COMPUTED_NONZERO_SLICE" and key not in got:
                        raise ValueError("nonzero status without value")
                    if st == "COMPUTED_ZERO_SLICE" and key in got:
                        zero(got[key], "zero status with nonzero value")
                elif key not in got:
                    unverified.append(skey)
                zero(got.get(key, 0)-expected[g].get(key, 0),
                     "catalogue mismatch " + g + " " + skey)
            report[g+"_"+branch] = {
                "polynomial_comparison": "PASS",
                "coverage": ("LEGACY_UNCERTIFIED" if legacy
                             else "EXPLICIT_SLICE_COVERAGE"),
                "absent_legacy_keys": unverified,
                "graph_identification": "R2_R5_NOT_CERTIFIED"}
    return report


def load_engine(folder):
    root = Path(folder).resolve(strict=True)
    for name in ("amplitude_rules.py", "feynman.py", "dred.py"):
        if not (root/name).is_file():
            raise FileNotFoundError(root/name)
    sys.path.insert(0, str(root))
    AR = importlib.import_module("amplitude_rules")
    if Path(AR.__file__).resolve().parent != root:
        raise RuntimeError("import resolved outside declared engine")
    return AR


def projector_check(AR):
    Pi = AR.pinv_sparse()
    M = sp.Matrix(10, 10, lambda a, b: sp.sympify(Pi.get((a, b), 0)))
    P0 = sp.zeros(10)
    for a in (0, 3, 9):
        P0[a, a] = 1
    for a in (4, 7):
        for b in (4, 7):
            P0[a, b] = Q(1, 2)
    P1 = sp.zeros(10)
    for a in (1, 2, 6, 8):
        P1[a, a] = 1
    P2m = sp.eye(10)-P0-P1
    projectors = (P0, P1, P2m)

    def ctype(a):
        m, n = HC[a]
        count = int(m in (0, 3))+int(n in (0, 3))
        return {2: 0, 1: 1, 0: 2}[count]

    def channel(a, b):
        ca, cb = ctype(a), ctype(b)
        if ca == cb == 1:
            return 1
        if ca == cb == 2:
            return 2
        return 0

    for s, P in enumerate(projectors):
        zero_matrix = P*P-P
        if any(sp.simplify(v) != 0 for v in zero_matrix):
            raise AssertionError("projector is not idempotent")
        PM = P*M
        for a in range(10):
            for b in range(10):
                want = M[a, b] if channel(a, b) == s else 0
                zero(PM[a, b]-want, "coarse helicity marker")
    return Pi, channel


def laurent_coefficient(expr, x, power):
    expr = sp.cancel(expr)
    num, den = sp.fraction(expr)
    dp = sp.Poly(sp.expand(den), x)
    if len(dp.terms()) != 1:
        raise ValueError("not a Laurent polynomial")
    (deg,), cf = dp.terms()[0]
    np = sp.Poly(sp.expand(num), x)
    return sp.expand(np.coeff_monomial(x**(deg+power))/cf) \
        if deg+power >= 0 else sp.Integer(0)


def replay(AR, graph, branch, outdir):
    """Historical flat momentum-slice algebra, with honest coverage."""
    start = time.time()
    F = AR.F
    if tuple(F.HC) != HC:
        raise ValueError("independent-coordinate order mismatch")
    Pi, channel = projector_check(AR)
    Gh = AR.ghost_num()
    V = F.vertices()
    kap = F.KAPPA
    LS, PS = sp.symbols("l0:4"), sp.symbols("p0:4")
    names = {**{r: LS[r] for r in range(4)},
             **{4+r: PS[r] for r in range(4)}}
    u, v = sp.symbols("u0:3"), sp.symbols("v0:3")
    slice_sub = {LS[1]: 0, LS[2]: 0, PS[1]: 0, PS[2]: 0,
                 PS[0]: q0, PS[3]: q3}

    def route(vt, routing):
        out = {}
        for key, poly in F.vt_route(vt, routing).items():
            e = poly.to_sympy(names) if hasattr(poly, "to_sympy") else poly
            # Polynomial substitution commutes with the finite contractions.
            out[key] = sp.expand(sp.sympify(e).subs(slice_sub))
        return out

    def pw(a, b, marker):
        return sp.sympify(Pi[(a, b)])*marker[channel(a, b)]

    def gw(a, b, marker):
        return sp.sympify(Gh[(a, b)])*marker[0 if a in (0, 3) else 1]

    N = {}
    def add(key, value):
        N[key] = N.get(key, 0)+value

    dens = "bubble"
    if graph == "D01":
        vt = V["V3_grav"]
        va = route(vt, [(0, 1), (-1, 0), (1, -1)])
        vb = route(vt, [(0, -1), (1, 0), (-1, 1)])
        for (a, c, e), pa in va.items():
            for (b, d, f), pb in vb.items():
                if (c, d) in Pi and (e, f) in Pi:
                    add((a, b), pa*pb*pw(c, d, u)*pw(e, f, v))
        pref = sp.sympify(AR.base_rules()["graphs"]["D01"]["S_f"]) \
            *(I*kap)**2*I**(2*vt.phase)*I**2

    elif graph == "D03":
        vt = V["V_cb_c_h"]
        va = route(vt, [(-1, 0), (1, -1), (0, 1)])
        vb = route(vt, [(-1, 1), (1, 0), (0, -1)])
        for (rho, mu, a), pa in va.items():
            for (sg, nu, b), pb in vb.items():
                if (mu, sg) in Gh and (nu, rho) in Gh:
                    add((a, b), pa*pb*gw(mu, sg, u)*gw(nu, rho, v))
        pref = -(I*kap)**2*I**(2*vt.phase)

    elif graph == "D11":
        vt = V["V_h_phi_phi"]
        va = route(vt, [(0, 1), (-1, 0), (1, -1)])
        vb = route(vt, [(0, -1), (1, 0), (-1, 1)])
        for (a, _, _), pa in va.items():
            for (b, _, _), pb in vb.items():
                add((a, b), pa*pb*u[0]*v[0])
        pref = Q(1, 2)*(I*kap)**2*I**(2*vt.phase)*I**2

    elif graph == "D04":
        vt = V["V_h_phi_phi"]
        va = route(vt, [(-1, 0), (0, 1), (1, -1)])
        vb = route(vt, [(1, 0), (0, -1), (-1, 1)])
        for (c, _, _), pa in va.items():
            for (d, _, _), pb in vb.items():
                if (c, d) in Pi:
                    add((0, 0), pa*pb*pw(c, d, u)*v[0])
        pref = (I*kap)**2*I**(2*vt.phase)*I**2

    elif graph == "D06":
        vt = V["V_cb_c_h"]
        va = route(vt, [(0, -1), (1, 0), (-1, 1)])
        vb = route(vt, [(-1, 0), (0, 1), (1, -1)])
        for (rho, mu, a), pa in va.items():
            for (sg, nu, b), pb in vb.items():
                if (mu, sg) in Gh and (a, b) in Pi:
                    add((rho, nu), pa*pb*gw(mu, sg, u)*pw(a, b, v))
        pref = (I*kap)**2*I**(2*vt.phase)*I

    elif graph == "D13":
        rules = AR.base_rules()
        vk, vg = AR.K_vertex(rules), V["V_cb_c_h"]
        va = route(vk, [(0, -1), (1, 0), (-1, 1)])
        vb = route(vg, [(-1, 0), (0, 1), (1, -1)])
        for (ap, mu, c), pa in va.items():
            for (rho, nu, d), pb in vb.items():
                if (mu, rho) in Gh and (c, d) in Pi:
                    add((ap, nu), pa*pb*gw(mu, rho, u)*pw(c, d, v))
        r = rules["graphs"]["D13"]
        pref = sp.sympify(r["ext_sign"]*r["S_f"]*r["loop_sign"]) \
            *(I*kap)**2*I**(vk.phase+vg.phase)*I

    elif graph == "D02":
        dens = "tadpole"
        vt = V["V4_grav"]
        va = route(vt, [(0, 1), (0, -1), (1, 0), (-1, 0)])
        for (a, b, c, d), pa in va.items():
            if (c, d) in Pi:
                add((a, b), pa*pw(c, d, u)*v[0])
        pref = Q(1, 2)*(I*kap**2)*I**vt.phase*I

    elif graph == "D12":
        dens = "tadpole"
        vt = V["V_hh_phi_phi"]
        va = route(vt, [(0, 1), (0, -1), (1, 0), (-1, 0)])
        for (a, b, _, _), pa in va.items():
            add((a, b), pa*u[0]*v[0])
        pref = Q(1, 2)*(I*kap**2)*I**vt.phase*I

    elif graph == "D05a":
        dens = "tadpole"
        vt = V["V_hh_phi_phi"]
        va = route(vt, [(1, 0), (-1, 0), (0, 1), (0, -1)])
        for (c, d, _, _), pa in va.items():
            if (c, d) in Pi:
                add((0, 0), pa*pw(c, d, u)*v[0])
        pref = Q(1, 2)*(I*kap**2)*I**vt.phase*I
    else:
        raise ValueError("unknown graph")

    # Exact circle average via a Laurent variable z=e^(i theta).
    z, w = sp.symbols("z w", nonzero=True)
    cosine = (z+1/z)/2
    sine = (z-1/z)/(2*I)
    lm0, lm3 = I*cosine/w, sine/w
    l2 = -1/w**2
    den = l2 if dens == "tadpole" else \
        l2*((lm0-q0)**2-(lm3-q3)**2)

    def pole(expr):
        e = sp.expand(expr.subs({LS[0]: lm0, LS[3]: lm3}))
        if e == 0:
            return sp.Integer(0)
        ser = sp.series(e/den, w, 0, 3).removeO()
        g2 = sp.expand(ser).coeff(w, 2)
        average = laurent_coefficient(g2, z, 0)
        # i/(4 pi^2) times 2 pi times the circle average.
        return sp.cancel(I*average/(2*sp.pi))

    if graph in ("D04", "D05a"):
        domain = [(0, 0)]
    elif graph == "D06":
        domain = [(a, b) for a in range(4) for b in range(4)]
    elif graph == "D13":
        domain = [(a, b) for a in range(10) for b in range(4)]
    else:
        domain = [(a, b) for a in range(10) for b in range(10)]

    cs = physical_cs(branch)
    values, states, mixed = {}, {}, {}
    for key in domain:
        e = sp.expand(N.get(key, 0))
        pair_poles = {}
        if e != 0:
            for mon, cf in sp.Poly(e, *u, *v).terms():
                iu = [i for i in range(3) if mon[i]]
                iv = [i for i in range(3) if mon[3+i]]
                if len(iu) != 1 or len(iv) != 1 \
                        or sum(mon[:3]) != 1 or sum(mon[3:]) != 1:
                    raise ValueError("unexpected channel-marker degree")
                s, t = iu[0], iv[0]
                if dens == "tadpole":
                    t = s
                pv = pole(cf)
                pair_poles[(s, t)] = pair_poles.get((s, t), 0)+pv
        pair_poles = {st: sp.factor(vv)
                      for st, vv in pair_poles.items()
                      if sp.simplify(vv) != 0}
        bad = {str(st): str(vv) for st, vv in pair_poles.items()
               if st[0] != st[1]}
        skey = str(key)
        if bad:
            mixed[skey] = bad
        if bad and branch != "UNIT":
            states[skey] = "EXCLUDED_MIXED_CHANNEL"
            continue
        total = 0
        for (s, t), pv in pair_poles.items():
            total += pv if branch == "UNIT" else pv*cs[s]
        value = sp.factor(sp.cancel(-I*pref*total))
        if value == 0:
            states[skey] = "COMPUTED_ZERO_SLICE"
        else:
            states[skey] = "COMPUTED_NONZERO_SLICE"
            values[skey] = str(value)

    result = {
        "graph": graph, "branch": branch,
        "status": "ALGEBRAIC_SLICE_ONLY",
        "prescription_status": "R2_R3_R4_R5_NOT_CERTIFIED",
        "prefactor_status": "DECLARED_FROZEN_SOURCE_CONVENTIONS",
        "pref": str(pref),
        "key_status": states,
        "mixed_channel_poles_before_prefactor": mixed,
        "Gamma_pole_coeff_of_1/(4-d)": values,
        "seconds": time.time()-start}
    path = Path(outdir)/("spec_"+graph+"_"+branch+".json")
    write_json(path, result)
    return {"written": str(path), "status": result["status"],
            "excluded_keys": sum(s == "EXCLUDED_MIXED_CHANNEL"
                                 for s in states.values())}


def tree_normalization(AR):
    F = AR.F
    if tuple(F.HC) != HC:
        raise ValueError("coordinate order mismatch")
    vt = F.grav_vertex(2)
    ks = [F.ksym(j) for j in range(2)]
    names = {4*j+r: ks[j][r] for j in range(2) for r in range(4)}
    p = (q0, 0, 0, q3)
    h00, h03, h33, f = sp.symbols("h00 h03 h33 f")
    # De Donder equations on h11=h22=f.
    F0 = q0*(h00+h33+2*f)/2-q3*h03
    F3 = q0*h03-q3*(h00+h33-2*f)/2
    solutions = sp.solve((F0, F3), (h00, h03), dict=True)
    if len(solutions) != 1:
        raise AssertionError("generic de Donder solve failed")
    sol = solutions[0]
    hv = {0: sol[h00], 3: sol[h03], 9: h33, 4: f, 7: f}
    Eu = einstein_coordinates(hv)
    ratios = []
    for a in range(10):
        val = 0
        for b in range(10):
            poly = vt.T.get((a, b))
            if poly is None:
                continue
            e = I**vt.phase*poly.to_sympy(names)
            sub = {ks[0][r]: p[r] for r in range(4)}
            sub.update({ks[1][r]: -p[r] for r in range(4)})
            val += e.subs(sub)*hv.get(b, 0)
        val = sp.cancel(val)
        den = sp.cancel(Eu[a])
        if den == 0:
            zero(val, "tree zero-coordinate comparison")
        else:
            ratios.append(sp.cancel(val/den))
    if not ratios:
        raise AssertionError("tree check had no nonzero probe")
    N = ratios[0]
    for r in ratios[1:]:
        zero(r-N, "tree normalization not constant")
    zero(N-1, "declared N")
    Agh = sp.sympify(F.A_GH)
    zero(Agh-Q(1, 2), "declared A_GH")
    zero(N/(I*Agh)+2*I, "tree-predicted lambda")
    return {"N": str(N), "A_GH": str(Agh),
            "lambda_pred": str(N/(I*Agh)),
            "scope": "TREE_NORMALIZATION_ON_DECLARED_DD_CLASS"}


def manifest(root):
    root = Path(root).resolve(strict=True)
    if not root.is_dir():
        raise ValueError("manifest root is not a directory")
    files = []
    for p in sorted(root.rglob("*"),
                    key=lambda p: p.relative_to(root).as_posix()):
        if p.is_symlink():
            raise ValueError("symlink requires a separate policy: " + str(p))
        rel = p.relative_to(root)
        if ".pytest_cache" in rel.parts or p.suffix == ".pyc":
            continue
        if p.is_file():
            digest = hashlib.sha256(p.read_bytes()).hexdigest()
            files.append((rel.as_posix(), digest))
    tree = hashlib.sha256()
    for rel, digest in files:
        name = rel.encode("utf-8")
        tree.update(len(name).to_bytes(8, "big"))
        tree.update(name)
        tree.update(bytes.fromhex(digest))
    return {"serialization":
                "sorted UTF8 relative names; 8-byte length; name; raw SHA256",
            "exclusions": [".pytest_cache path component", "*.pyc"],
            "symlinks": "REJECTED",
            "files": dict(files), "tree_sha256": tree.hexdigest()}


def main():
    p = argparse.ArgumentParser()
    sub = p.add_subparsers(dest="command", required=True)
    sub.add_parser("selftest")
    lp = sub.add_parser("logs")
    lp.add_argument("root")
    lp.add_argument("--legacy", action="store_true")
    rp = sub.add_parser("replay")
    rp.add_argument("graph", choices=GRAPHS)
    rp.add_argument("branch", choices=("CR", "F", "UNIT"))
    rp.add_argument("--engine", required=True)
    rp.add_argument("--out", required=True)
    tp = sub.add_parser("tree")
    tp.add_argument("--engine", required=True)
    mp = sub.add_parser("manifest")
    mp.add_argument("root")
    a = p.parse_args()
    if a.command == "selftest":
        result = {**check_heat_and_mellin(), **check_catalogue_algebra(),
                  "execution_claim":
                      "THIS_OUTPUT_EXISTS_ONLY_IF_THE_USER_RUNS_THE_PROGRAM",
                  "O1": "NOT_CLOSED",
                  "bulk_symmetry_restored": False}
    elif a.command == "logs":
        result = compare_logs(a.root, a.legacy)
    elif a.command == "replay":
        result = replay(load_engine(a.engine), a.graph, a.branch, a.out)
    elif a.command == "tree":
        result = tree_normalization(load_engine(a.engine))
    else:
        result = manifest(a.root)
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
