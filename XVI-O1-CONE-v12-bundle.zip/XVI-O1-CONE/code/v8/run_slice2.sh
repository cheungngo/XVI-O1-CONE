#!/bin/bash
cd /workspace/XVI-O1-CONE
for g in D04 D06 D13 D11 D03 D01; do python3 code/v8/slice_run.py $g > logs/v8/slice/run2_$g.out 2> logs/v8/slice/run2_$g.err; echo "$g rc=$?"; done; echo ALLDONE
