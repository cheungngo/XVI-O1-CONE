import sys, time; sys.path.insert(0,'/workspace/XVI-O1-CONE/code/v8')
import slice_engine as SE, sympy as sp
AR = SE.V7.load_engine('/tmp/o1cone_ro/XVI-P/code/p5_entry')
g = sys.argv[1]
N, dens, pref, u, v, LS = SE.numerators(AR, g)
t=time.time(); n=0
for key, e in N.items():
    for st, cf in SE.split_pairs(e, u, v, dens).items():
        c = SE.circle_pole(cf, LS, dens); d = SE.dred_pole(cf, LS, dens)
        d0 = d.subs({SE.G00:0,SE.G03:0,SE.G33:0})
        assert sp.simplify(c-d0)==0, (key, st, c, d0)
        if dens!='tadpole':
            rho,x = SE.x_density(cf, LS); assert sp.simplify(sp.integrate(rho,(x,0,1))-c)==0,(key,st)
        n+=1
print(g,'pairs checked',n,round(time.time()-t,1))
