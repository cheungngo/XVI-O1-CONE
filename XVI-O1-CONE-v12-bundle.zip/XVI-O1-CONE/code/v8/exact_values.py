"""v8: the six exact-direction coefficients e (x_nonPP = sum_i e_i B_i) constrained by the
constant-profile HH catalogue coordinates y (hh_map).  Exact over Q(i).  PARTIAL: only rank(B|hhK)=4
combinations are fixed; the kernel directions need CK/CB constant data and m>0 jet data."""
import json, sys, sympy as sp
out = {}
for t in sys.argv[1:]:
    d = json.load(open(f'logs/v8/cert/apex_cert_{t}_vectors.json'))
    h = json.load(open(f'logs/v8/cert/hh_map_{t}.json'))
    K = d['K']; hhK = [k for k in K if k < 18]
    B = sp.Matrix([[sp.Rational(a) + sp.I*sp.Rational(b) for a, b in row] for row in d['B_coords']])
    A = B[:, hhK].T                      # 6 x 6 : y = A e
    y = sp.Matrix([sp.Rational(v) for v in h['hh_sum']['engine_HH_K_coords']])
    e = sp.symbols('e1:7')
    sol = sp.linsolve((A, y), *e)
    sols = list(sol)
    rec = {'hhK': hhK, 'rank': A.rank(), 'consistent': len(sols) == 1,
           'solution': [str(sp.simplify(s)) for s in sols[0]] if sols else None,
           'kernel_dim': 6 - A.rank(), 'status': 'PARTIAL: 4 of 6 combinations fixed by constant-profile hh data; conditional on R1-R5 and the declared HH dictionary'}
    out[t] = rec; print(t, rec)
json.dump(out, open('logs/v8/cert/exact_values.json', 'w'), indent=1)
