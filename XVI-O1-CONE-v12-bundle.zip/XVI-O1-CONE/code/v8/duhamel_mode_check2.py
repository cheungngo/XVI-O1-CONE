"""v8: refined check of the per-mode Duhamel identity: cutoff sequence R and 1/R extrapolation; inner integral
over r' split at r (kernel peak). Numerical evidence only."""
import numpy as np, json
from scipy.special import ive
from scipy import integrate
def k(nu, r, rp, t): return np.exp(-(r - rp)**2/(4*t))*ive(nu, r*rp/(2*t))/(2*t)
def T(nu, mu, x, R):
    def inner(r):
        f = lambda rp: r*rp*k(nu, r, rp, x)*k(mu, rp, r, 1 - x)/rp**2
        a = integrate.quad(f, 0, r, limit=200, epsabs=1e-13)[0]
        b = integrate.quad(f, r, np.inf, limit=200, epsabs=1e-13)[0]
        return a + b
    return integrate.quad(inner, 0, R, limit=400, epsabs=1e-11)[0]
out = {}
xs, ws = np.polynomial.legendre.leggauss(12); xs = 0.5*(xs + 1); ws = 0.5*ws
for nu, mu in [(0.5, 1.5), (0.7, 2.4)]:
    row = {}
    for R in (25.0, 50.0, 100.0):
        row[R] = (mu**2 - nu**2)*sum(w*T(nu, mu, x, R) for w, x in zip(ws, xs))
        print(nu, mu, R, row[R], flush=True)
    ext = 2*row[100.0] - row[50.0]
    out[str((nu, mu))] = {'by_R': row, 'richardson_1/R': ext, 'rhs': (mu - nu)/2}
    print('extrap', nu, mu, ext, (mu - nu)/2, flush=True)
json.dump(out, open('/workspace/XVI-O1-CONE/logs/v8/duhamel_mode_check2.json', 'w'), indent=1)
