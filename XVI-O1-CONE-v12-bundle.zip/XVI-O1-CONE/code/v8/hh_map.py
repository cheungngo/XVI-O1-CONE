"""v8 items (d) and (a): exact map between the engine's constant-profile HH coordinates (6 of the 18) and the six
reflection-even catalogue structures S1..S6 of v7 (Wick dictionary declared below), and evaluation of the Ward
combinations supported on those six coordinates on the hh pole sum (CR, F) and per graph.
Dictionary (declared, checked by exact solvability): Euclidean longitudinal (tau,z) <-> Lorentzian (0,3) with
x^0=-i tau:  x00=-LL_tt, x03 = s_i * i LL_tz, x33=LL_zz, f = PM/2 (engine PM = h(e+,e-) = h11+h22, from gtimes);
q0 = s_i * i q_t, q3 = q_z.  Both signs s_i are tried; exactly-solvable choice reported.
usage: python3 hh_map.py <alpha p/q> <CR|F>"""
import sys, json, itertools
from fractions import Fraction as Fr
sys.path.insert(0, '/workspace/XVI-O1-CONE/code/v8')
import sympy as sp
import apex_exact as AJ
from gq import GQ
import apex_certificate_la as LA
from cone_v7 import invariant_data, structure_table, physical_cs, catalogue, bilinear, alpha as AL, kappa, q0, q3
a_s, br = sys.argv[1], sys.argv[2]
alpha = Fr(a_s); S = AJ.Setup(alpha, br)
tag = f"{a_s.replace('/', '_')}_{br}"
cert = json.load(open(f'/workspace/XVI-O1-CONE/logs/v8/cert/apex_cert_{tag}.json'))
vec = json.load(open(f'/workspace/XVI-O1-CONE/logs/v8/cert/apex_cert_{tag}_vectors.json'))
cands = AJ.candidates(S, 'h', 'h', 4); piv = cert['gh0']['HH']['pivot_candidates']
basis = [cands[i] for i in piv]
lab = cert['basis_labels']; K = vec['K']; KHH = [k for k in K if lab[k][0] == 'HH']   # positions in 34-order
hh_index = [lab[k][1] for k in KHH]                                                    # index within HH basis
x, y, Sst, idx = invariant_data()
def g2s(v):
    v = GQ.c(v); return sp.Rational(v.re.numerator, v.re.denominator) + sp.I*sp.Rational(v.im.numerator, v.im.denominator)
# m=0 unit atoms: LL (3 sym atoms) and PM
atoms = [('LL', [1, 0, 0, 0]), ('LL', [0, 1, 1, 0]), ('LL', [0, 0, 0, 1]), ('PM', [1])]
def cfg(at): return {at[0]: {(0, Fr(0)): [GQ(t) for t in at[1]]}}
def lor(at, si):
    C, v = at
    if C == 'PM': return {0: 0, 3: 0, 9: 0, 'f': sp.Rational(1, 2)*v[0]}
    return {0: -v[0], 3: si*sp.I*v[1], 9: v[3], 'f': 0}
QG = [(a, b) for a in range(1, 7) for b in range(1, 7)]
result = {}
for si in (1, -1):
    rows_E = [[] for _ in hh_index]; rows_S = [[] for _ in range(6)]
    for A in atoms:
        for B in atoms:
            for (qa, qb) in QG:
                q = [GQ(qa), GQ(qb)]
                for r, hi in enumerate(hh_index):
                    rows_E[r].append(g2s(AJ.eval_sym(basis[hi], cfg(A), cfg(B), q, True)))
                la, lb = lor(A, si), lor(B, si)
                sub = {x[0]: la[0], x[1]: la[3], x[2]: la[9], x[3]: la['f'], y[0]: lb[0], y[1]: lb[3], y[2]: lb[9], y[3]: lb['f'],
                       q0: si*sp.I*qa, q3: qb}
                for j in range(6): rows_S[j].append(sp.simplify(Sst[j].subs(sub)))
    Smat = sp.Matrix(rows_S); Emat = sp.Matrix(rows_E)
    # solve E = M S  (M: 6x6) exactly; consistency = residual zero on ALL complete columns
    try:
        M = (Emat * Smat.T) * (Smat * Smat.T).inv()
        resid = sp.simplify(Emat - M*Smat)
        ok = all(e == 0 for e in resid)
    except Exception as ex:
        ok = False; M = None
    result[si] = (ok, M)
good = [si for si, (ok, M) in result.items() if ok]
out = {'alpha': a_s, 'branch': br, 'solvable_sign_choices': good}
if good:
    si = good[0]; M = result[si][1]
    out['M_engine_HH_K_from_S'] = [[str(sp.simplify(M[i, j])) for j in range(6)] for i in range(6)]
    # Ward combinations supported on the six HH coordinates (exact, from the complete certificate)
    from gq import GQ as G
    P = lambda t: G(Fr(t[0]), Fr(t[1]))
    Z = [[P(t) for t in z] for z in vec['Z_basis']]
    piZ = [[z[k] for k in KHH] for z in Z]
    W = LA.nullspace(piZ, len(KHH))            # functionals on the six HH coords vanishing on Z
    Wm = sp.Matrix([[g2s(t) for t in w] for w in W])
    out['Ward_combos_on_HH_K'] = [[str(e) for e in Wm.row(i)] for i in range(Wm.rows)]
    cs = tuple(sp.simplify(c.subs(AL, sp.Rational(alpha.numerator, alpha.denominator))) for c in physical_cs(br))
    tab = structure_table(cs)
    MT = M.T
    def ycoords(b):
        return list(MT.solve(4*sp.Matrix(b)))
    per = {}
    tot = [0]*6
    for g, b in tab.items():
        yv = ycoords(list(b)); per[g] = {'b_S': [str(sp.simplify(t)) for t in b], 'engine_HH_K_coords': [str(sp.simplify(t)) for t in yv],
                                          'Ward_values': [str(sp.simplify((Wm.row(i)*sp.Matrix(yv))[0])) for i in range(Wm.rows)]}
        tot = [t + u for t, u in zip(tot, b)]
    ysum = ycoords(tot)
    out['per_graph_kappa2_over_pi'] = per
    out['hh_sum'] = {'b_S': [str(sp.simplify(t)) for t in tot], 'engine_HH_K_coords': [str(sp.simplify(t)) for t in ysum],
                     'Ward_values_on_sum': [str(sp.simplify((Wm.row(i)*sp.Matrix(ysum))[0])) for i in range(Wm.rows)]}
    out['units'] = 'kappa^2/pi; engine coordinates normalised by eval_sym (reflection+Bose symmetrised), Gamma_sym=4*Gamma'
    out['status'] = 'exact at the stated rational alpha; dictionary declared; graph identification conditional (R1-R5)'
json.dump(out, open(f'/workspace/XVI-O1-CONE/logs/v8/cert/hh_map_{tag}.json', 'w'), indent=1)
print(json.dumps(out, indent=1))
