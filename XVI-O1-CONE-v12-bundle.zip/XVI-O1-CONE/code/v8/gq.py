"""Exact Gaussian rationals Q(i) for the v8 exact port of the apex inventory."""
from fractions import Fraction as Fr
class GQ:
    __slots__ = ('re', 'im')
    def __init__(self, re=0, im=0):
        self.re = Fr(re); self.im = Fr(im)
    @staticmethod
    def c(x): return x if isinstance(x, GQ) else GQ(x)
    def __add__(s, o): o = GQ.c(o); return GQ(s.re + o.re, s.im + o.im)
    __radd__ = __add__
    def __sub__(s, o): o = GQ.c(o); return GQ(s.re - o.re, s.im - o.im)
    def __rsub__(s, o): return GQ.c(o) - s
    def __mul__(s, o):
        if not isinstance(o, GQ):
            o = Fr(o); return GQ(s.re * o, s.im * o)
        return GQ(s.re * o.re - s.im * o.im, s.re * o.im + s.im * o.re)
    __rmul__ = __mul__
    def __neg__(s): return GQ(-s.re, -s.im)
    def inv(s):
        n = s.re * s.re + s.im * s.im
        if n == 0: raise ZeroDivisionError('GQ inverse of 0')
        return GQ(s.re / n, -s.im / n)
    def __truediv__(s, o): return s * GQ.c(o).inv()
    def __rtruediv__(s, o): return GQ.c(o) * s.inv()
    def __bool__(s): return s.re != 0 or s.im != 0
    def __eq__(s, o): o = GQ.c(o); return s.re == o.re and s.im == o.im
    def __hash__(s): return hash((s.re, s.im))
    def __repr__(s): return 'GQ(%s,%s)' % (s.re, s.im)
    def tup(s): return (str(s.re), str(s.im))
def inv(x): return GQ.c(x).inv()
