"""v8: slice numerators of the frozen engine (verbatim numerator section of v7's replay, cone_v7.py), plus
(i)  the replay circle-average pole (reference),
(ii) a slice-DRED pole: the same UV angular average done with hat-metric ghat_L = eta_L - Gt_L (Gt formal,
     evanescent, XVI-P R3/R4 lifting restricted to the longitudinal slice) -> evanescent (Gt) pole coefficients,
(iii) Feynman-parameter-resolved pole densities rho_(s,t)(x) for bubbles (x = Schwinger fraction of the v-line),
     checked to integrate to the circle pole.
Prescription status: ALGEBRAIC_SLICE_ONLY; R2-R5 NOT certified."""
import sys, json, time
from pathlib import Path
sys.path.insert(0, '/workspace/XVI-O1-CONE/code/v8')
import sympy as sp
import cone_v7 as V7
src = Path('/workspace/XVI-O1-CONE/code/v8/cone_v7.py').read_text()
a = src.index('def replay(AR, graph, branch, outdir):'); b = src.index('    # Exact circle average via a Laurent variable')
body = src[a:b].replace('def replay(AR, graph, branch, outdir):', 'def numerators(AR, graph):', 1)
body += '    return N, dens, pref, u, v, LS\n'
exec(body, V7.__dict__)
numerators = V7.numerators
I = sp.I
q0, q3 = V7.q0, V7.q3
G00, G03, G33 = sp.symbols('Gt00 Gt03 Gt33')
GH = {(0, 0): 1 - G00, (3, 3): -1 - G33, (0, 3): -G03, (3, 0): -G03}

def split_pairs(e, u, v, dens):
    out = {}
    if e == 0: return out
    for mon, cf in sp.Poly(sp.expand(e), *u, *v).terms():
        s = [i for i in range(3) if mon[i]][0]; t = [i for i in range(3) if mon[3 + i]][0]
        if dens == 'tadpole': t = s
        out[(s, t)] = out.get((s, t), 0) + cf
    return out

def circle_pole(expr, LS, dens):
    z, w = sp.symbols('z w', nonzero=True)
    cosine = (z + 1/z)/2; sine = (z - 1/z)/(2*I)
    lm0, lm3 = I*cosine/w, sine/w
    l2 = -1/w**2
    den = l2 if dens == 'tadpole' else l2*((lm0 - q0)**2 - (lm3 - q3)**2)
    e = sp.expand(expr.subs({LS[0]: lm0, LS[3]: lm3}))
    if e == 0: return sp.Integer(0)
    ser = sp.series(e/den, w, 0, 3).removeO()
    g2 = sp.expand(ser).coeff(w, 2)
    return sp.cancel(I*V7.laurent_coefficient(g2, z, 0)/(2*sp.pi))

def _dhat_power(P, L0, L3, j, ghat):
    X = sp.expand(P)
    for _ in range(j):
        X = sp.expand(ghat[(0, 0)]*sp.diff(X, L0, 2) + 2*ghat[(0, 3)]*sp.diff(X, L0, L3) + ghat[(3, 3)]*sp.diff(X, L3, 2))
    return X

def angular_pole(e_over_den_series_coeff, L0, L3, ghat):
    """g2(L) homogeneous of degree -2 (a rational function with denominator c (L0^2-L3^2)^m).
    Returns i/(2 pi) <g2> at L^2=-1 using <P>=(L^2)^j Dhat^j P/(2^j j! prod_{i<j}(d+2i)), d=2 (pole level)."""
    g2 = sp.cancel(sp.together(e_over_den_series_coeff))
    if g2 == 0: return sp.Integer(0)
    num, den = sp.fraction(g2)
    L2 = L0**2 - L3**2
    dp = sp.Poly(den, L0, L3); m2 = dp.total_degree()
    assert m2 % 2 == 0
    m = m2//2
    c = sp.cancel(den/L2**m)
    assert not c.has(L0) and not c.has(L3), ('denominator not a power of L^2', den)
    num = sp.expand(num)
    j = m - 1
    np_ = sp.Poly(num, L0, L3)
    assert all(sum(mon) == 2*j for mon in np_.monoms()), 'numerator not homogeneous of degree 2j'
    X = _dhat_power(num, L0, L3, j, ghat)
    norm = 2**j*sp.factorial(j)*sp.prod([2 + 2*i for i in range(j)])
    avg = X/(norm*c)/(-1)        # divide by L^2 = -1
    return sp.expand(I*avg/(2*sp.pi))

def uv_coeff(expr, LS, dens, shift_x=None):
    """coefficient g2(L) of w^2 in expr/den with l = L/w (+ x p for the Feynman form)."""
    L0, L3, w = sp.symbols('L0 L3 w')
    if shift_x is None:
        e = sp.expand(expr.subs({LS[0]: L0/w, LS[3]: L3/w}))
        l2 = (L0**2 - L3**2)/w**2
        den = l2 if dens == 'tadpole' else l2*((L0/w - q0)**2 - (L3/w - q3)**2)
    else:
        x = shift_x
        e = sp.expand(expr.subs({LS[0]: L0/w + x*q0, LS[3]: L3/w + x*q3}, simultaneous=True))
        den = ((L0**2 - L3**2)/w**2 + x*(1 - x)*(q0**2 - q3**2))**2
    if e == 0: return sp.Integer(0), L0, L3
    ser = sp.series(e/den, w, 0, 3).removeO()
    return sp.expand(ser).coeff(w, 2), L0, L3

def dred_pole(expr, LS, dens):
    g2, L0, L3 = uv_coeff(expr, LS, dens)
    return angular_pole(g2, L0, L3, GH)

def x_density(expr, LS):
    x = sp.Symbol('x')
    g2, L0, L3 = uv_coeff(expr, LS, 'bubble', shift_x=x)
    eta = {(0, 0): 1, (3, 3): -1, (0, 3): 0, (3, 0): 0}
    return sp.expand(angular_pole(g2, L0, L3, eta)), x
