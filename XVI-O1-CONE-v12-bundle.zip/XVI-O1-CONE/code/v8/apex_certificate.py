"""v8 item (e) + (a)/(d) support: COMPLETE exact Q(i) certificate of the apex counterterm inventory.

Historical apex_run.py evaluated functionals on RANDOM configurations mod p (rank = lower bound only).
Here every functional is bilinear in finitely many configuration atoms and polynomial in the longitudinal
momentum q=(q0,q1); we evaluate on ALL relevant unit atoms (pairs with n1+n2=0; other pairs vanish identically
because every candidate carries n1+n2=0 and every operator preserves n) and on a full tensor grid of q values
of size (D+1)^2 with D >= the q-degree.  A complete evaluation matrix has the SAME row space as the functionals,
so its exact rank is the exact functional rank, and its exact kernel is the exact relation space.
Certificates written: exact ranks, pivot (row,col) sets with a nonzero exact minor, kernel bases verified to
annihilate the complete matrix.  usage: python3 apex_certificate.py <alpha p/q> <CR|F> [DM] [QN]"""
import sys, json, time, itertools, hashlib
from fractions import Fraction as Fr
sys.path.insert(0, '/workspace/XVI-O1-CONE/code/v8')
import apex_exact as AJ
from apex_exact import Setup, Ops, candidates, eval_sym, FIELDS, REFL, TEN, VEC
from gq import GQ, inv
alpha = Fr(sys.argv[1]); branch = sys.argv[2]
DM = int(sys.argv[3]) if len(sys.argv) > 3 else 6
QN = int(sys.argv[4]) if len(sys.argv) > 4 else 6
S = Setup(alpha, branch); T0 = time.time()
QGRID = [[GQ(a), GQ(b)] for a in range(1, QN + 1) for b in range(1, QN + 1)]
QGEN = [GQ(Fr(37, 11)), GQ(Fr(-53, 17))]
def negq(q): return [-x for x in q]
def log(*a): print(*a, round(time.time() - T0, 1), flush=True)

def unit_atoms(F, dmax):
    comps = FIELDS[F][0]; out = []
    for (C, n, m) in S.jets(F, dmax):
        rk = comps[C][1]
        vecs = {0: [[1]], 1: [[1, 0], [0, 1]], 2: [[1, 0, 0, 0], [0, 1, 1, 0], [0, 0, 0, 1]]}[rk]
        for i, v in enumerate(vecs):
            out.append(((C, n, m, i), {C: {(n, m): [GQ(x) for x in v]}}))
    return out
def nonzero_jets(cfg):
    return {(C, k) for C, d in cfg.items() for k, v in d.items() if any(v)}

# ------------------------------------------------------------------ exact linear algebra on GQ
def rref_rows(rows):
    """returns rank, pivot row indices, pivot columns (row-wise incremental elimination, like AJ.rank_and_basis)."""
    R = []; piv = []; pcols = []
    for i, r in enumerate(rows):
        v = list(r)
        for (pc, prow) in R:
            f = v[pc]
            if f: v = [x - f * y for x, y in zip(v, prow)]
        nz = next((j for j, x in enumerate(v) if x), None)
        if nz is not None:
            iv = inv(v[nz]); v = [x * iv for x in v]
            R.append((nz, v)); piv.append(i); pcols.append(nz)
    return len(R), piv, pcols
def nullspace(A, ncols):
    M = [list(r) for r in A]; pivc = []; r = 0
    for c in range(ncols):
        pr = next((i for i in range(r, len(M)) if M[i][c]), None)
        if pr is None: continue
        M[r], M[pr] = M[pr], M[r]
        iv = inv(M[r][c]); M[r] = [x * iv for x in M[r]]
        for i in range(len(M)):
            if i != r and M[i][c]:
                f = M[i][c]; M[i] = [x - f * y for x, y in zip(M[i], M[r])]
        pivc.append(c); r += 1
        if r == len(M): break
    free = [c for c in range(ncols) if c not in pivc]; B = []
    for fc in free:
        x = [GQ(0)] * ncols; x[fc] = GQ(1)
        for i, pc in enumerate(pivc): x[pc] = -M[i][fc]
        B.append(x)
    return B
def det(M):
    """exact determinant (Gaussian elimination over the field Q(i))."""
    M = [list(r) for r in M]; n = len(M); dt = GQ(1)
    for c in range(n):
        pr = next((i for i in range(c, n) if M[i][c]), None)
        if pr is None: return GQ(0)
        if pr != c: M[c], M[pr] = M[pr], M[c]; dt = -dt
        dt = dt * M[c][c]; iv = inv(M[c][c])
        for i in range(c + 1, n):
            if M[i][c]:
                f = M[i][c] * iv; M[i] = [x - f * y for x, y in zip(M[i], M[c])]
    return dt
def gq_digest(x): return hashlib.sha256(repr(x.tup()).encode()).hexdigest()[:16]
def minor_cert(rows, rank):
    """rows: matrix (list of rows). Find rank x rank nonsingular minor: pivot rows, then pivot cols of those rows."""
    r, prow, _ = rref_rows(rows)
    assert r == rank
    sub = [rows[i] for i in prow]
    cols = list(zip(*sub)); r2, pc, _ = rref_rows([list(c) for c in cols])   # independent columns
    assert r2 == rank
    Mm = [[sub[i][j] for j in pc] for i in range(rank)]
    D = det(Mm); assert D
    return {'rows': prow, 'cols': pc, 'det_nonzero': True, 'det_sha16': gq_digest(D),
            'det_num_digits': [len(str(D.re.numerator)), len(str(D.im.numerator))]}
def apply(z, rows): return [sum((zi * x for zi, x in zip(z, row)), GQ(0)) for row in rows]

res = {'alpha': str(alpha), 'branch': branch, 'arith': 'exact Q(i)', 'DM': DM, 'q_grid': f'{QN}x{QN}'}
SECT = {'HH': ('h', 'h', True), 'CB': ('cb', 'c', False), 'CK': ('K', 'c', False), 'PP': ('phi', 'phi', True)}
# ------------------------------------------------------------------ 1. gh0 candidate bases, complete
def read_sets(cands, bose):
    A = set(); B = set()
    for c in cands:
        (C1, n1, m1), (C2, n2, m2) = c[0], c[1]
        for (C, n, m), tgt in (((C1, n1, m1), A), ((C2, n2, m2), B)):
            tgt.add((C, (n, m))); tgt.add((REFL[C], (-n, m)))
    if bose: A = B = A | B
    return A, B
ATOMS = {F: unit_atoms(F, DM) for F in FIELDS}
basis = {}; cert = {}; RS = {}
for name, (F1, F2, bose) in SECT.items():
    cands = candidates(S, F1, F2, 4)
    RA, RB = read_sets(cands, bose); RS[name] = (RA, RB)
    a1 = [a for a in ATOMS[F1] if nonzero_jets(a[1]) & RA]; a2 = [a for a in ATOMS[F2] if nonzero_jets(a[1]) & RB]
    cols = [(x, y, q) for x in a1 for y in a2 if x[0][1] + y[0][1] == 0 for q in QGRID]
    rows = [[eval_sym(c, x[1], y[1], q, bose) for (x, y, q) in cols] for c in cands]
    r, piv, _ = rref_rows(rows)
    basis[name] = [cands[i] for i in piv]
    dep = nullspace([list(t) for t in zip(*rows)], len(cands))     # relations among candidates
    for z in dep: assert not any(apply(z, list(map(list, zip(*rows))))), 'relation fails'
    cert[name] = {'n_candidates': len(cands), 'rank': r, 'pivot_candidates': piv, 'n_columns': len(cols),
                  'n_relations': len(dep), 'relations_verified_on_complete_columns': True,
                  'minor': minor_cert(rows, r)}
    log('gh0', name, len(cands), r, len(cols))
res['gh0'] = cert; res['gh0_dims'] = {k: v['rank'] for k, v in cert.items()}
order = [(name, i) for name in SECT for i in range(len(basis[name]))]
N = len(order); res['N_total'] = N
def Cv(name, i, a, b, q):
    F1, F2, bose = SECT[name]; return eval_sym(basis[name][i], a, b, q, bose)
def jm(name, i):
    c = basis[name][i]; return (str(c[0]), str(c[1]), c[4])
res['basis_labels'] = [[nm, i, *jm(nm, i)] for (nm, i) in order]
# ------------------------------------------------------------------ 2. ST rows (sigma_0 closure), complete
def relevant(F, ops, targets):
    out = []
    for lab, cfg in ATOMS[F]:
        hit = False
        for op in ops:
            img = op(cfg)
            if nonzero_jets(img) & targets: hit = True; break
        if hit: out.append((lab, cfg))
    return out
RHH = RS['HH'][0]; RCKA, RCKB = RS['CK']; RCBA, RCBB = RS['CB']
o_gen = Ops(S, QGEN); o_gen_n = Ops(S, negq(QGEN))
h_rel = relevant('h', [lambda c: c, lambda c: o_gen_n.E(c)], RHH | RCKA)
c_rel = relevant('c', [lambda c: c, lambda c: o_gen.K2(c)], RHH | RCKB | RCBB)
b_rel = relevant('b', [lambda c: c, lambda c: o_gen_n.C2T(c)], RCBA | RCKA)
log('relevant atoms h,c,b', len(h_rel), len(c_rel), len(b_rel))
rows = []; rowtag = []
for (hl, h) in h_rel:
    for (cl, c) in c_rel:
        if hl[1] + cl[1] != 0: continue
        for q in QGRID:
            K2c = Ops(S, q).K2(c); Eh = Ops(S, negq(q)).E(h)
            row = []
            for (name, i) in order:
                if name == 'HH': row.append(2 * Cv(name, i, h, K2c, q))
                elif name == 'CK': row.append(Cv(name, i, Eh, c, q))
                else: row.append(GQ(0))
            rows.append(row); rowtag.append(('hc', hl[2] if False else hl, cl))
for (bl, b) in b_rel:
    for (cl, c) in c_rel:
        if bl[1] + cl[1] != 0: continue
        for q in QGRID:
            C2Tb = Ops(S, negq(q)).C2T(b)
            row = []
            for (name, i) in order:
                if name == 'CB': row.append(Cv(name, i, b, c, q))
                elif name == 'CK': row.append(Cv(name, i, C2Tb, c, q))
                else: row.append(GQ(0))
            rows.append(row); rowtag.append(('bc', bl, cl))
log('ST rows', len(rows))
Z = nullspace(rows, N)
for z in Z: assert not any(apply(z, rows)), 'Z vector fails a complete row'
rk = N - len(Z)
res['ST'] = {'n_rows_complete': len(rows), 'rank': rk, 'Z_dim': len(Z), 'Z_verified_on_all_rows': True,
             'minor': minor_cert(rows, rk)}
log('Z', len(Z), 'rank', rk)
# ------------------------------------------------------------------ 3. (a) constant-profile (m=0) support analysis
K = [k for k, (nm, i) in enumerate(order) if basis[nm][i][0][2] == 0 and basis[nm][i][1][2] == 0]
res['K_constant_profile_coords'] = [res['basis_labels'][k] for k in K]
piK = [[z[k] for k in K] for z in Z]
rKZ = rref_rows(piK)[0] if piK else 0
res['Ward_combinations_supported_on_K'] = len(K) - rKZ
res['rank_piK_Z'] = rKZ
# rows from m=0 configurations only
rows0 = [row for row, tg in zip(rows, rowtag) if tg[1][2] == 0 and tg[2][2] == 0]
r0 = rref_rows(rows0)[0] if rows0 else 0
res['rank_rows_from_m0_configs'] = r0
# annihilator of Z supported on K: explicit basis
AnnK = nullspace(piK, len(K)) if piK else []
res['AnnK_dim'] = len(AnnK)
# are the m=0-config rows spanning AnnK?  (rows0 restricted to K must have rank = len(AnnK), and their support is in K)
supp_ok = all(not row[k] for row in rows0 for k in range(N) if k not in K)
res['m0_rows_supported_on_K'] = supp_ok
res['m0_rows_span_AnnK'] = (supp_ok and r0 == len(AnnK))
log('K', len(K), 'AnnK', len(AnnK), 'rank m0 rows', r0)
# Z restricted: which Z-coordinates are fixed by K data: dim(Z cap ker piK)
res['dim_Z_cap_ker_piK'] = len(Z) - rKZ
# ------------------------------------------------------------------ 4. exact directions B (gh -1), complete columns
XS = {'X1': ('h', 'cb', 3), 'X2': ('h', 'K', 3), 'X3': ('cs', 'c', 3)}
xb = {}
for nm, (F1, F2, T) in XS.items():
    cands = candidates(S, F1, F2, T); RA, RB = read_sets(cands, False)
    a1 = [a for a in ATOMS[F1] if nonzero_jets(a[1]) & RA]; a2 = [a for a in ATOMS[F2] if nonzero_jets(a[1]) & RB]
    cols = [(x, y, q) for x in a1 for y in a2 if x[0][1] + y[0][1] == 0 for q in QGRID]
    rws = [[eval_sym(c, x[1], y[1], q, False) for (x, y, q) in cols] for c in cands]
    r, piv, _ = rref_rows(rws); xb[nm] = [cands[i] for i in piv]
res['gh-1_dims'] = {k: len(v) for k, v in xb.items()}
log('gh-1', res['gh-1_dims'])
xorder = [(nm, i) for nm in XS for i in range(len(xb[nm]))]
def X(nm, i, a, b, q): return eval_sym(xb[nm][i], a, b, q, False)
def sigma_X(nm, i, sec, a, b, q):
    if nm == 'X1':
        if sec == 'CB': return -X(nm, i, Ops(S, q).K2(b), a, negq(q))
        if sec == 'HB': return X(nm, i, a, b, q)
        return GQ(0)
    if nm == 'X2':
        if sec == 'CK': return -X(nm, i, Ops(S, q).K2(b), a, negq(q))
        if sec == 'HH': return (X(nm, i, a, Ops(S, q).E(b), q) + X(nm, i, b, Ops(S, negq(q)).E(a), negq(q))) * inv(2)
        if sec == 'HB': return X(nm, i, a, Ops(S, q).C2T(b), q)
        return GQ(0)
    if nm == 'X3':
        if sec == 'CK': return X(nm, i, Ops(S, negq(q)).K2T(a), b, q)
        if sec == 'CB': return -X(nm, i, Ops(S, negq(q)).ghost(a), b, q)
        return GQ(0)
# complete gh0 columns for the image comparison: relevant atoms for basis reads and X reads (via the operators)
RX = {nm: read_sets(xb[nm], False) for nm in XS}
allX_A = set().union(*[RX[n][0] for n in XS]); allX_B = set().union(*[RX[n][1] for n in XS])
tg = allX_A | allX_B
o = o_gen; on = o_gen_n
relh = relevant('h', [lambda c: c, lambda c: o.E(c), lambda c: on.E(c)], RHH | tg)
relcb = relevant('cb', [lambda c: c], RCBA | tg)
relc = relevant('c', [lambda c: c, lambda c: o.K2(c), lambda c: on.K2(c)], RCBB | RCKB | tg)
relK = relevant('K', [lambda c: c, lambda c: on.K2T(c), lambda c: o.K2T(c)], RCKA | tg)
relb = relevant('b', [lambda c: c, lambda c: o.C2T(c), lambda c: on.C2T(c)], tg)
relcs = relevant('cs', [lambda c: c, lambda c: on.ghost(c), lambda c: o.ghost(c)], tg)
QG2 = QGRID
smp = []
for sec, A_, B_ in (('HH', relh, relh), ('CB', relcb, relc), ('CK', relK, relc), ('HB', relh, relb)):
    for (la, a) in A_:
        for (lb, b) in B_:
            if la[1] + lb[1] != 0: continue
            for q in QG2: smp.append((sec, a, b, q))
log('image columns', len(smp))
Mimg = [[sigma_X(nm, i, sec, a, b, q) for (sec, a, b, q) in smp] for (nm, i) in xorder]
Mbas = [[(Cv(name, i, a, b, q) if sec == name else GQ(0)) for (sec, a, b, q) in smp] for (name, i) in order]
hbc = [k for k, s in enumerate(smp) if s[0] == 'HB']
A_hb = [[Mimg[r][k] for r in range(len(xorder))] for k in hbc]
Xok = nullspace(A_hb, len(xorder))
imgs = [[sum((xv[r] * Mimg[r][k] for r in range(len(xorder))), GQ(0)) for k in range(len(smp))] for xv in Xok]
rB = rref_rows(imgs)[0] if imgs else 0
rBas = rref_rows(Mbas)[0]; rBoth = rref_rows(Mbas + imgs)[0]
res['basis_rank_on_image_columns'] = rBas
res['exact_dim_B'] = rB; res['B_in_candidate_span'] = (rBoth == rBas)
inZ = None; Bcoords = []
if rBoth == rBas:
    inZ = True
    MT = [list(t) for t in zip(*Mbas)]
    for vec in imgs:
        aug = [MT[k] + [-vec[k]] for k in range(len(smp))]
        ns = nullspace(aug, N + 1); sol = next((v for v in ns if v[-1]), None)
        if sol is None: inZ = False; break
        iv = inv(sol[-1]); y = [x * iv for x in sol[:-1]]; Bcoords.append(y)
        if any(apply(y, rows)): inZ = False; break
res['B_subset_Z'] = inZ
res['H0_dim'] = (len(Z) - rB) if inZ else None
res['Ward_constrained_count'] = N - len(Z)
log('B', rB, inZ, 'H0', res['H0_dim'])
# B coordinates restricted to K: which exact directions are visible in constant-profile data
if Bcoords:
    res['rank_piK_B'] = rref_rows([[y[k] for k in K] for y in Bcoords])[0]
res['seconds'] = round(time.time() - T0, 1)
store = {'Z_basis': [[x.tup() for x in z] for z in Z], 'B_coords': [[x.tup() for x in y] for y in Bcoords],
         'AnnK_basis': [[x.tup() for x in a] for a in AnnK], 'K': K}
tag = f"{str(alpha).replace('/', '_')}_{branch}"
json.dump(res, open(f'/workspace/XVI-O1-CONE/logs/v8/cert/apex_cert_{tag}.json', 'w'), indent=1)
json.dump(store, open(f'/workspace/XVI-O1-CONE/logs/v8/cert/apex_cert_{tag}_vectors.json', 'w'))
print(json.dumps({k: v for k, v in res.items() if k not in ('basis_labels', 'gh0')}, indent=1, default=str))
