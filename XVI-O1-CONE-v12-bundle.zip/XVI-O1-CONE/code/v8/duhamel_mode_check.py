"""v8 (b): numerical check of the per-mode Duhamel identity used for mixed-channel apex traces:
(mu^2-nu^2) int_0^1 dx Tr[e^{-x A_nu} r^{-2} e^{-(1-x) A_mu}] = Tr[e^{-A_nu}-e^{-A_mu}] = (mu-nu)/2.
Radial heat kernel k_nu(r,r';t)=(1/2t) exp(-(r^2+r'^2)/4t) I_nu(r r'/2t) on L^2(r dr). Numerical evidence only."""
import numpy as np, sys, json
from scipy.special import ive
from scipy import integrate
def k(nu, r, rp, t): return np.exp(-(r - rp)**2/(4*t))*ive(nu, r*rp/(2*t))/(2*t)
def T(nu, mu, x):
    f = lambda rp, r: r*rp*k(nu, r, rp, x)*k(mu, rp, r, 1 - x)/rp**2
    v, e = integrate.dblquad(f, 0, 40, 0, 40, epsabs=1e-10, epsrel=1e-8)
    return v
out = {}
for nu, mu in [(0.5, 1.5), (0.3, 1.3), (1.2, 2.2), (0.7, 2.4)]:
    xs, ws = np.polynomial.legendre.leggauss(16); xs = 0.5*(xs + 1); ws = 0.5*ws
    vals = [T(nu, mu, x) for x in xs]
    lhs = (mu**2 - nu**2)*sum(w*v for w, v in zip(ws, vals))
    out[str((nu, mu))] = {'lhs': lhs, 'rhs': (mu - nu)/2, 'profile_x': list(map(float, xs)), 'profile': [float((mu**2-nu**2)*v) for v in vals]}
    print(nu, mu, lhs, (mu - nu)/2, flush=True)
json.dump(out, open('/workspace/XVI-O1-CONE/logs/v8/duhamel_mode_check.json', 'w'), indent=1)
