"""v8 (a): support analysis of Z, B and the Ward annihilator on sub-blocks of the 12 constant-profile coordinates."""
import json, sys; sys.path.insert(0, '/workspace/XVI-O1-CONE/code/v8')
from fractions import Fraction as Fr
from gq import GQ
import apex_certificate_la as LA
tag = sys.argv[1]
d = json.load(open(f'/workspace/XVI-O1-CONE/logs/v8/cert/apex_cert_{tag}.json'))
v = json.load(open(f'/workspace/XVI-O1-CONE/logs/v8/cert/apex_cert_{tag}_vectors.json'))
P = lambda t: GQ(Fr(t[0]), Fr(t[1]))
Z = [[P(x) for x in z] for z in v['Z_basis']]; B = [[P(x) for x in y] for y in v['B_coords']]
lab = d['basis_labels']; K = v['K']
blocks = {s: [k for k in K if lab[k][0] == s] for s in ('HH', 'CB', 'CK', 'PP')}
blocks['HH+CK'] = blocks['HH'] + blocks['CK']; blocks['CB+CK'] = blocks['CB'] + blocks['CK']; blocks['K'] = K
out = {}
for nm, blk in blocks.items():
    rZ = LA.rank([[z[k] for k in blk] for z in Z]); rB = LA.rank([[y[k] for k in blk] for y in B])
    out[nm] = {'size': len(blk), 'rank_pi_Z': rZ, 'rank_pi_B': rB, 'Ward_combos_supported_here': len(blk) - rZ}
print(json.dumps(out, indent=1))
json.dump(out, open(f'/workspace/XVI-O1-CONE/logs/v8/cert/k_support_{tag}.json', 'w'), indent=1)
