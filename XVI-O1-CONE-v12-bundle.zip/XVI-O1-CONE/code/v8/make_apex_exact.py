"""v8: mechanically generate code/v8/apex_exact.py (exact Q(i)) from the historical code/apex_jets.py (read, never edited)."""
import re
src = open('/workspace/XVI-O1-CONE/code/apex_jets.py').read()
hdr = '''"""v8 EXACT port of code/apex_jets.py (historical file unchanged): every residue mod P is replaced by an exact
Gaussian rational in Q(i) (code/v8/gq.py); II = i exactly; inverses are exact.  Generated mechanically by
code/v8/make_apex_exact.py; the operator algebra is otherwise identical."""
'''
s = src
s = re.sub(r'pow\(([^,()]+(?:\([^()]*\))?), P - 2, P\)', r'inv(\1)', s)
s = s.replace('P - inv(', '-inv(').replace('P - 1,', '-1,').replace('P - 1]', '-1]')
s = s.replace(' % P', '')
s = s.replace('random.randrange(P)', 'random.randint(-9, 9)')
s = re.sub(r"def sqrtm1\(p\):.*?\n(?=P = )", "def sqrtm1(p): return GQ(0, 1)\n", s, flags=re.S)
s = s.replace("P = PRIMES[0]; II = sqrtm1(P)", "P = None; II = GQ(0, 1)")
s = re.sub(r"def setprime\(p\):\n    global P, II\n    P = p; II = sqrtm1\(p\)\n", "def setprime(p):\n    pass  # exact arithmetic: no prime\n", s)
s = re.sub(r"def fr\(x\):.*?\n.*?\n", "def fr(x):   # Fraction -> exact GQ\n    return GQ(Fr(x))\n", s, count=1)
s = s.replace("inv = inv(v[nz]); v = [x * inv for x in v]", "iv = inv(v[nz]); v = [x * iv for x in v]")
s = s.replace("inv = inv(M[r][c]); M[r] = [x * inv for x in M[r]]", "iv = inv(M[r][c]); M[r] = [x * iv for x in M[r]]")
s = s.replace("from fractions import Fraction as Fr\n", "from fractions import Fraction as Fr\nimport sys as _s; _s.path.insert(0, '/workspace/XVI-O1-CONE/code/v8')\nfrom gq import GQ, inv\n", 1)
assert ' P - ' not in s and 'pow(' not in s.replace('def sqrtm1', ''), 'residual modular construct'
open('/workspace/XVI-O1-CONE/code/v8/apex_exact.py', 'w').write(hdr + s)
print('written')
