"""Exact twisted Friedrichs / geometric-branch kernels on the cone (Euclidean, massless, 4D).
G_b(x,x') = S_b(eta/alpha, psi) / (8 pi^2 alpha r r' sinh eta),
S_b(u,psi) = f_b(u - i psi) + f_{1-b}(u + i psi),  f_b(z) = e^{-b z}/(1-e^{-z}).
For 0<=b<1 this is the Friedrichs mode sum sum_n e^{i(n+b)psi} e^{-|n+b|u};
for b outside [0,1) it is the 'geometric branch' (E0-type flips in the modes with sign change)."""
import mpmath as mp
def f(b,z): return mp.exp(-b*z)/(1-mp.exp(-z))
def S(b,u,psi): return f(b,u-1j*psi)+f(1-b,u+1j*psi)
def S_modes(b,u,psi,N=4000):
    # Friedrichs mode sum, b reduced mod 1
    b=b-mp.floor(b)
    return mp.nsum(lambda n: mp.exp(1j*(n+b)*psi-abs(n+b)*u),[-mp.inf,mp.inf])
def G(b,alpha,x,xp):
    """x=(tau,X,Y,z) developed Cartesian coordinates (lift: angle = atan2/alpha, small sector)"""
    t,X,Y,z=x; tp,Xp,Yp,zp=xp
    r=mp.sqrt(X*X+Y*Y); rp=mp.sqrt(Xp*Xp+Yp*Yp)
    th=mp.atan2(Y,X); thp=mp.atan2(Yp,Xp)
    psi=(thp-th)/alpha          # lift angle difference x -> x'
    ch=(r*r+rp*rp+(t-tp)**2+(z-zp)**2)/(2*r*rp)
    eta=mp.acosh(ch)
    return S(b,eta/alpha,psi)/(8*mp.pi**2*alpha*r*rp*mp.sinh(eta))
def Gflat(x,xp):
    return 1/(4*mp.pi**2*sum((a-b)**2 for a,b in zip(x,xp)))
