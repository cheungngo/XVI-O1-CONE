# Radial scan of the spin-2 Ward residual (I-B-G-S eq:gravityWard), CR (=bgeom) vs Friedrichs, copied/adapted from I-B-G-S/code/ward.py
import mpmath as mp,sys,json
mp.mp.dps=30
sys.path.insert(0,'/workspace/XVI-O1-CONE/code')
from tensor import *
al=mp.mpf(sys.argv[1]); mode=sys.argv[2]
br={'geom':bgeom,'fried':bfried}[mode]
xp=(mp.mpf("0.35"),mp.mpf("0.8"),mp.mpf("0.45"),mp.mpf("0.2"))
def dx(fun,i,pt): return mp.diff(lambda s: fun(tuple(pt[k]+(s if k==i else 0) for k in range(4))),0)
half=mp.mpf(1)/2
out={'alpha':str(al),'mode':mode,'scan':[]}
for rr in ["1.0","0.3","0.1","0.03","0.01"]:
    x=(mp.mpf("0.1"),mp.mpf(rr),mp.mpf("0.2"),mp.mpf("0.05"))
    def hbar(y,mu,nu,rho,sg):
        W=ten_kernel(al,y,xp,br); val=W[((mu,nu),(rho,sg))]
        if mu==nu: val-=half*sum(W[((l,l),(rho,sg))] for l in range(4))
        return val
    row={'r':rr}
    for (nu,rho,sg) in [(1,1,1),(2,2,2),(1,1,2)]:
        lhs=sum(dx(lambda y: hbar(y,mu,nu,rho,sg),mu,x) for mu in range(4))
        rhs=dx(lambda y: vec_kernel(al,x,y)[nu][sg],rho,xp)+dx(lambda y: vec_kernel(al,x,y)[nu][rho],sg,xp)
        row[str((nu,rho,sg))]=[mp.nstr(abs(lhs+rhs),6),mp.nstr(abs(rhs),6)]
    out['scan'].append(row); print(row,flush=True)
json.dump(out,open('/workspace/XVI-O1-CONE/logs/wardscan_%s_%s.json'%(sys.argv[1],mode),'w'),indent=1)
