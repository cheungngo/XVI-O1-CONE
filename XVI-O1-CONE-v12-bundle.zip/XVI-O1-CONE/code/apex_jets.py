"""Apex (worldsheet W) counterterm inventory and BRST cohomology on the cone C_alpha x R^2 (Euclidean), stage 1.

Fields near W are apex-polyhomogeneous spectral packets of the declared realization (I-B-G-S-v2 smooth packets):
component of helicity weight s, angular channel n:  u = sum_j c_j(t,z) r^(eps*nu+2j) e^{i a theta},  a = n/alpha + s,
nu=|a|, eps=-1 only in the curvature-regular E0 channels (s,n)=(+2,-1),(-2,+1) for alpha>1/2 (graviton and its
antifield K), eps=+1 otherwise (Friedrichs).  Jets J=(comp,n,m) carry dimension [F]+m.
An apex functional is  int_W  J1 . M(d_par) . J2  with n1+n2=0 (cone rotation), O(2)_par invariance (delta pairings,
no epsilon: reflection), phi-reflection invariance, Bose symmetry; power counting kappa^2 int_W: [F1]+m1+[F2]+m2+k=4.
Linear BRST (free gauge-fixed EH + b-field, frozen-gauge structure): s h=K2 c, s cb=b, s K=E h + C2^T b,
s c* = K2^T K - (C2 K2)^T cb ; s c = s b = s phi = 0.
Exact arithmetic mod two primes p=1 mod 4 (i = sqrt(-1) mod p); alpha a rational with large denominator (generic)."""
import itertools, random, json, sys
from fractions import Fraction as Fr

PRIMES = [1000000009, 998244353, 1000000021]
def sqrtm1(p):
    for g in range(2, 200):
        x = pow(g, (p - 1) // 4, p)
        if x * x % p == p - 1: return x
P = PRIMES[0]; II = sqrtm1(P)
def setprime(p):
    global P, II
    P = p; II = sqrtm1(p)
def fr(x):   # Fraction -> mod P
    x = Fr(x); return x.numerator % P * pow(x.denominator % P, P - 2, P) % P

# ---------------- components: name -> (weight, longitudinal rank)
VEC = {'L': (0, 1), 'P': (1, 0), 'M': (-1, 0)}
TEN = {'LL': (0, 2), 'PM': (0, 0), 'LP': (1, 1), 'LM': (-1, 1), 'PP': (2, 0), 'MM': (-2, 0)}
SCA = {'S': (0, 0)}
REFL = {'L': 'L', 'P': 'M', 'M': 'P', 'LL': 'LL', 'PM': 'PM', 'LP': 'LM', 'LM': 'LP', 'PP': 'MM', 'MM': 'PP', 'S': 'S'}
FIELDS = {  # name: (component table, dimension, kind)
    'h': (TEN, 1, 'graviton'), 'K': (TEN, 2, 'graviton'), 'c': (VEC, 1, 'vector'), 'cb': (VEC, 1, 'vector'),
    'b': (VEC, 2, 'vector'), 'cs': (VEC, 2, 'vector'), 'phi': (SCA, 1, 'scalar')}

class Setup:
    def __init__(self, alpha, branch, nmax=4, mcap=Fr(7, 2)):
        self.al = Fr(alpha); self.branch = branch; self.nmax = nmax; self.mcap = mcap
    def a(self, s, n): return Fr(n) / self.al + s
    def eps(self, kind, s, n):
        if kind == 'graviton' and self.branch == 'CR' and self.al > Fr(1, 2) and (s, n) in ((2, -1), (-2, 1)):
            return -1
        return 1
    def lattice_ok(self, kind, s, n, m):
        nu = abs(self.a(s, n)); e = self.eps(kind, s, n)
        d = (Fr(m) - e * nu) / 2
        return d.denominator == 1 and d >= 0
    def jets(self, F, dmax):
        comps, dim, kind = FIELDS[F]; out = []
        for C, (s, rk) in comps.items():
            for n in range(-self.nmax, self.nmax + 1):
                nu = abs(self.a(s, n)); e = self.eps(kind, s, n)
                j = 0
                while True:
                    m = e * nu + 2 * j
                    if dim + m > dmax: break
                    out.append((C, n, m)); j += 1
        return out

# ---------------- configurations: dict comp -> dict (n,m) -> coefficient tensor (flat tuple over 2^rank indices)
def zeros(rk): return [0] * (2 ** rk)
def rand_tensor(rk, sym):
    v = [random.randrange(P) for _ in range(2 ** rk)]
    if rk == 2 and sym: v[2] = v[1]
    return v
def add_into(cfg, C, key, vec, fac=1):
    d = cfg.setdefault(C, {}); cur = d.setdefault(key, zeros({1: 0, 2: 1, 4: 2}[len(vec)]))
    for i in range(len(vec)): cur[i] = (cur[i] + fac * vec[i]) % P
def scal(vec, f): return [x * f % P for x in vec]

class Ops:
    """flat parallel-frame operators acting on atom configurations; q = longitudinal momentum (mod P ints)"""
    def __init__(self, S, q): self.S = S; self.q = q
    def Dw(self, d, s):      # d: {(n,m):vec} for a component of weight s -> weight s-1
        out = {}
        for (n, m), v in d.items():
            c = fr((Fr(m) + self.S.a(s, n)) / 2)
            if c: out[(n, m - 1)] = scal(v, c)
        return out
    def Dwb(self, d, s):
        out = {}
        for (n, m), v in d.items():
            c = fr((Fr(m) - self.S.a(s, n)) / 2)
            if c: out[(n, m - 1)] = scal(v, c)
        return out
    # longitudinal derivative i q_a: rank r -> r+1 (new index FIRST)
    def Dl(self, d):
        out = {}
        for k, v in d.items():
            r = {1: 0, 2: 1, 4: 2}[len(v)]
            w = []
            for a in range(2):
                w += [II * self.q[a] % P * x % P for x in v]
            out[k] = w
        return out
    def contract_first(self, d):   # sum_a  T[a, a, ...] for rank>=2 (first two indices)
        out = {}
        for k, v in d.items():
            n = len(v) // 4
            out[k] = [(v[0 * 2 * n + 0 * n + i] + v[1 * 2 * n + 1 * n + i]) % P for i in range(n)]
        return out
    @staticmethod
    def addd(*ds, facs=None):
        out = {}
        for i, d in enumerate(ds):
            f = 1 if facs is None else facs[i]
            for k, v in d.items():
                cur = out.setdefault(k, [0] * len(v))
                for j in range(len(v)): cur[j] = (cur[j] + f * v[j]) % P
        return out
    @staticmethod
    def sc(d, f): return {k: scal(v, f % P) for k, v in d.items()}
    @staticmethod
    def swap01(d):   # transpose first two indices of rank-2
        return {k: [v[0], v[2], v[1], v[3]] for k, v in d.items()}
    # --- scalar/vector/tensor operators
    def grad(self, f):   # scalar comp dict -> vector
        return {'L': self.Dl(f.get('S', {})), 'P': self.sc(self.Dwb(f.get('S', {}), 0), 2), 'M': self.sc(self.Dw(f.get('S', {}), 0), 2)}
    def divv(self, V):
        return {'S': self.addd(self.contract_first_vec(self.Dl(V.get('L', {}))), self.Dwb(V.get('M', {}), -1), self.Dw(V.get('P', {}), 1))}
    def contract_first_vec(self, d):  # rank2 from Dl of rank1: sum_a T[a,a]
        return {k: [(v[0] + v[3]) % P] for k, v in d.items()}
    def K2(self, c):
        cL = c.get('L', {}); cP = c.get('P', {}); cM = c.get('M', {})
        dL = self.Dl(cL)                       # [a][b] = i q_a c_b
        LL = self.addd(dL, self.swap01(dL))
        LP = self.addd(self.Dl(cP), self.sc(self.Dwb(cL, 0), 2))
        LM = self.addd(self.Dl(cM), self.sc(self.Dw(cL, 0), 2))
        PP = self.sc(self.Dwb(cP, 1), 4); MM = self.sc(self.Dw(cM, -1), 4)
        PM = self.addd(self.sc(self.Dwb(cM, -1), 2), self.sc(self.Dw(cP, 1), 2))
        return {'LL': LL, 'LP': LP, 'LM': LM, 'PP': PP, 'MM': MM, 'PM': PM}
    def divt(self, X):   # (div X)_nu = d_a X_{a nu} + dwb X_{- nu} + dw X_{+ nu}
        LL = X.get('LL', {}); LP = X.get('LP', {}); LM = X.get('LM', {}); PP = X.get('PP', {}); MM = X.get('MM', {}); PM = X.get('PM', {})
        L = self.addd(self.contract_first(self.Dl(LL)), self.Dwb(LM, -1), self.Dw(LP, 1))
        Pp = self.addd(self.contract_first_vec(self.Dl(LP)), self.Dwb(PM, 0), self.Dw(PP, 2))
        Mm = self.addd(self.contract_first_vec(self.Dl(LM)), self.Dwb(MM, -2), self.Dw(PM, 0))
        return {'L': L, 'P': Pp, 'M': Mm}
    def tr(self, X):
        LL = X.get('LL', {})
        t = {k: [(v[0] + v[3]) % P] for k, v in LL.items()}
        return {'S': self.addd(t, X.get('PM', {}))}
    def gtimes(self, f):  # metric times scalar: LL=delta f, PM = 2 f
        fs = f.get('S', {})
        return {'LL': {k: [v[0], 0, 0, v[0]] for k, v in fs.items()}, 'PM': self.sc(fs, 2)}
    def tadd(self, *Xs, facs=None):
        out = {}
        for i, X in enumerate(Xs):
            f = 1 if facs is None else facs[i]
            for C, d in X.items():
                out[C] = self.addd(out.get(C, {}), d, facs=[1, f])
        return out
    def box(self, X, wt):   # wt: comp->weight
        q2 = (self.q[0] * self.q[0] + self.q[1] * self.q[1]) % P
        out = {}
        for C, d in X.items():
            s = wt[C]
            out[C] = self.addd(self.sc(d, -q2), self.sc(self.Dw(self.Dwb(d, s), s + 1), 4))
        return out
    def Ptr(self, X):
        return self.tadd(X, self.gtimes(self.tr(X)), facs=[1, P - pow(2, P - 2, P)])
    def E(self, h):
        wt = {C: TEN[C][0] for C in TEN}
        dv = self.divt(h); th = self.tr(h)
        dd = self.divv(dv); bt = self.box(th, {'S': 0})
        return self.tadd(self.box(h, wt), self.K2(dv), self.K2(self.grad(th)), self.gtimes(dd), self.gtimes(bt),
                         facs=[1, P - 1, pow(2, P - 2, P), 1, P - 1])
    def C2(self, h): return self.divt(self.Ptr(h))
    def C2T(self, b): return self.tadd(self.Ptr(self.K2(b)), facs=[P - pow(2, P - 2, P)])
    def K2T(self, K): return {C: self.sc(d, -2) for C, d in self.divt(K).items()}
    def ghost(self, c): return self.C2(self.K2(c))
    def Ric(self, h):
        dv = self.divt(h); th = self.tr(h); wt = {C: TEN[C][0] for C in TEN}
        return self.tadd(self.K2(dv), self.box(h, wt), self.K2(self.grad(th)), facs=[pow(2, P - 2, P), P - pow(2, P - 2, P), P - pow(4, P - 2, P)])

def rand_cfg(S, F, dmax):
    comps, dim, kind = FIELDS[F]; cfg = {}
    for (C, n, m) in S.jets(F, dmax):
        rk = comps[C][1]
        cfg.setdefault(C, {})[(n, m)] = rand_tensor(rk, C == 'LL')
    return cfg

def foreign(S, F, cfg):
    """atoms of cfg (a field of type F) outside F's realization lattice"""
    comps, dim, kind = FIELDS[F]; bad = []
    for C, d in cfg.items():
        s = comps[C][0]
        for (n, m), v in d.items():
            if any(v) and not S.lattice_ok(kind, s, n, m): bad.append((C, n, str(m)))
    return bad

def reflect(cfg):
    return {REFL[C]: {(-n, m): list(v) for (n, m), v in d.items()} for C, d in cfg.items()}

# ---------------- candidate functionals
def pairings(slots):
    if not slots: yield []; return
    a = slots[0]
    for i in range(1, len(slots)):
        rest = slots[1:i] + slots[i + 1:]
        for pr in pairings(rest): yield [(a, slots[i])] + pr

def candidates(S, F1, F2, T):
    c1, d1, _ = FIELDS[F1]; c2, d2, _ = FIELDS[F2]; out = []
    J1 = S.jets(F1, T); J2 = S.jets(F2, T)   # v2: cap T (a CR-flipped partner can have m in (-1,0)); k>=0 enforces the budget
    for (C1, n1, m1) in J1:
        for (C2, n2, m2) in J2:
            if n1 + n2 != 0: continue
            k = Fr(T) - d1 - m1 - d2 - m2
            if k.denominator != 1 or k < 0: continue
            k = int(k); r1 = c1[C1][1]; r2 = c2[C2][1]
            slots = [('A', i) for i in range(r1)] + [('B', i) for i in range(r2)] + [('p', i) for i in range(k)]
            if len(slots) % 2: continue
            seen = set()
            for pr in pairings(slots):
                key = tuple(sorted(tuple(sorted((x[0], x[1] if x[0] != 'p' else 0) for x in pair)) for pair in pr))
                if key in seen: continue
                seen.add(key); out.append(((C1, n1, m1), (C2, n2, m2), r1, r2, k, pr))
    return out

def eval_cand(cand, cfg1, cfg2, q):
    (C1, n1, m1), (C2, n2, m2), r1, r2, k, pr = cand
    v1 = cfg1.get(C1, {}).get((n1, m1)); v2 = cfg2.get(C2, {}).get((n2, m2))
    if v1 is None or v2 is None: return 0
    tot = 0
    for idx in itertools.product(range(2), repeat=r1 + r2 + k):
        A = idx[:r1]; B = idx[r1:r1 + r2]; Pp = idx[r1 + r2:]
        lab = {('A', i): A[i] for i in range(r1)}; lab.update({('B', i): B[i] for i in range(r2)}); lab.update({('p', i): Pp[i] for i in range(k)})
        if any(lab[x] != lab[y] for x, y in pr): continue
        ia = 0
        for i in A: ia = ia * 2 + i
        ib = 0
        for i in B: ib = ib * 2 + i
        t = v1[ia] * v2[ib] % P
        for i in Pp: t = t * q[i] % P
        tot = (tot + t) % P
    return tot

def negq(q): return [(-x) % P for x in q]

def eval_sym(cand, cfg1, cfg2, q, bose):
    v = (eval_cand(cand, cfg1, cfg2, q) + eval_cand(cand, reflect(cfg1), reflect(cfg2), q)) % P
    if bose:
        v = (v + eval_cand(cand, cfg2, cfg1, negq(q)) + eval_cand(cand, reflect(cfg2), reflect(cfg1), negq(q))) % P
    return v

# ---------------- modular linear algebra
def rank_and_basis(rows):
    """rows: list of vectors (mod P). returns rank and pivot row indices (independent subset)"""
    M = [list(r) for r in rows]; piv = []; R = []
    for i, r in enumerate(M):
        v = list(r)
        for (pc, prow) in R:
            if v[pc]:
                f = v[pc]
                v = [(x - f * y) % P for x, y in zip(v, prow)]
        nz = next((j for j, x in enumerate(v) if x), None)
        if nz is not None:
            inv = pow(v[nz], P - 2, P); v = [x * inv % P for x in v]
            R.append((nz, v)); piv.append(i)
    return len(R), piv

def nullspace(A, ncols):
    """A: list of rows (mod P). returns basis of {x: A x = 0}"""
    M = [list(r) for r in A]; pivcols = []; r = 0
    for c in range(ncols):
        pr = next((i for i in range(r, len(M)) if M[i][c]), None)
        if pr is None: continue
        M[r], M[pr] = M[pr], M[r]
        inv = pow(M[r][c], P - 2, P); M[r] = [x * inv % P for x in M[r]]
        for i in range(len(M)):
            if i != r and M[i][c]:
                f = M[i][c]; M[i] = [(x - f * y) % P for x, y in zip(M[i], M[r])]
        pivcols.append(c); r += 1
        if r == len(M): break
    free = [c for c in range(ncols) if c not in pivcols]; basis = []
    for fcol in free:
        x = [0] * ncols; x[fcol] = 1
        for i, pc in enumerate(pivcols): x[pc] = (-M[i][fcol]) % P
        basis.append(x)
    return basis
