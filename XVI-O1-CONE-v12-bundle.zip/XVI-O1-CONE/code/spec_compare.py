"""compare spectral constant-profile results with coincidence-route (tadpole2) constant-constant terms; S=0 externals only."""
import json, sys, sympy as sp
q0,q3=sp.symbols('q0 q3')
names=['a0','b0','c0','f0']
def bil(S, tag1='_1', tag2='_2'):
    a=[sp.Symbol(n+tag1) for n in names]; b=[sp.Symbol(n+tag2) for n in names]
    H1={0:a[0],3:a[1],9:a[2],4:a[3],7:a[3]}; H2={0:b[0],3:b[1],9:b[2],4:b[3],7:b[3]}
    B=0
    for k,v in S.items():
        x,y=eval(k)
        if x in H1 and y in H2: B+=sp.sympify(v)*H1[x]*H2[y]
    return sp.expand(B.subs({q0:sp.Symbol('p0'),q3:sp.Symbol('p3')}))
def tadconst(T):
    V=T['vars']; keep={n+t for n in names for t in ('_1','_2')}|{'p0','p3'}
    Tt=0
    for k,v in T['pole_bilinear'].items():
        idx=eval(k)
        if all((e==0 or V[i] in keep) for i,e in enumerate(idx)):
            Tt+=sp.sympify(v)*sp.prod([sp.Symbol(V[i])**e for i,e in enumerate(idx)])
    return sp.expand(Tt)
if __name__=='__main__':
    g=sys.argv[1]
    for br in ['CR','F']:
        S=json.load(open(f'logs/v4/spec_{g}_{br}.json'))['Gamma_pole_coeff_of_1/(4-d)']
        tf=f'logs/v3/tad2fast_{g}_{br}.json' if g=='D02' else f'logs/v3/tad2_{g}_CR.json'
        T=json.load(open(tf))
        B=bil(S); Tt=tadconst(T)
        print(g,br,'spectral terms',len(sp.Add.make_args(B)),'coincidence terms',len(sp.Add.make_args(Tt)),'difference:',sp.simplify(B-Tt))
