"""v11 item (1): F(mu,nu) = int_0^1 T_1(x;mu,nu) dx with the corrected T_1 (code/v11/t1v11.py); tanh-sinh, dps 30,
endpoint limits T_1(0)=mu(mu^2-1)/3, T_1(1)=nu(nu^2-1)/3. Cache: logs/v11/M10/cache/<mu>__<nu>.json (exact rationals).
Usage: m10_eval.py mu nu   (mu, nu as fractions)."""
import sys, os, json, time
from fractions import Fraction as Fr
sys.path.insert(0, '/workspace/XVI-O1-CONE/code/v11')
import mpmath as mp, t1v11 as T
mp.mp.dps = 30
def key(m, n): return f"{m}__{n}".replace('/', '_')
D = '/workspace/XVI-O1-CONE/logs/v11/M10/cache'
def F(mu, nu):
    f = os.path.join(D, key(mu, nu) + '.json')
    if os.path.exists(f): return mp.mpf(json.load(open(f))['F'])
    if os.path.exists(os.path.join(D, key(nu, mu) + '.json')): return mp.mpf(json.load(open(os.path.join(D, key(nu, mu) + '.json')))['F'])  # F symmetric
    m = mp.mpf(mu.numerator)/mu.denominator; n = mp.mpf(nu.numerator)/nu.denominator
    if mu == nu: return m*(m*m-1)/3   # exact diagonal (scheme Z per-mode value); covers (0,0)
    eps = mp.mpf(10)**-22
    def g(x):
        # v11 fix 3: evaluate the half x>1/2 by the symmetry T1(x;mu,nu) = T1(1-x;nu,mu) (cancellation near x=1 at fixed dps),
        # and raise the working precision near the endpoint (loss ~ 1.5 digits per decade of x).
        if x > mp.mpf(1)/2: y, a, b = 1 - x, n, m
        else: y, a, b = x, m, n
        if y < eps: return a*(a*a-1)/3
        extra = int(1.5*max(0, -mp.log10(y))) + 5
        with mp.workdps(30 + extra):
            return +T.T1(y, a, b, K=56)
    t0 = time.time(); v = mp.quad(g, [0, mp.mpf(1)/2, 1], maxdegree=4)   # v11: degree 4 (test at (97/3,100/3): degrees 3/4/5 agree to 3e-23 rel.; higher degrees only chase integrand noise)
    json.dump({'mu': str(mu), 'nu': str(nu), 'F': mp.nstr(v, 28), 'sec': round(time.time()-t0, 1)}, open(f, 'w'))
    return v
if __name__ == '__main__':
    print(sys.argv[1], sys.argv[2], F(Fr(sys.argv[1]), Fr(sys.argv[2])), flush=True)
