#!/bin/bash
cd /workspace/XVI-O1-CONE
cat logs/v11/M10/jobs_dedup.txt | xargs -P 7 -L 1 sh -c 'python3 code/v11/m10_eval.py $0 $1 >> logs/v11/M10/driver.log 2>&1'
echo ALLDONE >> logs/v11/M10/driver.log
