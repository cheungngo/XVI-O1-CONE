"""list of (mu,nu) needed for M10 in pairings P0 (same-k, helicity frame) and P1 (unit angular-momentum shift = frame intertwiner)."""
from fractions import Fraction as Fr
AL = [Fr(3, 10), Fr(7071, 10000), Fr(1, 2), Fr(1)]
KS = list(range(0, 20)) + list(range(20, 58, 2))
def fam(al, P):
    out = {}
    for k in KS:
        if P == 'P0':
            out[('pos', k)] = ((k + al)/al, Fr(k)/al)
            if k >= 1: out[('neg', k)] = ((k - al)/al, Fr(k)/al)
        else:
            out[('pos', k)] = ((k + al)/al, Fr(k + 1)/al)
            if k >= 1: out[('neg', k)] = (abs(al - k)/al, Fr(abs(1 - k))/al)
    return out
if __name__ == '__main__':
    s = set()
    for al in AL:
        for P in ('P0', 'P1'):
            for v in fam(al, P).values(): s.add(v)
    for m, n in sorted(s, key=lambda t: t[0] + t[1]): print(m, n)
