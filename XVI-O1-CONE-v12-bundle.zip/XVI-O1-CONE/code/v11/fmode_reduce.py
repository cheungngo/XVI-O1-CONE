"""v11 item (5), partial: exact reduction of the F mode. For nu = 2-mu (h=1, d=2mu-2) both 2F1 factors of Prop. v9g are
incomplete Beta functions: with w(s)=s^{mu-1}(1-s)^{1-mu}, W(x)=int_0^x w, W1=W(1)=Gamma(mu)Gamma(2-mu),
   g(x;mu,2-mu) = W(x)(W1-W(x)) / (4 W1 x(1-x) w(x)),
   I_F = -4(mu-1) int R g = -((mu-1)/W1) int_0^1 (3-2x) W(x)(W1-W(x))/w(x) dx = -(mu-1)[A(mu) - B(mu)/W1],
   A = int (3-2x) W/w dx = (1/mu) sum_n (n+1)!/(mu+1)_n int (3-2x) x^{n+1}(1-x) dx   (Gamma series, CR type),
   B = int (3-2x) W^2/w dx.   Checked numerically against the v10 closed form."""
import mpmath as mp, json
mp.mp.dps = 30
out = {}
for m in ['7/4', '5/4', '3/2']:
    p, q = map(int, m.split('/')); mu = mp.mpf(p)/q
    w = lambda s: s**(mu-1)*(1-s)**(1-mu)
    W = lambda x: mp.betainc(mu, 2-mu, 0, x)
    W1 = mp.gamma(mu)*mp.gamma(2-mu)
    A = mp.quad(lambda x: (3-2*x)*W(x)/w(x), [0, 1])
    Aser = mp.nsum(lambda n: mp.factorial(n+1)/mp.rf(mu+1, n)*(3/((n+2)*(n+3)) - 2/((n+3)*(n+4)) ), [0, mp.inf])/mu
    B = mp.quad(lambda x: (3-2*x)*W(x)**2/w(x), [0, 1])
    IF = -(mu-1)*(A - B/W1)
    closed = (mu-1)*(59*mu**3-57*mu**2-62*mu+48)/36 - (mu-1)**3*(mu+1)*mp.pi**2/6
    out[m] = {'A_quad': mp.nstr(A, 20), 'A_series': mp.nstr(Aser, 20), 'I_F_reduced': mp.nstr(IF, 22), 'I_F_closed_v10': mp.nstr(closed, 22), 'diff': mp.nstr(abs(IF-closed), 3)}
    print(m, out[m], flush=True)
json.dump(out, open('/workspace/XVI-O1-CONE/logs/v11/fmode_reduce.json', 'w'), indent=1)
