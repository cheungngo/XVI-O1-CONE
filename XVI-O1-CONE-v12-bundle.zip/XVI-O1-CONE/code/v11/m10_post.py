"""v11: post-processing of logs/v11/M10/m10.json -> logs/v11/M10/m10_text.tex (interpretive paragraph with numbers only from json),
plus the leading-asymptotics check c_0 = alpha^{-3}/3 (u=k or u=alpha h) predicted by F ~ h(h^2-1)/3."""
import json
from fractions import Fraction as Fr
import mpmath as mp
mp.mp.dps = 30
import re
def tx(x):  # nstr -> LaTeX
    return re.sub(r'e([+-]?)0*(\d+)', lambda m: r'\times10^{%s%s}' % ('-' if m.group(1) == '-' else '', m.group(2)), x)
M = json.load(open('/workspace/XVI-O1-CONE/logs/v11/M10/m10.json'))
import glob
bad = []; nok = 0
for f in glob.glob('/workspace/XVI-O1-CONE/logs/v11/M10/cache/*.json'):
    d = json.load(open(f)); m, n = Fr(d['mu']), Fr(d['nu']); F = mp.mpf(d['F'])
    a, b = m*(m*m-1)/3, n*(n*n-1)/3; lo, hi = min(a, b), max(a, b)
    if mp.mpf(lo.numerator)/lo.denominator - 1e-12 <= F <= mp.mpf(hi.numerator)/hi.denominator + 1e-12: nok += 1
    else: bad.append([d['mu'], d['nu'], d['F']])
json.dump({'n_ok': nok, 'n_bad': len(bad), 'bad': bad}, open('/workspace/XVI-O1-CONE/logs/v11/M10/m10_sanity.json', 'w'), indent=1)
lead = {}
for tag, v in M.items():
    if 'leading_c_pos' not in v: continue
    al = Fr(tag.split('|')[0]); reg = tag.split('|')[2]
    pred = mp.mpf(al.denominator**3)/al.numerator**3/3   # u = k or u = alpha*h: both give c_0 = alpha^{-3}/3
    lead[tag] = {s: mp.nstr(abs(mp.mpf(v[f'leading_c_{s}'][0]) - pred)/pred, 3) for s in ('pos', 'neg')}
json.dump(lead, open('/workspace/XVI-O1-CONE/logs/v11/M10/m10_leading.json', 'w'), indent=1)
worst = max(float(x) for d in lead.values() for x in d.values()) if lead else None
def g(t, k='M10_FP'): return M[t][k] if t in M and k in M[t] else None
lines = []
lines.append(r'\paragraph{Reading of Table~\ref{tab:v11M10}.} The leading fitted coefficient agrees with the prediction '
             r'\(c_0=\alpha^{-3}/3\) (for \(u=k\) and for \(u=\alpha h\)) from \(F\sim h(h^2-1)/3\) to relative '
             + (r'\(%s\)' % tx(mp.nstr(worst, 2)) if worst is not None else 'n/a') + r' in every family (\loc{logs/v11/M10/m10_leading.json}). '
             r'This is the only analytic input to the asymptotics; the subleading coefficients are fitted, not derived.')
diffs = []
for al in ('3/10', '7071/10000'):
    a, b = g(f'{al}|P0|Rh'), g(f'{al}|P1|Rh')
    if a and b: diffs.append(r'\(%s\): \(%s\)' % (al, tx(mp.nstr(mp.mpf(b) - mp.mpf(a), 8))))
if diffs:
    lines.append(r'The intertwiner choice is not a small effect: \(M_{10}^{\rm P1}-M_{10}^{\rm P0}\) under \(R_h\) is ' + '; '.join(diffs) + '.')
a, b = g('1/2|P0|Rh'), g('1/2|P1|Rh')
if a and b:
    lines.append(r'At \(\alpha=\tfrac12\) the P1 pairs \((2k+1,2k+2)\) are, after reindexing, the P0 pairs of the negative family and vice versa, so the two pairings must agree under the label-based regulator \(R_h\) (not under \(R_k\)). They agree to \(%s\), a non-trivial check of the head/tail machinery on non-exact data.' % tx(mp.nstr(abs(mp.mpf(a)-mp.mpf(b)), 2)))
pl = {t: v['pole_coeff_1/eps'] for t, v in M.items() if '|P0|' in t and 'pole_coeff_1/eps' in v}
dev = max(abs(mp.mpf(v) + mp.mpf(Fr(t.split('|')[0]).numerator)/Fr(t.split('|')[0]).denominator/40) for t, v in pl.items())
lines.append(r'The P0 pole coefficient equals \(-\alpha/40\) at all four angles and for both regulators, to \(%s\) (identified numerically, not derived).' % tx(mp.nstr(dev, 2)))
lines.append(r'The pole coefficients are nonzero in general; a declared minimal subtraction of the \(1/\epsilon\) term is part of the finite-part definition.')
open('/workspace/XVI-O1-CONE/logs/v11/M10/m10_text.tex', 'w').write('\n'.join(lines) + '\n')
print('\n'.join(lines)); print(lead)
