"""v11 item (4): machine check of the degree bound (D).
The row entries are eval_sym(candidate, X, Y, q) with candidates = pivot candidates (a selection, no alpha-dependent
combination; code/v10/minor_poly.make_basis) and X,Y in {unit atom, K2 c, E(-q) h, C2^T(-q) b}; eval_cand is multilinear in
the atom values and polynomial in q only.  The ONLY alpha-dependence of the operator algebra (code/v8/apex_exact.py) is the
coefficient (m +- a(s,n))/2 in Dw/Dwb, with a = n t + s, t = 1/alpha, and the jet label m = eps |a| + 2j (+ shifts).
Here the operators are re-run with sympy values and SYMBOLIC t (sign of a fixed by the chamber representative alpha0), on
every unit atom of h, c, b used by the rows, at a generic symbolic momentum, and the exact degree in t of every output
coefficient is recorded.  Also checks that the numeric label m of every output matches the symbolic label at t=1/alpha0."""
import sys, json, itertools
from fractions import Fraction as Fr
sys.path.insert(0, '/workspace/XVI-O1-CONE/code/v8')
import sympy as sp
import apex_exact as AE
t, Q0, Q1 = sp.symbols('t q0 q1')
AE.II = sp.I
AE.fr = lambda x: sp.sympify(x)
AE.inv = lambda x: sp.Rational(1, x)
class SymOps(AE.Ops):
    def __init__(self, S, q, sgn): super().__init__(S, q); self.sgn = sgn
    def _c(self, s, n, m, pm):
        # m is a symbolic label expression in t
        return sp.expand((m + pm*(n*t + s))/2)
    def Dw(self, d, s):
        out = {}
        for (n, m), v in d.items():
            c = self._c(s, n, m, 1)
            if c != 0: out[(n, sp.expand(m - 1))] = [sp.expand(x*c) for x in v]
        return out
    def Dwb(self, d, s):
        out = {}
        for (n, m), v in d.items():
            c = self._c(s, n, m, -1)
            if c != 0: out[(n, sp.expand(m - 1))] = [sp.expand(x*c) for x in v]
        return out
def unit_atoms(S, F, dmax, al0):
    comps, dim, kind = AE.FIELDS[F]; out = []
    for (C, n, m) in S.jets(F, dmax):
        s, rk = comps[C]; e = S.eps(kind, s, n)
        a0 = Fr(n)/al0 + s; sg = 1 if a0 > 0 else (-1 if a0 < 0 else 0)
        j = (Fr(m) - e*abs(a0))/2
        msym = sp.expand(e*sg*(n*t + s) + 2*j)
        assert msym.subs(t, sp.Rational(al0.denominator, al0.numerator)) == m
        for i in range(2**rk):
            if C == 'LL' and i == 2: continue
            v = [0]*(2**rk); v[i] = 1
            if C == 'LL' and i == 1: v[2] = 1
            out.append(((C, n, str(m), i), {C: {(n, msym): v}}))
    return out
def deg(cfg):
    d = -1; nz = 0
    for C, dd in cfg.items():
        for k, v in dd.items():
            for x in v:
                x = sp.expand(x)
                if x != 0:
                    nz += 1; d = max(d, sp.Poly(x, t).degree())
    return d, nz
res = {}
for tag, al0, br in [('CR_c1', Fr(3, 10), 'CR'), ('CR_c2', Fr(41, 100), 'CR'), ('CR_c3', Fr(3, 5), 'CR'), ('CR_c4', Fr(7071, 10000), 'CR'),
                     ('F_c1', Fr(3, 10), 'F'), ('F_c2', Fr(41, 100), 'F'), ('F_c3', Fr(3, 5), 'F'), ('F_c4', Fr(7071, 10000), 'F')]:
    S = AE.Setup(al0, br)
    o = SymOps(S, [Q0, Q1], None); on = SymOps(S, [-Q0, -Q1], None)
    out = {'K2c': [-1, 0], 'E_h': [-1, 0], 'C2Tb': [-1, 0]}
    for F, op, name in (('c', o.K2, 'K2c'), ('h', on.E, 'E_h'), ('b', on.C2T, 'C2Tb')):
        dmax = 6
        for lab, cfg in unit_atoms(S, F, dmax, al0):
            dg, nz = deg(op(cfg))
            out[name][0] = max(out[name][0], dg); out[name][1] += 1
    res[tag] = out; print(tag, out, flush=True)
res['bound_D_holds'] = all(v[n][0] <= 2 for k, v in res.items() if isinstance(v, dict) for n in v)
json.dump(res, open('/workspace/XVI-O1-CONE/logs/v11/degree_check.json', 'w'), indent=1); print(res['bound_D_holds'])
