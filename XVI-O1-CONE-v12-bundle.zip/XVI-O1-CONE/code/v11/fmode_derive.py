"""v11 item (5): derivation of the F mode I_F(mu) (nu = 2-mu), replacing the v10 PSLQ identification.
Steps (all exact):
 (i)  g(x;mu,2-mu) = W(W1-W)/(4 W1 x(1-x) w),  w = x^{mu-1}(1-x)^{1-mu},  W = int_0^x w,  W1 = Gamma(mu)Gamma(2-mu)
      [both 2F1 of Prop. v9g are incomplete Beta functions:  2F1(a,a-1;a+1;x) = a x^{-a} B_x(a,2-a)].
 (ii) I_F = -4(mu-1) int (3-2x) x(1-x) g = -(mu-1)/W1 int (3-2x) W (W1-W)/w = -(mu-1) A + (mu-1) B/W1,
      A = int (3-2x) W/w = (1/mu) sum (n+1)! K_n/(mu+1)_n = -I_CR/(mu-1)   (W/w = x(1-x) 2F1(2,1;mu+1;x)/mu), so
      I_F = I_CR + (mu-1) B/W1,  B = int (3-2x) W^2/w.
 (iii) (x(1-x)/w)' = (2-mu-2x)/w  =>  B = -2 int x(1-x) W + (1+mu) C,  C = int W^2/w;
      int x(1-x) W = W1 E,  E = 1/6 - mu(mu+1)/12 + mu(mu+1)(mu+2)/72.
 (iv) C/W1 = (1/mu) sum_n a_n [1/(n+2)-1/(n+3)] - sum_n (mu+n+1)/((n+2)^2(n+3)) + sum_n (mu+n+1)(mu+n+2)/((n+2)(n+3)^2(n+4)),
      a_n = (n+1)!/(mu+1)_n, using int W x^m = W1 (1 - (mu)_{m+1}/(m+2)!)/(m+1); the a_n sums are the v10 G_b."""
import sympy as sp, mpmath as mp, json, sys
mu, e, Ps, T, g = sp.symbols('mu epsilon Psi T gamma_E'); be = mu - 1
exec(open('/workspace/XVI-O1-CONE/code/v10/cr_mode_closed.py').read().split('Gs = {b: G(b)')[0].split('import sympy as sp, mpmath as mp, json, sys')[1].replace("mu, e, Ps, T, g = sp.symbols('mu epsilon Psi T gamma_E'); be = mu - 1", ''))
G2, G3, G4 = G(2), G(3), G(4)
n = sp.symbols('n', integer=True, nonnegative=True)
Kn = sp.Rational(2)/(n+4) - sp.Rational(5)/(n+3) + sp.Rational(3)/(n+2)
I_cr = sp.expand(-(mu-1)**2*(2*G4 - 5*G3 + 3*G2))           # v10 (T = psi1(mu-1), Ps = psi(mu-1))
Sa = mu*(mu-1)*(G2 - G3)                                       # sum a_n (1/(n+2) - 1/(n+3))
def rsum(expr):
    # sum_{n>=0} of a rational function: apart into c/(n+a)^k; k=1 terms (coefficients summing to 0) give -c psi(a), k>=2 give c psi_{k-1}(a)(-1)^k/(k-1)!
    p = sp.apart(sp.together(expr), n); tot = 0; c1 = 0
    for term in sp.Add.make_args(p):
        num, den = sp.fraction(sp.factor(term)); base = sp.Poly(den, n)
        (lin, k), = sp.factor_list(den)[1]; a = sp.Poly(lin, n).all_coeffs(); assert a[0] == 1 or a[0] == -1
        c = sp.simplify(num/sp.factor_list(den)[0]/a[0]**k); a0 = a[1]/a[0]
        if k == 1: tot += -c*sp.polygamma(0, a0); c1 += c
        else: tot += c*(-1)**k*sp.polygamma(k-1, a0)/sp.factorial(k-1)
    assert sp.simplify(c1) == 0
    return sp.simplify(sp.expand_func(tot))
R1 = rsum((mu+n+1)/((n+2)**2*(n+3))); R2 = rsum((mu+n+1)*(mu+n+2)/((n+2)*(n+3)**2*(n+4)))
C_W1 = sp.expand(Sa/mu - R1 + R2)
E = sp.Rational(1, 6) - mu*(mu+1)/12 + mu*(mu+1)*(mu+2)/72
B_W1 = sp.expand(-2*E + (1+mu)*C_W1)
I_F = sp.expand(I_cr + (mu-1)*B_W1)
assert sp.simplify(I_F.coeff(g)) == 0 and sp.simplify(I_F.coeff(Ps)) == 0
I_F = sp.simplify(I_F.subs({g: 0, Ps: 0}))
target = (mu-1)*(59*mu**3-57*mu**2-62*mu+48)/36 - (mu-1)**3*(mu+1)*sp.pi**2/6
diff = sp.simplify(sp.expand(I_F - target))
print('C/W1 =', sp.factor(sp.simplify(C_W1.subs({g: 0, Ps: 0}))), '\nR1 =', R1, ' R2 =', R2)
print('I_F derived =', sp.factor(I_F), '\nI_F - v10 PSLQ form =', diff)
mp.mp.dps = 30; chk = {}
fC = sp.lambdify(mu, sp.simplify(C_W1.subs({g: 0, Ps: 0, T: sp.Symbol('TT')})).subs(sp.Symbol('TT'), sp.polygamma(1, mu-1)), 'mpmath')
for m in ['7/4', '4/3', '10/7']:
    p, q = map(int, m.split('/')); mv = mp.mpf(p)/q
    w = lambda s: s**(mv-1)*(1-s)**(1-mv); W = lambda x: mp.betainc(mv, 2-mv, 0, x); W1 = mp.gamma(mv)*mp.gamma(2-mv)
    Cq = mp.quad(lambda x: W(x)**2/w(x), [0, 0.5, 1])/W1
    chk[m] = {'C/W1 quad': mp.nstr(Cq, 22), 'C/W1 derived': mp.nstr(fC(mv), 22), 'diff': mp.nstr(abs(Cq-fC(mv)), 3)}; print(m, chk[m])
json.dump({'C_over_W1': str(sp.factor(sp.simplify(C_W1.subs({g: 0, Ps: 0})))), 'R1': str(R1), 'R2': str(R2),
           'I_F_derived': str(sp.factor(I_F)), 'I_F_minus_v10_PSLQ': str(diff), 'T_means': 'psi1(mu-1)', 'checks': chk},
          open('/workspace/XVI-O1-CONE/logs/v11/fmode_derive.json', 'w'), indent=1)
