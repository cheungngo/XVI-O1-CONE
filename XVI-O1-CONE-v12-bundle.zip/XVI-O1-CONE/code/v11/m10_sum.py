"""v11 item (1): zeta-regulated mode sums M10 for pairings P0 (same-k helicity frame, the v10 rule) and P1 (unit
angular-momentum shift; the declared frame intertwiner H_I), families pos/neg, regulators
  R_k: weight |k|^{-eps} (v10 declaration; pos k=0 unregulated),   R_h: weight h_k^{-eps}, h=(mu+nu)/2.
Head k<K0 exact (cached F); tail k>=K0 from a least-squares fit F ~ sum_i c_i u^{3-i} on k=20..56 (step 2),
u = k (R_k) or u = alpha*h_k (R_h); tail = sum_i c_i zeta(i-3, u_K0), the u^{-1} term giving the pole c_4/eps
(reported) and finite part c_4(-psi(u_K0) [- log(1/alpha) for R_h]).  Error estimate = spread over fit orders.
Missing cache values are reported as missing, never as zero."""
import sys, json, os
from fractions import Fraction as Fr
sys.path.insert(0, '/workspace/XVI-O1-CONE/code/v11')
import mpmath as mp
from m10_jobs import AL, KS, fam
from m10_eval import key, D
mp.mp.dps = 40
def Fval(m, n):
    if m == n: return mp.mpf(m.numerator)/m.denominator*((mp.mpf(m.numerator)/m.denominator)**2-1)/3   # exact diagonal
    for a, b in ((m, n), (n, m)):
        f = os.path.join(D, key(a, b) + '.json')
        if os.path.exists(f): return mp.mpf(json.load(open(f))['F'])
    return None
K0 = 20
def famsum(al, P, side, reg, nfit, sub=1):
    fm = fam(al, P); a = mp.mpf(1)/(mp.mpf(al.numerator)/al.denominator)
    ks = [k for (s, k) in fm if s == side]
    def u(k):
        m, n = fm[(side, k)]
        return k if reg == 'Rk' else (mp.mpf((m+n).numerator)/(m+n).denominator)/2/a
    vals = {k: Fval(*fm[(side, k)]) for k in ks}
    miss = [k for k in ks if vals[k] is None]
    if miss: return {'missing_k': miss}
    head = mp.mpf(0)
    for k in ks:
        if k < K0:
            if reg == 'Rk' and k == 0: head += vals[k]
            elif reg == 'Rk': head += vals[k]
            else: head += vals[k]
    fit = [k for k in ks if k >= K0][::sub]
    S = mp.mpf(38)   # column scaling (u/S)^{3-i}; QR least squares
    A = mp.matrix([[(mp.mpf(u(k))/S)**(3-i) for i in range(nfit)] for k in fit]); b = mp.matrix([vals[k] for k in fit])
    cs, _ = mp.qr_solve(A, b); c = [cs[i]/S**(3-i) for i in range(nfit)]
    res = max(abs(sum(c[i]*mp.mpf(u(k))**(3-i) for i in range(nfit)) - vals[k]) for k in fit)
    u0 = mp.mpf(u(K0)); tail = mp.mpf(0); pole = mp.mpf(0)
    for i in range(nfit):
        if i == 4:
            pole = c[i]; tail += c[i]*(-mp.digamma(u0) - (mp.log(a) if reg == 'Rh' else 0))
        else: tail += c[i]*mp.zeta(i-3, u0)
    return {'FP': head + tail, 'pole': pole, 'fit_resid': res, 'c': [c[i] for i in range(min(nfit, 6))]}
out = {}
for al in AL:
    for P in ('P0', 'P1'):
        for reg in ('Rk', 'Rh'):
            tag = f"{al}|{P}|{reg}"; r = {}
            runs = {nf: [famsum(al, P, s, reg, nf) for s in ('pos', 'neg')] for nf in (10, 11, 12, 13)}
            if any('missing_k' in x for v in runs.values() for x in v):
                out[tag] = {'status': 'MISSING', 'missing': {s: runs[10][i].get('missing_k') for i, s in enumerate(('pos', 'neg'))}}
                print(tag, out[tag]); continue
            tot = {nf: v[0]['FP'] + v[1]['FP'] for nf, v in runs.items()}
            for nf in (8, 9):   # half the fit points (k = 20, 24, ..., 56): sensitivity to data noise
                tot[f'sub{nf}'] = sum(famsum(al, P, sd, reg, nf, sub=2)['FP'] for sd in ('pos', 'neg'))
            best = tot[12]; err = max(abs(tot[nf] - best) for nf in tot)
            pole = runs[12][0]['pole'] + runs[12][1]['pole']
            out[tag] = {'M10_FP': mp.nstr(best, 18), 'err_est': mp.nstr(err, 3), 'pole_coeff_1/eps': mp.nstr(pole, 12),
                        'pos_FP': mp.nstr(runs[12][0]['FP'], 18), 'neg_FP': mp.nstr(runs[12][1]['FP'], 18),
                        'fit_resid': [mp.nstr(runs[12][i]['fit_resid'], 3) for i in (0, 1)],
                        'leading_c_pos': [mp.nstr(x, 15) for x in runs[12][0]['c']], 'leading_c_neg': [mp.nstr(x, 15) for x in runs[12][1]['c']]}
            print(tag, out[tag]['M10_FP'], out[tag]['err_est'], out[tag]['pole_coeff_1/eps'], flush=True)
json.dump(out, open('/workspace/XVI-O1-CONE/logs/v11/M10/m10.json', 'w'), indent=1)

# PSLQ attempt on the finite values (precision limited by err_est; any relation with |coeff| <= 1000 is reported, none is assumed)
res = {}
for tag, v in out.items():
    if 'M10_FP' not in v: continue
    x = mp.mpf(v['M10_FP']); er = mp.mpf(v['err_est']); al = mp.mpf(eval(tag.split('|')[0]))
    if al == 1: res[tag] = 'alpha=1: basis degenerate; compared with exact rationals instead'; continue
    if er == 0 or er > 1e-6: res[tag] = 'precision too low for PSLQ'; continue
    tol = max(er*10, mp.mpf(10)**-30)
    basis = [x, 1, al, 1/al, al**2, 1/al**2, 1/al**3, mp.zeta(3)/al**2, mp.pi**2, mp.log(al)]
    rel = mp.pslq(basis, tol=tol, maxcoeff=1000, maxsteps=10**5)
    res[tag] = {'basis': 'M,1,a,1/a,a^2,1/a^2,1/a^3,zeta3/a^2,pi^2,log a', 'tol': mp.nstr(tol, 3), 'relation': rel}
    print('PSLQ', tag, res[tag]['relation'])
json.dump(res, open('/workspace/XVI-O1-CONE/logs/v11/M10/m10_pslq.json', 'w'), indent=1)
