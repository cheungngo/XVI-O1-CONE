"""Cross-check of degree_check.SymOps against the exact numeric engine Ops at t=1/alpha0 (all h,c,b unit atoms, DM=6, q=(37/11,-53/17))."""
import sys, json
from fractions import Fraction as Fr
sys.path.insert(0, '/workspace/XVI-O1-CONE/code/v8')
import importlib, sympy as sp
import apex_exact as AEnum
from gq import GQ
AEnum_Ops = AEnum.Ops; numfr = AEnum.fr
src = open('/workspace/XVI-O1-CONE/code/v11/degree_check.py').read().split('res = {}')[0]
ns = {}; exec(src, ns)
AE = ns['AE']; t = ns['t']; Q0, Q1 = ns['Q0'], ns['Q1']
import importlib.util
spec = importlib.util.spec_from_file_location('AEN', '/workspace/XVI-O1-CONE/code/v8/apex_exact.py'); AEN = importlib.util.module_from_spec(spec); spec.loader.exec_module(AEN)
bad = 0; tot = 0; out = {}
q = [Fr(37, 11), Fr(-53, 17)]
for tag, al0, br in [('CR_c4', Fr(7071, 10000), 'CR'), ('F_c3', Fr(3, 5), 'F'), ('CR_c1', Fr(3, 10), 'CR')]:
    S = AE.Setup(al0, br); Sn = AEN.Setup(al0, br)
    so = ns['SymOps'](S, [-sp.Rational(37, 11), sp.Rational(53, 17)], None); no = AEN.Ops(Sn, [GQ(-q[0]), GQ(-q[1])])
    for F, sname in (('h', 'E'), ('c', 'K2'), ('b', 'C2T')):
        for lab, cfg in ns['unit_atoms'](S, F, 6, al0):
            (C, n, ms, i) = lab; (k, v), = cfg[C].items()
            ncfg = {C: {(n, Fr(ms)): [GQ(x) for x in v]}}
            A = getattr(so, sname)(cfg); B = getattr(no, sname)(ncfg)
            for Cc, dd in A.items():
                for (nn, mm), vv in dd.items():
                    mnum = Fr(str(sp.nsimplify(mm.subs(t, sp.Rational(al0.denominator, al0.numerator)))))
                    w = B.get(Cc, {}).get((nn, mnum))
                    for j, x in enumerate(vv):
                        xs = sp.nsimplify(sp.expand(x).subs(t, sp.Rational(al0.denominator, al0.numerator)))
                        y = GQ.c(w[j]) if w is not None else GQ(0)
                        tot += 1
                        if sp.Rational(y.re.numerator, y.re.denominator) + sp.I*sp.Rational(y.im.numerator, y.im.denominator) != xs: bad += 1
    out[tag] = [tot, bad]; print(tag, tot, bad, flush=True)
json.dump(out, open('/workspace/XVI-O1-CONE/logs/v11/degree_crosscheck.json', 'w'))
