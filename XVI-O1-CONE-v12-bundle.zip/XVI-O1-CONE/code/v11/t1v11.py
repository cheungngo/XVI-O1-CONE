"""v11: corrected scheme-Z mixed r^2 trace T_1(x;mu,nu). v10's t1_fp used a fixed Cauchy radius r=0.04 in t; the t-expansion
has a branch point at |t2| = 2 sqrt(x(1-x))/|1-2x| (second root of the discriminant), so near the endpoints the fixed radius
exceeds the convergence radius and the even Taylor coefficients are wrong. Here r = min(0.25, 0.25 |t2|, 1/(1+h)).
v11 fix 4 (final): also r <= |t2|/(1+h); without it the endpoint region is aliased for h>~60 (F(61,60) came out below both endpoint values).
v11 fix 2: without the 1/(1+h) cap the Cauchy extraction loses ~1.3 digits per unit h (diagonal test mu=nu=7: 2.6e-10)."""
import mpmath as mp
def XY(t, x):
    lam = 1 - t*t; B = 1 + lam*(2*x - 1); disc = B*B - 4*lam*x*x
    sq = t*mp.sqrt(disc/(t*t)); X = (B - sq)/2; return X, X - lam*(2*x - 1)
def T1(x, mu, nu, K=64):
    x = mp.mpf(x); h = (mu + nu)/2
    if x == mp.mpf(1)/2: t2 = mp.inf
    else: t2 = 2*mp.sqrt(x*(1 - x))/abs(1 - 2*x)
    r = min(mp.mpf('0.25'), t2/4, 1/(1 + h), t2/(1 + h))
    co = [0, 0, 0]
    for j in range(K):
        t = r*mp.expj(2*mp.pi*(j + mp.mpf(1)/2)/K); X, Y = XY(t, x)
        f = mp.hyp2f1(h, h+1, mu+1, X)*mp.hyp2f1(h, h+1, nu+1, Y)
        co[0] += f/K; co[1] += f*t**(-2)/K; co[2] += f*t**(-4)/K
    co = [mp.re(c) for c in co]
    FP = h*(h+1)*co[0] - 2*(h+1)*co[1] + 2*co[2]
    return (4*x*(1-x))**2/4*mp.gamma(h+2)*mp.gamma(h+1)/(mp.gamma(mu+1)*mp.gamma(nu+1))*x**mu*(1-x)**nu*FP/(h*(h+1))
def phi_GL(n, N=60, K=64):
    X, W = mp.gauss_quadrature(N, 'legendre')
    return sum(w*T1((x+1)/2, n+1, n, K)/2 for x, w in zip(X, W))
