#!/usr/bin/env python3
"""Build XVI-O1-CONE-v9.tex from the read-only v8 source plus asserted replacements/insertions.
Every anchor must occur exactly once; v8 is never modified."""
import json, os, re, hashlib, glob
from fractions import Fraction
B = '/workspace/XVI-O1-CONE'
v8 = open(f'{B}/XVI-O1-CONE-v8.tex', encoding='utf-8').read()
assert hashlib.sha256(v8.encode()).hexdigest().startswith('153e4e9d'), 'v8 bytes changed'
S = lambda n: open(f'{B}/v9src/{n}', encoding='utf-8').read()
s = v8
def rep(a, b, count=1):
    global s
    n = s.count(a); assert n == count, (n, a[:120]); s = s.replace(a, b)
def between(a, b, new):
    global s
    assert s.count(a) == 1, a[:80]; i = s.index(a); j = s.index(b, i) + len(b); s = s[:i] + new + s[j:]

rep('pdftitle={Scoped O.1 on the Prescribed Cone, v8},', 'pdftitle={Scoped O.1 on the Prescribed Cone, v9},')
rep(r'''\large Version 8; revision of \texttt{XVI-O1-CONE-v7.tex}:\\
executed replay, exact span certificates, and constant-profile maps}''',
    r'''\large Version 9; revision of \texttt{XVI-O1-CONE-v8.tex}:\\
hidden pairs resolved, the ghost-sector dictionary, and chambers}''')
between(r'\begin{abstract}', r'\end{abstract}', S('abstract.tex').strip())

# ---------- fill v9 section placeholders ----------
sec = S('sec_v9.tex')
dj = []
for f in glob.glob(f'{B}/logs/v9/hidden/dJ_*.json'):
    d = json.load(open(f)); dj.append((Fraction(d['alpha']), d))
dj.sort(key=lambda t: t[0])
def num(x, n=16):
    v = float(x); return '0' if v == 0 else ('%.*g' % (n, v)).replace('e-0', 'e-').replace('e-', r'\times10^{-') + ('}' if 'e-' in ('%.*g' % (n, v)) else '')
def fmt(x): 
    t = '%.15f' % float(x)
    return '\\(' + t + '\\)'
rows = [r'\(%s\) & \(%.6f\) & %s & %s & %s\\' % (a, float(d['nu0']), fmt(d['J_CR_mode_series']), fmt(d['J_F_mode_quad']), fmt(d['DeltaJ'])) for a, d in dj]
assert len(rows) == 14
sec = sec.replace('@@DJTABLE@@', '\n'.join(rows))
scan = {}
for f in glob.glob(f'{B}/logs/v9/scan/apex_*_p0.json'):
    d = json.load(open(f)); scan[(Fraction(d['alpha']), d['branch'])] = d
srows = []
for br in ('CR', 'F'):
    for lo, hi, nm in [(Fraction(1, 4), Fraction(1, 3), r'(1/4,1/3)'), (Fraction(1, 3), Fraction(1, 2), r'(1/3,1/2)'),
                       (Fraction(1, 2), Fraction(2, 3), r'(1/2,2/3)'), (Fraction(2, 3), Fraction(1), r'(2/3,1)')]:
        pts = sorted(a for (a, b) in scan if b == br and lo < a < hi)
        res = {}
        for a in pts:
            d = scan[(a, br)]; key = (d['N_total'], d['N_total'] - d['Z_dim'], d['Z_dim'], d['exact_dim_B'], d['H0_dim'])
            res.setdefault(key, []).append(a)
        for key, al in sorted(res.items()):
            srows.append(r'%s & \(%s\): \(N=%d\), rank \(%d\), \(\dim Z=%d\), \(\dim B=%d\), \(\dim H^0=%d\) & %d angles\\' % (br, nm, *key, len(al)))
    for w in (Fraction(1, 3), Fraction(1, 2), Fraction(2, 3)):
        if (w, br) in scan:
            d = scan[(w, br)]
            srows.append(r'%s & wall \(%s\): \(N=%d\), rank \(%d\), \(\dim Z=%d\), \(\dim H^0=%d\) & wall\\' % (br, w, d['N_total'], d['N_total'] - d['Z_dim'], d['Z_dim'], d['H0_dim']))
nscan = len(scan); nall = 2 * len(open(f'{B}/logs/v9/scan/alphas.txt').read().split())
srows.append(r'\multicolumn{3}{@{}l}{Completed: %d of %d runs (an incomplete scan is reported as such, never extrapolated).}\\' % (nscan, nall))
sec = sec.replace('@@SCANTABLE@@', '\n'.join(srows))
th = json.load(open(f'{B}/logs/v9/tree_hashes_v9.json'))
hr = r'''\begin{center}\scriptsize
\begin{tabular}{@{}lll@{}}
\toprule
Tree & before / after & SHA-256\\
\midrule
''' + '\n'.join(r'%s & %s & \texttt{%s}\\ && \texttt{%s}\\' % (t, 'equal' if th['identical_before_after'][t] else 'DIFFERENT', th['after'][t][:32], th['after'][t][32:]) for t in ['XVI-P', 'XVI-Q', 'XVI-R']) + r'''
\bottomrule
\end{tabular}
\end{center}'''
sec = sec.replace('@@HASHROWS@@', hr)
assert '@@' not in sec
rep(r'\section{Open obligations and the exact release}', sec + '\n' + r'\section{Open obligations and the exact release}')

# ---------- open table ----------
between(r'''\begingroup\small
\begin{longtable}{@{}L{.22\linewidth}L{.40\linewidth}L{.31\linewidth}@{}}
\caption{Open obligations after v8.''', r'''\end{longtable}
\endgroup''', S('opentable.tex').strip())

# ---------- release theorem ----------
rep(r'\begin{theorem}[Scoped v8 release]', r'\begin{theorem}[Scoped v9 release]')
rep(r'''\item \emph{(v8.)} The v6 \(hh\) branch difference is conditional on
the hidden D01 mixed-channel term of Proposition~\ref{prop:v8hidden};
the evanescent coefficients of Section~\ref{sec:v8evan} are
conditional on the declared prescription.
\end{enumerate}''', r'''\item \emph{(v8, amended in v9.)} The hidden D01 mixed-channel term of
Proposition~\ref{prop:v8hidden} is pure TT and vanishes on the lattice
(Proposition~\ref{prop:v9TT}); the v6 \(hh\) branch difference is
restored, subject only to Assumption~\ref{ass:reduction}.
The evanescent coefficients of Section~\ref{sec:v8evan} are
conditional on the declared prescription and are excluded from the
frozen \(\tilde g\) rule (Proposition~\ref{prop:v9evan}).

\item \emph{(v9, executed.)} The mixed trace has the closed form of
Proposition~\ref{prop:v9g}; the TT branch difference \(\Delta J\) is
finite and computed (Table~\ref{tab:v9dJ}); absolute TT values carry
the IR logarithm of Proposition~\ref{prop:v9log}.

\item \emph{(v9, executed, exact on four points.)} The CB/CK
dictionaries and all six constant-profile Ward functionals hold with
two fitted \(\alpha\)-independent normalizations; \(e_5,e_6\) are not
separately determined at constant profile
(Theorem~\ref{thm:v9ghost}).

\item \emph{(v9.)} The generic ST rank over \(\mathbb Q(\alpha)\) is as
in Theorem~\ref{thm:v9generic} on the chambers of
Proposition~\ref{prop:v9walls}; the exceptional set inside chambers is
open.
\end{enumerate}''')
rep(r'''Items (ix)--(xi) are Theorem~\ref{thm:v8cert},''', r'''Items (xii)--(xiv) are Propositions~\ref{prop:v9g},
\ref{prop:v9log}, \ref{prop:v9walls} and Theorems~\ref{thm:v9ghost},
\ref{thm:v9generic}.
Items (ix)--(xi) are Theorem~\ref{thm:v8cert},''')
rep(r'''present conditional statements must not be relabelled as
unconditional graph theorems.}''', r'''present conditional statements must not be relabelled as
unconditional graph theorems.

v9 adds the items of Section~\ref{sec:whatv9}, each hashed in
Appendix~\ref{app:v9artifacts}. It claims no closed form for
\(\Delta J\) or for the D04 part, no derivation of the two ghost
normalizations, no proof that \(\pi_KB\) is independent of \(\alpha\)
beyond the four points, and no identification of the exceptional set
inside chambers. No independent review was started; nothing was
pushed, posted or written to the site.}''')

# ---------- declarations ----------
rep(r'''(versions in \loc{logs/v8/env.json}). No proof-assistant check is
asserted.''', r'''(versions in \loc{logs/v8/env.json}). No proof-assistant check is
asserted.
v9: programs in \loc{code/v9/}, logs in \loc{logs/v9/}, hashes in
Appendix~\ref{app:v9artifacts}; mpmath is additionally used for the
30-digit mode functionals.''')
rep(r'''v8 was compiled with
\begin{verbatim}
pdflatex -halt-on-error XVI-O1-CONE-v8.tex
pdflatex -halt-on-error XVI-O1-CONE-v8.tex
\end{verbatim}''', r'''v9 was compiled with
\begin{verbatim}
pdflatex -halt-on-error XVI-O1-CONE-v9.tex
pdflatex -halt-on-error XVI-O1-CONE-v9.tex
\end{verbatim}''')
rep(r'''No independent review of v8 has taken place;''', r'''No independent review of v8 or v9 has taken place;''')

# ---------- artifacts appendix ----------
rep(r'\section{Source, version, and compilation declarations}', S('artifacts.tex') + '\n' + r'\section{Source, version, and compilation declarations}')

# ---------- bibliography ----------
rep(r'''\item[] \textit{Marks (v8):} * read in full; \ddag{} confirmed online
(registry fetch of 18 October 2026, \url{https://enter.grok.me/browse});''', r'''\item[] \textit{Marks (v9):} * read in full; \ddag{} confirmed online
(registry fetches of 18 October 2026, \url{https://enter.grok.me/browse};
for the v9 sheets: source fetched, abstract and every theorem statement read);''')
bib = S('bib_v9.tex')
rep(r'\bibitem{CheungConeV7}', bib.strip() + '\n\n' + r'\bibitem{CheungConeV7}')
open(f'{B}/XVI-O1-CONE-v9.tex', 'w', encoding='utf-8').write(s)
print('written', len(s.splitlines()), 'lines')
