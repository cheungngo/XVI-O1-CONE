"""v6 item (b): r^2-weighted apex heat coefficient D_b:  ApTr[r^2 e^{-sA_b}] = D_b * s  (Abel-subtracted), so that
ApTr[r^2 f(A_b)] = -D_b f'(0) for heat superpositions.  Also the singular-channel shift and orbifold image checks."""
import sympy as sp, json, mpmath as mp
u, al, b, nu = sp.symbols('u alpha b nu', positive=True)
S = sp.cosh((sp.Rational(1, 2) - b) * u / al) / sp.sinh(u / (2 * al))          # sum_n exp(-|n+b|u/alpha)
# int_0^inf z e^{-z cosh u} I_rho(z) dz = -(1/sinh u) d/du [e^{-rho u}/sinh u]; T2/s = sum_n of that
T2 = -(1 / sp.sinh(u)) * sp.diff(S / sp.sinh(u), u)
c = sp.cosh(u) - 1
bulk = al / c**2                                                            # int r^2 e^{-c r^2/2s} dV/(4 pi s) / s
ser = sp.series(T2 - bulk, u, 0, 2).removeO()
Db = sp.factor(sp.simplify(ser.coeff(u, 0)))
print('pole terms (must vanish):', [sp.simplify(ser.coeff(u, -k)) for k in (1, 2, 3, 4)])
print('D_b =', Db)
# singular channel shift: sum over one channel: -(1/sinh u) d/du [(e^{nu u}-e^{-nu u})/sinh u] -> u->0
sh = sp.limit(-(1 / sp.sinh(u)) * sp.diff((sp.exp(nu * u) - sp.exp(-nu * u)) / sp.sinh(u), u), u, 0)
print('flip shift of D (one channel):', sp.simplify(sh))
# orbifold check alpha = 1/N, b=0: images give sum_{k=1}^{N-1} 1/(4 N sin^4(pi k/N))
chk = {}
for N in [2, 3, 4, 5, 7]:
    img = sum(1 / (4 * N * mp.sin(mp.pi * k / N) ** 4) for k in range(1, N))
    val = Db.subs({al: sp.Rational(1, N), b: 0})
    chk[N] = (mp.nstr(img, 15), str(val), mp.nstr(mp.mpf(sp.N(val, 30)) - img, 5))
    print('alpha=1/%d image sum' % N, chk[N])
# twisted orbifold check: alpha=1/N, b=j/N  -> phases e^{2 pi i k b N/N}? holonomy: images weighted by e^{-2 pi i k b} (b = twist)
tchk = {}
for N, j in [(3, 1), (4, 1), (5, 2)]:
    bb = sp.Rational(j, N)
    img = sum(mp.cos(2 * mp.pi * k * j / N * N / N) / (4 * N * mp.sin(mp.pi * k / N) ** 4) for k in range(1, N))
    # holonomy of twisted channel b around full 2pi/alpha... image k carries phase exp(2 pi i k b / alpha * alpha)?? report both
    val = Db.subs({al: sp.Rational(1, N), b: bb})
    tchk[str((N, j))] = (mp.nstr(img, 12), str(val), mp.nstr(mp.mpf(sp.N(val, 30)), 12))
    print('twisted', N, j, tchk[str((N, j))])
json.dump({'D_b': str(Db), 'flip_shift': str(sp.simplify(sh)), 'orbifold_b0': {str(k): v for k, v in chk.items()}, 'twisted': tchk},
          open('/workspace/XVI-O1-CONE/logs/v6/weighted_apex.json', 'w'), indent=1)
