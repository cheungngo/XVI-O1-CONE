#!/usr/bin/env python3
"""Build XVI-O1-CONE-v10.tex from the read-only v9 source plus asserted replacements/insertions (anchors occur once)."""
import json, hashlib, glob
from fractions import Fraction
B = '/workspace/XVI-O1-CONE'
v9 = open(f'{B}/XVI-O1-CONE-v9.tex', encoding='utf-8').read()
assert hashlib.sha256(v9.encode()).hexdigest().startswith('3a8dd434'), 'v9 bytes changed'
S = lambda n: open(f'{B}/v10src/{n}', encoding='utf-8').read()
s = v9
def rep(a, b, count=1):
    global s
    n = s.count(a); assert n == count, (n, a[:120]); s = s.replace(a, b)
def between(a, b, new):
    global s
    assert s.count(a) == 1, a[:80]; i = s.index(a); j = s.index(b, i) + len(b); s = s[:i] + new + s[j:]
rep('pdftitle={Scoped O.1 on the Prescribed Cone, v9},', 'pdftitle={Scoped O.1 on the Prescribed Cone, v10},')
rep(r'''\large Version 9; revision of \texttt{XVI-O1-CONE-v8.tex}:\\
hidden pairs resolved, the ghost-sector dictionary, and chambers}''',
    r'''\large Version 10; revision of \texttt{XVI-O1-CONE-v9.tex}:\\
closed \(\Delta J\), derived ghost normalizations, chamber ranks, and transverse jets}''')
between(r'\begin{abstract}', r'\end{abstract}', S('abstract.tex').strip())
sec = S('sec_v10.tex')
d = json.load(open(f'{B}/logs/v10/dJ_closed_verify.json'))['fresh']
def e(x): 
    v = float(x); 
    if v == 0: return '0'
    m, ex = ('%.1e' % v).split('e'); return r'\(%s\times10^{%d}\)' % (m, int(ex))
rows = [r'\(%s\) & %s & %s & \(%s\)\\' % (k.replace('sqrt2', r'\sqrt2').replace('golden', r'\varphi_{\rm g}').replace('pi/2', r'\pi/2').replace('(alpha=', r'(\alpha=').replace('_', r'\_'),
        e(v['F_closed_diff']), e(v['CR_closed_diff']), v['DeltaJ_closed'][:22]) for k, v in d.items()]
sec = sec.replace('@@DJFRESH@@', '\n'.join(rows))
V = json.load(open(f'{B}/logs/v10/vector_fp/combined.json'))
vrows = []
for al in sorted(V, key=lambda a: Fraction(a)):
    c = V[al]['D01+D03_FP']['(1, 1)'].split('*')[0]
    vrows.append(r'\(%s\) & \(%s\)\\' % (al, c))
sec = sec.replace('@@VECTAB@@', '\n'.join(vrows))
assert '@@' not in sec
rep(r'\section{Open obligations and the exact release}', sec + '\n' + r'\section{Open obligations and the exact release}')
between(r'''\begingroup\small
\begin{longtable}{@{}L{.22\linewidth}L{.40\linewidth}L{.31\linewidth}@{}}
\caption{Open obligations after v9.''', r'''\end{longtable}
\endgroup''', S('opentable.tex').strip())
rep(r'\begin{theorem}[Scoped v9 release]', r'\begin{theorem}[Scoped v10 release]')
rep(r'''Proposition~\ref{prop:v9walls}; the exceptional set inside chambers is
open.
\end{enumerate}''', r'''Proposition~\ref{prop:v9walls}; the exceptional set inside chambers is
open. \emph{(Amended in v10: empty, conditional on (D); item (xviii).)}

\item \emph{(v10, executed.)} \(\Delta J\) has the closed form of
Corollary~\ref{cor:v10dJ}: the CR mode is derived, and the F mode is
identified by PSLQ and verified, not derived.

\item \emph{(v10, executed.)} \(\lambda_{\rm CK}=-8\) and
\(\lambda_{\rm CB}=-4\ii\) follow from tree operator ratios and the
v9 dictionaries (Theorem~\ref{thm:v10lambda}).

\item \emph{(v10, conditional on (D).)} The rank is constant inside
chambers: 26 on \(N=34\) chambers and 29 on F above \(\tfrac12\)
(Theorem~\ref{thm:v10chamber}).

\item \emph{(v10, partial.)} The slice jet catalogue, the scheme-Z
\(r^2\) moments, and the vector-key finite parts in a declared
scheme are as in Sections~\ref{sec:v10jet} and
\ref{sec:v10vector}. The D04 part, the jet Ward combinations and
\(e_5,e_6\) remain open.
\end{enumerate}''')
rep(r'''Items (xii)--(xiv) are Propositions~\ref{prop:v9g},''', r'''Items (xv)--(xviii) are Corollary~\ref{cor:v10dJ},
Theorems~\ref{thm:v10lambda}, \ref{thm:v10chamber} and
Propositions~\ref{prop:v10Z}, \ref{prop:v10dressed},
\ref{prop:v10vector}.
Items (xii)--(xiv) are Propositions~\ref{prop:v9g},''')
rep(r'''pushed, posted or written to the site.}''', r'''pushed, posted or written to the site.

v10 adds the items of Section~\ref{sec:whatv10}, each hashed in
Appendix~\ref{app:v10artifacts}. It does not claim a derivation of
the F mode, a machine check of the degree bound (D), any jet-level
Ward residual, the D04 value, or a physical scheme for the vector
finite parts. No scope is labelled
\texttt{CLOSED\_PENDING\_INDEPENDENT\_REVIEW}. No independent
review was started; nothing was pushed, posted or written to the
site.}''')
rep(r'''Appendix~\ref{app:v9artifacts}; mpmath is additionally used for the
30-digit mode functionals.''', r'''Appendix~\ref{app:v9artifacts}; mpmath is additionally used for the
30-digit mode functionals.
v10: programs in \loc{code/v10/}, logs in \loc{logs/v10/}, hashes in
Appendix~\ref{app:v10artifacts}.''')
rep(r'''v9 was compiled with
\begin{verbatim}
pdflatex -halt-on-error XVI-O1-CONE-v9.tex
pdflatex -halt-on-error XVI-O1-CONE-v9.tex
\end{verbatim}''', r'''v10 was compiled with
\begin{verbatim}
pdflatex -halt-on-error XVI-O1-CONE-v10.tex
pdflatex -halt-on-error XVI-O1-CONE-v10.tex
\end{verbatim}''')
rep(r'''No independent review of v8 or v9 has taken place;''', r'''No independent review of v8, v9 or v10 has taken place;''')
rep(r'\section{Source, version, and compilation declarations}', S('artifacts.tex') + '\n' + r'\section{Source, version, and compilation declarations}')
rep(r'''\item[] \textit{Marks (v9):} * read in full; \ddag{} confirmed online''', r'''\item[] \textit{Marks (v10):} * read in full; \ddag{} confirmed online''')
rep(r'\bibitem{CheungConeV8}', S('bib_v10.tex').strip() + '\n\n' + r'\bibitem{CheungConeV8}')
open(f'{B}/XVI-O1-CONE-v10.tex', 'w', encoding='utf-8').write(s)
print('written', len(s.splitlines()), 'lines')
