"""v6: compare every printed v5 catalogue entry (coefficient form) with the
executed spectral logs logs/v4/spec_<G>_<BR>.json. Keys: HC index
0=00,1=01,2=02,3=03,4=11,5=12,6=13,7=22,8=23,9=33; ghost index 0,3.
Absent log key = computed zero (spectral_apex.py drops exact zeros)."""
import json, sympy as sp
al, ka, q0, q3 = sp.symbols('alpha kappa q0 q3')
I, pi = sp.I, sp.pi
P2 = q0**2 - q3**2
c0 = (1-al**2)/(12*al); c1 = (5*al**2-6*al+1)/(12*al)
C2 = {'CR': (23*al**2-12*al+1)/(12*al), 'F': (23*al**2-36*al+13)/(12*al)}
def sym(d):
    out = {}
    for (a, b), v in d.items(): out[(a, b)] = v; out[(b, a)] = v
    return out
def expected(br):
    c2 = C2[br]; A = c0+2*c1+4*c2; B = -c0+2*c1
    R = 3*c0+4*c1; T = 4*c0+3*c1; V = c1-c0; W = (c0+2*c1+c2)/2
    k16 = ka**2/(16*pi)
    E = {}
    E['D04'] = {(0, 0): -ka**2/(4*pi)*c0*P2}
    E['D05a'] = {(0, 0): -ka**2/(4*pi)*(c2-c0)*P2}
    E['D11'] = sym({(4, 4): c0/2*P2*k16, (4, 7): c0/2*P2*k16, (7, 7): c0/2*P2*k16})
    def tens(t):  # apply 1<->2 images 4<->7 on single transverse index
        out = dict(t)
        for (a, b), v in t.items():
            for (x, y) in [(a, b)]:
                m = {4: 7}
                if a == 4 and b not in (4, 7): out[(7, b)] = v
                if b == 4 and a not in (4, 7): out[(a, 7)] = v
        return sym(out)
    D03 = {(0, 0): -c0*P2, (0, 9): -c0*P2, (9, 9): -c0*P2, (3, 3): 4*c0*P2,
           (0, 4): c0*(q0**2-3*q3**2), (3, 4): 4*c0*q0*q3, (4, 9): -c0*(3*q0**2-q3**2),
           (4, 4): -(c0+4*c1)*P2, (7, 7): -(c0+4*c1)*P2, (4, 7): -c0*P2,
           (5, 5): -8*c1*P2}  # (5,5) new in v6 (absent from v4/v5 table)
    D01 = {(0, 0): c0*P2, (0, 9): c0*P2, (9, 9): c0*P2, (3, 3): -4*c0*P2,
           (4, 4): (c0-4*c1+c2)*P2, (7, 7): (c0-4*c1+c2)*P2, (4, 7): (c0+c2)*P2,
           (3, 4): -4*(c0+2*c2)*q0*q3, (4, 9): A*q0**2-B*q3**2, (0, 4): -B*q0**2+A*q3**2,
           (5, 5): -8*c1*P2}  # (5,5) new in v6
    E['D03'] = {k: v*k16 for k, v in tens(D03).items()}
    E['D01'] = {k: v*k16 for k, v in tens(D01).items()}
    E['D06'] = {(0, 0): I*ka**2/(8*pi)*R*P2, (3, 3): I*ka**2/(8*pi)*R*P2}
    E['D13'] = {(0, 0): -2*T*q0, (0, 3): 2*V*q3, (3, 0): -R*q3, (3, 3): R*q0,
                (9, 0): -2*V*q0, (9, 3): 2*T*q3}
    E['D13'] = {k: I*ka**2/(16*pi)*v for k, v in E['D13'].items()}
    D02p = {(1, 1): q3**2, (2, 2): q3**2, (5, 5): P2, (6, 6): q0**2, (8, 8): q0**2,
            (1, 6): -q0*q3, (2, 8): -q0*q3, (0, 4): -q3**2/2, (0, 7): -q3**2/2,
            (3, 4): q0*q3, (3, 7): q0*q3, (4, 7): -P2/2, (4, 9): -q0**2/2, (7, 9): -q0**2/2}
    E['D02'] = {k: ka**2/pi*W*v for k, v in sym(D02p).items()}
    E['D12'] = {}
    return E
loc = {'alpha': al, 'kappa': ka, 'q0': q0, 'q3': q3, 'I': I, 'pi': pi}
report = {}
for br in ['CR', 'F']:
    E = expected(br)
    for g, exp in E.items():
        d = json.load(open(f'logs/v4/spec_{g}_{br}.json'))
        got = {tuple(int(x) for x in k.strip('()').split(',')): sp.sympify(v, locals=loc)
               for k, v in d['Gamma_pole_coeff_of_1/(4-d)'].items()}
        keys = set(got) | set(exp)
        bad = [str(k) for k in sorted(keys) if sp.simplify(got.get(k, 0) - exp.get(k, 0)) != 0]
        import re
        try: mixed = sorted(set(re.findall(r'MIXED nonzero (\(\d+, \d+\))', open(f'logs/v4/spec_{g}_{br}.log').read())))
        except FileNotFoundError: mixed = 'no log'
        report[f'{g}_{br}'] = {'mixed_dropped_keys': mixed, 'n_log_keys': len(got), 'n_expected_keys': len([k for k in exp if exp[k] != 0]),
                               'mismatch': bad, 'mixed_helicity_flag': d.get('mixed_helicity_cancel')}
        print(g, br, report[f'{g}_{br}'])
json.dump(report, open('logs/v6/catalogue_check.json', 'w'), indent=1)
print('ALL_MATCH', all(not r['mismatch'] for r in report.values()))
