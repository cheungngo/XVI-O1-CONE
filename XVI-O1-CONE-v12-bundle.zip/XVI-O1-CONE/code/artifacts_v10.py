#!/usr/bin/env python3
"""v10 artifact appendix: SHA-256 of v10 programs/logs, frozen-tree digests before/after, v1-v9 digests before/after."""
import hashlib, glob, os, subprocess, json, sys, platform
R = '/workspace/XVI-O1-CONE/'
def sha(p): return hashlib.sha256(open(p, 'rb').read()).hexdigest()
def tree(t):
    cmd = f"cd /workspace/XVI-{t} && find . -type f -not -path './.pytest_cache/*' -not -name '*.pyc' | sort | xargs sha256sum | sha256sum"
    return subprocess.run(cmd, shell=True, capture_output=True, text=True, env={**os.environ, 'LC_ALL': 'C.UTF-8'}).stdout.split()[0]
os.makedirs(R + 'logs/v10', exist_ok=True)
before = dict(l.split()[:2] for l in open(R + 'logs/frozen_v10_before.sha') if l.strip())
after = {t: tree(t) for t in 'PQR'}
th = {'before': {'XVI-' + t: before['XVI' + t] for t in 'PQR'}, 'after': {'XVI-' + t: after[t] for t in 'PQR'},
      'identical_before_after': {('XVI-' + t): before['XVI' + t] == after[t] for t in 'PQR'}}
json.dump(th, open(R + 'logs/v10/tree_hashes_v10.json', 'w'), indent=1)
v9b = dict((l.split()[1], l.split()[0]) for l in open(R + 'logs/v9_hashes_before_v10.sha') if l.strip())
v9same = all(sha(R + f) == h for f, h in v9b.items())
earlier = {f: sha(R + f) for f in sorted(glob.glob('XVI-O1-CONE-v[1-9].tex', root_dir=R) + glob.glob('XVI-O1-CONE-v[1-9].pdf', root_dir=R))}
prev = R + 'logs/v9/earlier_versions_sha.json'
v18same = all(earlier.get(f) == h for f, h in json.load(open(prev)).items()) if os.path.exists(prev) else None
json.dump(earlier, open(R + 'logs/v10/earlier_versions_sha.json', 'w'), indent=1)
import sympy, mpmath
env = {'python': sys.version.split()[0], 'sympy': sympy.__version__, 'mpmath': mpmath.__version__, 'platform': platform.platform()}
json.dump(env, open(R + 'logs/v10/env.json', 'w'), indent=1)
G = lambda pat: sorted(glob.glob(pat, root_dir=R))
groups = [
 ('Base source (read-only)', ['XVI-O1-CONE-v9.tex']),
 ('v10 programs', G('code/v10/*.py') + G('code/v10/*.sh') + ['code/build_v10.py', 'code/artifacts_v10.py']),
 ('v10 source fragments', [f for f in G('v10src/*.tex') if 'artifacts' not in f]),
 ('Delta J closed form', ['logs/v10/cr_mode_closed.json', 'logs/v10/dJ_closed_verify.json'] + G('logs/v10/fmode/*.json')),
 ('Ghost normalizations', ['logs/v10/lambda_derive.json']),
 ('Chamber minors', G('logs/v10/minor/*/pick.json') + G('logs/v10/minor/*/entries_check.json') + G('logs/v10/minor/*/cocycle9.json')),
 ('Transverse jets', G('logs/v10/jet/jet_*.json') + G('logs/v10/jet/*scheme*.json') + G('logs/v10/jet/t1_fp*.json') + G('logs/v10/jet/mixed_r2*.json') + ['logs/v10/jet/density_D04.json']),
 ('Vector finite parts', G('logs/v10/vector_fp/*.json')),
 ('Integrity, environment', ['logs/frozen_v10_before.sha', 'logs/v10/tree_hashes_v10.json', 'logs/v9_hashes_before_v10.sha',
                             'logs/v10/earlier_versions_sha.json', 'logs/v10/env.json', 'CHECKPOINT_v10.md']),
]
phi = G('logs/v10/jet/phi/*.json')
open(R + 'logs/v10/jet/phi/SHA256SUMS', 'w').write(''.join(f'{sha(R + f)}  {os.path.basename(f)}\n' for f in phi))
groups[6][1].append('logs/v10/jet/phi/SHA256SUMS')
mins = G('logs/v10/minor/*/[0-9]*.json')
open(R + 'logs/v10/minor/SHA256SUMS', 'w').write(''.join(f'{sha(R + f)}  {f}\n' for f in mins))
groups[5][1].append('logs/v10/minor/SHA256SUMS')
rows, man = [], []
for title, files in groups:
    rows.append(r'\multicolumn{2}{@{}l}{\textit{%s} (%d files)}\\' % (title, len(files)))
    for f in files:
        h = sha(R + f); man.append(f'{h}  {f}')
        rows.append(r'{\scriptsize\loc{%s}} & \texttt{\tiny %s}\\' % (f, h))
open(R + 'logs/v10/artifact_manifest_v10.sha256', 'w').write('\n'.join(man) + '\n')
cmds = r'''cd /workspace/XVI-O1-CONE
python3 code/v10/cr_mode_closed.py
python3 code/v10/f_mode_pslq.py
python3 code/v10/dJ_closed_verify.py
python3 code/v10/lambda_derive.py
setsid nohup bash code/v10/minor_driver.sh \
   > logs/v10/minor/driver.log 2>&1 &
python3 code/v10/minor_entries.py
python3 code/v10/cocycle9.py F_c4 7071/10000 7/10 3/4 \
   4/5 5/6 7/8 9/10 19/20   # F_c3 likewise
setsid nohup bash code/v10/jet_driver.sh > /dev/null 2>&1 &
python3 code/v10/jet_analyse.py; python3 code/v10/r2_scheme.py
python3 code/v10/t1_fp.py; python3 code/v10/t1_fp_check.py
python3 code/v10/jet_density_D04.py
setsid nohup bash code/v10/phi_driver.sh > /dev/null 2>&1 &
setsid nohup bash code/v10/vector_driver.sh > /dev/null 2>&1 &
python3 code/v10/vector_combine.py
python3 code/artifacts_v10.py && python3 code/build_v10.py
pdflatex -halt-on-error XVI-O1-CONE-v10.tex   # twice'''
app = r'''
%======================================================================
\section{v10 artifacts, hashes and rerun commands}
\label{app:v10artifacts}
%======================================================================

Paths are relative to \loc{/workspace/XVI-O1-CONE/}. Long jobs ran
detached with \loc{setsid}, were logged, and were resumable through
per-item JSON caches. Environment: Python~''' + env['python'] + r''', SymPy~''' + env['sympy'] + r''', mpmath~''' + env['mpmath'] + r'''.
Frozen trees before \(=\) after: ''' + ', '.join(f"XVI-{t}: {'yes' if th['identical_before_after']['XVI-'+t] else 'NO'}" for t in 'PQR') + r'''.
Digests: ''' + ', '.join(f"XVI-{t} \\texttt{{{after[t][:16]}\\ldots}}" for t in 'PQR') + r'''.
The v9 source and PDF are unchanged: ''' + ('yes' if v9same else 'NO') + r'''. The v1--v8 sources are unchanged: ''' + ('yes' if v18same else ('NO' if v18same is False else 'not recorded')) + r'''.
The cached \(\varphi\) values (''' + str(len(phi)) + r''' files) and the minor evaluations (''' + str(len(mins)) + r''' files) are hashed in
\loc{logs/v10/jet/phi/SHA256SUMS} and \loc{logs/v10/minor/SHA256SUMS}. The full manifest is
\loc{logs/v10/artifact_manifest_v10.sha256}; the \TeX{} source and PDF are hashed in \loc{SHA256SUMS_v10}.
The large-\(n\) \(\varphi\) runs were stopped before completion; they feed no printed value.

\paragraph{Rerun commands.}
\begin{verbatim}
''' + cmds + r'''
\end{verbatim}

{\small
\begin{longtable}{@{}p{.50\linewidth}p{.46\linewidth}@{}}
\caption{SHA-256 of v10 artifacts.}\\
\toprule
File & SHA-256\\
\midrule
\endfirsthead
\toprule
File & SHA-256\\
\midrule
\endhead
\bottomrule
\endfoot
''' + '\n'.join(rows) + r'''
\end{longtable}}
'''
open(R + 'v10src/artifacts.tex', 'w').write(app)
print(th['identical_before_after'], 'v9 same', v9same, 'v1-8 same', v18same, len(man))
