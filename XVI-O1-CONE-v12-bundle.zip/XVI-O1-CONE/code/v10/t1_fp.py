"""v10: closed evaluation of the per-mode mixed r^2 trace T_1(x;mu,nu)=Tr[e^{-(1-x)A_mu} r^2 e^{-x A_nu}] in scheme Z.
Series: T_1 = (4x(1-x))^2/4 G(h+2)G(h+1)/(G(mu+1)G(nu+1)) x^mu (1-x)^nu F4(h+2,h+1;mu+1,nu+1;x^2,(1-x)^2), h=(mu+nu)/2.
F4(h+2,h+1) = (h+1+theta)(h+theta)/(h(h+1)) F4(h,h+1), theta = Euler operator = lam d/dlam on (lam x^2, lam (1-x)^2).
Bailey: F4(h,h+1;mu+1,nu+1;X(1-Y),Y(1-X)) = 2F1(h,h+1;mu+1;X) 2F1(h,h+1;nu+1;Y). With lam = 1-t^2, X(t),Y(t) analytic in t,
Phi(t)=sum phi_n t^n; the finite part at lam=1 (Abel; = zeta continuation since all singular exponents are half-integers) is
FP = h(h+1) phi0 - 2(h+1) phi2 + 2 phi4  [from theta -> -C, theta^2 -> -C+2E with Phi_reg = A + C(1-lam) + E(1-lam)^2]."""
import mpmath as mp
def XY(t, x):
    lam = 1 - t*t; B = 1 + lam*(2*x - 1)
    disc = B*B - 4*lam*x*x
    # analytic square root ~ 2 t sqrt(x(1-x)) (1+...) : sqrt(disc) = t*sqrt(disc/t^2)
    sq = t*mp.sqrt(disc/(t*t)) if t != 0 else mp.mpf(0)
    X = (B - sq)/2; Y = X - lam*(2*x - 1)
    return X, Y
def T1(x, mu, nu):
    x = mp.mpf(x); h = (mu + nu)/2
    Phi = lambda t: mp.hyp2f1(h, h+1, mu+1, XY(t, x)[0])*mp.hyp2f1(h, h+1, nu+1, XY(t, x)[1])
    # even part via symmetric finite differences is automatic in taylor of the even combination
    E = lambda t: (Phi(t) + Phi(-t))/2
    c = mp.taylor(E, mp.mpf(10)**(-6), 4)    # expand at small t>0 to avoid 0/0, then shift: use polyfit instead
    return None
def T1(x, mu, nu, M=12, r=mp.mpf('0.05')):
    """even Taylor coefficients of Phi_even(t) by sampling on a circle in t (Cauchy), radius r."""
    x = mp.mpf(x); h = (mu + nu)/2
    def Phi(t):
        X, Y = XY(t, x)
        return mp.hyp2f1(h, h+1, mu+1, X)*mp.hyp2f1(h, h+1, nu+1, Y)
    K = 4*M
    co = [mp.mpf(0)]*5
    for j in range(K):
        t = r*mp.expj(2*mp.pi*(j + mp.mpf(1)/2)/K)
        f = Phi(t)
        for n in (0, 2, 4):
            co[n] += f*t**(-n)/K
    co = [mp.re(c) for c in co]
    FP = h*(h+1)*co[0] - 2*(h+1)*co[2] + 2*co[4]
    pref = (4*x*(1-x))**2/4*mp.gamma(h+2)*mp.gamma(h+1)/(mp.gamma(mu+1)*mp.gamma(nu+1))*x**mu*(1-x)**nu
    return pref*FP/(h*(h+1))
if __name__ == '__main__':
    import json
    mp.mp.dps = 40
    out = {}
    for (x, mu, nu) in [('0.5', 1.3, 1.3), ('0.3', 1.3, 1.3), ('0.3', 2.5, 2.5)]:
        mu = mp.mpf(mu); nu = mp.mpf(nu)
        out[f'{x},{mu},{nu}'] = [mp.nstr(T1(x, mu, nu), 25), mp.nstr(mu*(mu**2-1)/3, 25)]
        print(out[f'{x},{mu},{nu}'], flush=True)
    json.dump(out, open('/workspace/XVI-O1-CONE/logs/v10/jet/t1_fp_same.json', 'w'), indent=1)
