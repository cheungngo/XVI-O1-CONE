"""v10 item (1), declared IR scheme for r^2 jets.  Scheme Z (radial Mellin + Hurwitz zeta):
  per mode  P_w(mu) = Tr_mode[r^{2w} e^{-s A_mu}] continued analytically from Re w < -1/2;  at w=1: s*mu(mu^2-1)/3
  (closed form (2s)^w/2 * Gamma(w+1+mu)Gamma(-1/2-w)/(2^{w+1} sqrt(pi) Gamma(mu-w))),  mode sum by Hurwitz zeta.
Checks: (a) closed form vs quadrature for w<-1/2; (b) mode sum vs D_b of Theorem D: D^Z_b = D_b + 11 alpha/180 (exact);
(c) singular flip -mu: Delta = 2 nu(1-nu^2)/3 = Prop. Dflip; (d) alpha=1 and alpha=1/2 consequences."""
import mpmath as mp, json, sympy as sp
mp.mp.dps = 40
def Pw(w, mu, s=1):
    return (2*s)**w/2*mp.gamma(w+1+mu)*mp.gamma(-mp.mpf(1)/2-w)/(2**(w+1)*mp.sqrt(mp.pi)*mp.gamma(mu-w))
def Pquad(w, mu, s=1):
    f = lambda r: r**(1+2*w)*mp.besseli(mu, r*r/(2*s))*mp.exp(-r*r/(2*s))/(2*s)
    return mp.quad(f, [0, 1, 5, 20, mp.inf])
out = {'a': []}
for (w, mu) in [(-0.8, 1.3), (-1, 0.7), (-0.75, 2.5), (-1.3, 1.9)]:
    out['a'].append([w, mu, float(Pw(w, mu)), float(Pquad(w, mu)), float(abs(Pw(w, mu) - Pquad(w, mu)))])
out['P1_closed'] = str(sp.simplify(sp.gamma(sp.Symbol('m')+2)*sp.gamma(-sp.Rational(3, 2))/(4*sp.sqrt(sp.pi)*sp.gamma(sp.Symbol('m')-1))))
# (b) mode sum: modes mu_k = |k+b|/alpha, k in Z;  sum mu^3/3 - mu/3 by Hurwitz zeta
a, b = sp.symbols('alpha b', positive=True)
B2 = b**2 - b + sp.Rational(1, 6); B4 = b**4 - 2*b**3 + b**2 - sp.Rational(1, 30)
zH = lambda n: -sp.bernoulli(n+1, b)/(n+1) - sp.bernoulli(n+1, 1-b)/(n+1)   # zeta(-n,b)+zeta(-n,1-b)
DZ = sp.expand((zH(3)/a**3 - zH(1)/a)/3)
Db = -11*a/180 + B2/(3*a) - B4/(6*a**3)
out['b_DZ_minus_Db'] = str(sp.simplify(DZ - Db))
# numeric cross-check of the zeta sum at alpha=0.7,b=0.3 using mpmath zeta
al, bb = mp.mpf('0.7'), mp.mpf('0.3')
num = (mp.zeta(-3, bb) + mp.zeta(-3, 1-bb))/(3*al**3) - (mp.zeta(-1, bb) + mp.zeta(-1, 1-bb))/(3*al)
out['b_numeric'] = [float(num), float(DZ.subs({a: 0.7, b: 0.3}))]
nu = sp.Symbol('nu')
out['c_flip'] = str(sp.factor(-nu*(nu**2-1)/3 - nu*(nu**2-1)/3 - 2*nu*(1-nu**2)/3))
# (d) channel jet weights d_s (Abel scheme = Theorem D):  d0=D(a,0), d1=D(a,a), d2F=D(a,2a-1), d2CR=D(a,2a)
D = lambda x, y: Db.subs({a: x, b: y})
ds = {'d0': D(a, 0), 'd1': D(a, a), 'd2F': D(a, 2*a-1), 'd2CR': D(a, 2*a)}
out['d_s'] = {k: str(sp.factor(vv)) for k, vv in ds.items()}
out['alpha1_F'] = {k: str(sp.simplify(vv.subs(a, 1))) for k, vv in ds.items()}
out['alpha_half_CR_minus_F'] = str(sp.simplify((ds['d2CR'] - ds['d2F']).subs(a, sp.Rational(1, 2))))
print(json.dumps(out, indent=1))
json.dump(out, open('/workspace/XVI-O1-CONE/logs/v10/jet/r2_scheme.json', 'w'), indent=1)
