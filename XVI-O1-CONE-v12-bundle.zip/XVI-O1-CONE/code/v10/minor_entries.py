"""v10 item (5): are the entries of the stored minors alpha-independent?  For tag and alpha list, rebuild the minor
sub-matrices and report the set of distinct entry-matrices (hash) and which columns carry alpha dependence."""
import sys, json, hashlib
sys.argv = ['minor_poly.py', 'eval', sys.argv[1]] + sys.argv[2:]
ARGV = list(sys.argv)
src = open('/workspace/XVI-O1-CONE/code/v10/minor_poly.py').read(); src = src[:src.index("if mode == 'pick':\n    T0")]
exec(src)
res = {}
for a in ARGV[3:]:
    g = setup(a); basis, order = make_basis(g, meta['gh0_pivots']); tags, ATI = row_tags(g, basis)
    H = []
    for m in meta['minors']:
        sub = [build_row(g, ATI, order, basis, tuple(t)) for t in m['rows']]
        M = [[str(g['GQ'].c(row[j]).re) + '|' + str(g['GQ'].c(row[j]).im) for j in m['cols']] for row in sub]
        H.append(M)
    res[a] = H
ref = res[ARGV[3]]
out = {'tag': ARGV[2], 'alphas': ARGV[3:], 'entries_identical_to_first': {a: [ref[k] == res[a][k] for k in range(len(ref))] for a in res}}
diffcols = set()
for a in res:
    for k in range(len(ref)):
        for i, (r1, r2) in enumerate(zip(ref[k], res[a][k])):
            for j, (x, y) in enumerate(zip(r1, r2)):
                if x != y: diffcols.add((k, j))
out['alpha_dependent_entries(minor,col)'] = sorted(diffcols)
json.dump(out, open(f'logs/v10/minor/{ARGV[2]}/entries_check.json', 'w'), indent=1); print(json.dumps(out)[:600])
