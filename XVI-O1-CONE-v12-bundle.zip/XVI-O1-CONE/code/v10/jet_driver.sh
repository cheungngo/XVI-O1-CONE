#!/bin/bash
cd /workspace/XVI-O1-CONE
for g in D04 D05a D12 D02 D11 D06 D13 D03 D01; do
  python3 code/v10/jet_replay.py $g >> logs/v10/jet/driver.log 2>> logs/v10/jet/err_$g.log
done
echo ALLDONE >> logs/v10/jet/driver.log
