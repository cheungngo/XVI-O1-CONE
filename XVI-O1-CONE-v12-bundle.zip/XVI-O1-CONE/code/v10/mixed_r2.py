"""v10: per-mode mixed r^{2w} trace integrated over the Schwinger fraction, X_w(mu,nu)=int_0^1 Tr[e^{-(1-x)A_mu} r^{2w} e^{-x A_nu}]dx,
series form  X_w = 4^w Sum_{k,l} G(N+h+w+1)G(N+h+1)G(2k+mu+w+2)G(2l+nu+w+2)/(k! l! G(k+mu+1)G(l+nu+1)G(2N+2h+2w+4)), N=k+l, h=(mu+nu)/2.
Scheme Z: continuation in w via the large-N expansion of the N-shell sums t_N (fitted, then Hurwitz-zeta summed).
Checks: w=-1 gives 1/(2(mu+nu)) (v9 Prop. g);  mu=nu at w=1 gives mu(mu^2-1)/3 (same-mode Mellin closed form)."""
import mpmath as mp, sys, json
mp.mp.dps = 50
def shells(w, mu, nu, Nmax):
    h = (mu + nu)/2; t = []
    lg = mp.loggamma
    for N in range(Nmax):
        s = mp.mpf(0)
        for k in range(N + 1):
            l = N - k
            s += mp.exp(lg(N+h+w+1) + lg(N+h+1) + lg(2*k+mu+w+2) + lg(2*l+nu+w+2) - lg(k+1) - lg(l+1) - lg(k+mu+1) - lg(l+nu+1) - lg(2*N+2*h+2*w+4))
        t.append(4**w*s)
    return t
def zsum(w, mu, nu, Nmax=260, J=14, N0=120):
    t = shells(w, mu, nu, Nmax)
    a = w - mp.mpf(1)/2       # leading exponent  t_N ~ sum_j c_j N^{a-j}  (assumed; checked by the fit residual)
    Ns = list(range(Nmax - 2*J, Nmax, 2))[:J]
    A = mp.matrix([[mp.mpf(n)**(a - j) for j in range(J)] for n in Ns]); bvec = mp.matrix([t[n] for n in Ns])
    c = mp.lu_solve(A, bvec)
    resid = max(abs(t[n] - sum(c[j]*mp.mpf(n)**(a-j) for j in range(J))) for n in range(Nmax - 2*J - 20, Nmax - 2*J))
    tot = sum(t[:N0]) + sum(t[n] - sum(c[j]*mp.mpf(n)**(a-j) for j in range(J)) for n in range(N0, Nmax)) \
        + sum(c[j]*mp.zeta(j - a, Nmax) for j in range(J)) * 0  # placeholder replaced below
    # continued sum: sum_{n<N0} t_n + sum_{n>=N0} [asymptotic]  (asymptotic summed by Hurwitz zeta), tail error ~ resid
    tot = sum(t[:N0]) + sum(c[j]*mp.zeta(j - a, N0) for j in range(J))
    return tot, resid
if __name__ == "__main__":
  out = {}
  for (mu, nu) in [(mp.mpf('1.3'), mp.mpf('1.3')), (mp.mpf('2.5'), mp.mpf('2.5'))]:
      v, r = zsum(1, mu, nu); out[f'same {mu}'] = [mp.nstr(v, 20), mp.nstr(mu*(mu**2-1)/3, 20), mp.nstr(r, 5)]
      print(out[f'same {mu}'], flush=True)
  t = shells(-1, mp.mpf('1.3'), mp.mpf('0.6'), 400); out['w=-1 check'] = [mp.nstr(sum(t), 15), mp.nstr(1/(2*mp.mpf('1.9')), 15)]
  print(out['w=-1 check'], flush=True)
  for (mu, nu) in [(mp.mpf('1.3'), mp.mpf('0.6')), (mp.mpf('2.2'), mp.mpf('0.7')), (mp.mpf('1.75'), mp.mpf('1.25'))]:
      v, r = zsum(1, mu, nu); out[f'mixed {mu},{nu}'] = [mp.nstr(v, 20), mp.nstr(r, 5)]
      print(out[f'mixed {mu},{nu}'], flush=True)
  json.dump(out, open('/workspace/XVI-O1-CONE/logs/v10/jet/mixed_r2.json', 'w'), indent=1)
