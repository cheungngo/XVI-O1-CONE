"""v10 item (3): derive the ghost-sector normalisations from TREE data only (no loop values).
Dictionaries (v8/v9, si=+1): h: x00=-LL_tt, x03=i LL_tz, x33=LL_zz, f=PM/2;  c^0 = sc*i*L_t (sc=-1), c^3 = L_z;
 b, cb: comp0 = +i L_t, comp3 = L_z;  K: K^00=-LL_tt, K^03=-2i LL_tz, K^33=LL_zz;  q0 = i q_t, q3 = q_z.
Tree objects compared (engine operators of code/v8/apex_exact.py vs catalogue formulas of v9 Sec. ST):
 rho : engine K2 c        = rho * delta_c h   (delta_c h_{mn} = p_m c_n + p_n c_m, c_n = eta_nn c^n, p_m=(q0,q3))
 eps : engine E h (K-slot)= eps * (2-delta_mn) E^{mn}_cat(h)        (eq. Einstein, raised, coordinate weighted)
 tau : engine C2^T b      = tau * Y_b,  Y_b = -2 eta F_L^T b  (the catalogue ghost identity  B_D06 = -2 eta F_L Gamma_D13)
Engine rows on catalogue coordinates (y_HH: Gamma_sym=4Gamma, y_CB,y_CK: 2Gamma) give
 HH/CK row:  8 rho B + 2 lambda_CK eps G = 0, with catalogue B + lambda_pred G = 0, lambda_pred = N/(i A_GH) = -2i (Input tree)
             => lambda_CK = 4 rho lambda_pred / eps
 CB/CK row:  2 lambda_CB Gamma_D06 + 2 lambda_CK tau Gamma_D06 = 0  => lambda_CB = -tau lambda_CK."""
import sys, json
from fractions import Fraction as Fr
sys.path.insert(0, '/workspace/XVI-O1-CONE/code/v8')
import sympy as sp
import apex_exact as AJ
from gq import GQ
I = sp.I
def g2s(v):
    v = GQ.c(v); return sp.Rational(v.re.numerator, v.re.denominator) + I*sp.Rational(v.im.numerator, v.im.denominator)
S = AJ.Setup(Fr(7071, 10000), 'CR')   # m=0, n=0 atoms: operators below do not see alpha on these atoms
def cfg(C, v): return {C: {(0, Fr(0)): [GQ(t) for t in v]}}
def LLlor_h(LL): return {(0, 0): -LL[0], (0, 3): I*LL[1], (3, 3): LL[3]}
def LLlor_K(LL): return {(0, 0): -LL[0], (0, 3): -2*I*LL[1], (3, 3): LL[3]}
eta = {0: 1, 3: -1}
out = {'rho': set(), 'eps': set(), 'tau': set()}
for qa in range(1, 4):
    for qb in range(1, 4):
        q = [GQ(qa), GQ(qb)]; Q0, Q3 = I*qa, sp.Integer(qb); O = AJ.Ops(S, q); On = AJ.Ops(S, [GQ(-qa), GQ(-qb)])
        # rho: c atoms
        for v in ([1, 0], [0, 1]):
            K2 = O.K2(cfg('L', v)); LL = [g2s(x) for x in K2['LL'][(0, Fr(0))]]
            hL = LLlor_h(LL)
            cu = {0: -1*I*v[0], 3: v[1]}; cl = {k: eta[k]*cu[k] for k in cu}; p = {0: Q0, 3: Q3}
            dh = {(0, 0): 2*p[0]*cl[0], (0, 3): p[0]*cl[3] + p[3]*cl[0], (3, 3): 2*p[3]*cl[3]}
            for k in dh:
                if dh[k] != 0: out['rho'].add(sp.nsimplify(sp.simplify(hL[k]/dh[k])))
                elif hL[k] != 0: out['rho'].add('MISMATCH')
        # eps: h atoms (LL and PM), engine E with momentum convention of the hc row (E at -q)
        for C, v in (('LL', [1, 0, 0, 0]), ('LL', [0, 1, 1, 0]), ('LL', [0, 0, 0, 1]), ('PM', [1])):
            Eh = On.E(cfg(C, v)); LLE = [g2s(x) for x in Eh.get('LL', {}).get((0, Fr(0)), [0, 0, 0, 0])]
            KL = LLlor_K(LLE)
            if C == 'PM': h = {(0, 0): 0, (0, 3): 0, (3, 3): 0}; f = sp.Rational(1, 2)*v[0]
            else: h = LLlor_h(v); f = 0
            # catalogue E_{mn} (lower) on the lattice (longitudinal part + transverse trace 2f), momentum p -> -p is irrelevant (even)
            P2 = Q0**2 - Q3**2; pl = {0: Q0, 3: Q3}; pu = {0: Q0, 3: -Q3}
            H = {(0, 0): h[(0, 0)], (0, 3): h[(0, 3)], (3, 0): h[(0, 3)], (3, 3): h[(3, 3)]}
            tr4 = h[(0, 0)] - h[(3, 3)] - 2*f
            ph = {m: sum(pu[r]*H[(r, m)] for r in (0, 3)) for m in (0, 3)}; pph = sum(pu[m]*ph[m] for m in (0, 3))
            def Ecat(m, n):
                return P2*H[(m, n)] - pl[m]*ph[n] - pl[n]*ph[m] + pl[m]*pl[n]*tr4 + (eta[m] if m == n else 0)*(pph - P2*tr4)
            Ecoord = {(0, 0): Ecat(0, 0), (0, 3): 2*eta[0]*eta[3]*Ecat(0, 3), (3, 3): Ecat(3, 3)}
            for k in Ecoord:
                a, b = sp.expand(KL[k]), sp.expand(Ecoord[k])
                if b != 0: out['eps'].add(sp.nsimplify(sp.simplify(a/b)))
                elif a != 0: out['eps'].add(('MISMATCH', str(a)))
        # tau: b atoms; engine C2T at -q (bc row convention)
        for v in ([1, 0], [0, 1]):
            C2 = On.C2T(cfg('L', v)); LL = [g2s(x) for x in C2.get('LL', {}).get((0, Fr(0)), [0, 0, 0, 0])]
            KL = LLlor_K(LL)
            bu = {0: I*v[0], 3: v[1]}
            Y = {(0, 0): -bu[0]*Q0 - bu[3]*Q3, (3, 3): -bu[0]*Q0 - bu[3]*Q3, (0, 3): 2*bu[0]*Q3 + 2*bu[3]*Q0}
            for k in Y:
                a, b = sp.expand(KL[k]), sp.expand(Y[k])
                if b != 0: out['tau'].add(sp.nsimplify(sp.simplify(a/b)))
                elif a != 0: out['tau'].add(('MISMATCH', str(a)))
res = {k: [str(x) for x in v] for k, v in out.items()}
print(res)
if all(len(v) == 1 and 'MISMATCH' not in str(v) for v in out.values()):
    rho, eps, tau = [list(out[k])[0] for k in ('rho', 'eps', 'tau')]
    lp = -2*I
    lCK = sp.simplify(4*rho*lp/eps); lCB = sp.simplify(-tau*lCK)
    res.update({'lambda_pred': str(lp), 'lambda_CK_derived': str(lCK), 'lambda_CB_derived': str(lCB),
                'fitted_v9': {'lambda_CK': '-8', 'lambda_CB': '-4*I'},
                'agree': [sp.simplify(lCK + 8) == 0, sp.simplify(lCB + 4*I) == 0]})
    print(res)
json.dump(res, open('logs/v10/lambda_derive.json', 'w'), indent=1)
