#!/bin/bash
cd /workspace/XVI-O1-CONE
echo 0 1/7 2/7 3/7 4/7 5/7 6/7 1 8/7 9/7 10/7 11/7 12/7 13/7 2 15/7 17/7 19/7 3 23/7 4 5 6 8 10 3/11 13/11 | tr ' ' '\n' | \
  xargs -P 6 -I{} sh -c 'python3 code/v10/phi_mixed.py {} >> logs/v10/jet/phi_driver.log 2>&1'
echo ALLDONE >> logs/v10/jet/phi_driver.log
