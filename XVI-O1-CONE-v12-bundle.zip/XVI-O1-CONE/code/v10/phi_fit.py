"""Try to identify phi(n)=int_0^1 T_1(x;n+1,n)dx as sum_j a_j n^j + sum_j b_j n^j psi1(n) (+ optional digamma terms),
fit on part of the cached values (logs/v10/jet/phi), verified on the rest."""
import mpmath as mp, json, glob, os, itertools
from fractions import Fraction as Fr
mp.mp.dps = 38
data = {}
for f in glob.glob('/workspace/XVI-O1-CONE/logs/v10/jet/phi/*.json'):
    d = json.load(open(f)); q = Fr(d['n'])
    if q == 0 or d['phi'] == 'nan': continue
    data[q] = mp.mpf(d['phi'])
ns = sorted(data)
print(len(ns), [str(n) for n in ns])
def basis(n, P, Qd, dig):
    n = mp.mpf(n.numerator)/n.denominator
    b = [n**j for j in range(P + 1)] + [n**j*mp.psi(1, n) for j in range(Qd + 1)]
    if dig: b += [n**j*mp.psi(0, n) for j in range(dig)]
    return b
best = []
for P, Qd, dig in itertools.product(range(2, 6), range(0, 5), [0, 2]):
    nb = P + 1 + Qd + 1 + dig
    if nb + 3 > len(ns): continue
    fit, ver = ns[::2][:nb] if len(ns[::2]) >= nb else ns[:nb], None
    fit = ns[:nb] if len(ns[::2]) < nb else ns[::2][:nb]
    ver = [n for n in ns if n not in fit]
    A = mp.matrix([basis(n, P, Qd, dig) for n in fit]); bb = mp.matrix([data[n] for n in fit])
    try: c = mp.lu_solve(A, bb)
    except ZeroDivisionError: continue
    err = max(abs(sum(c[i]*v for i, v in enumerate(basis(n, P, Qd, dig))) - data[n]) for n in ver)
    best.append((err, P, Qd, dig, [mp.identify(ci) or mp.nstr(ci, 15) for ci in c]))
best.sort(key=lambda t: t[0])
for b in best[:5]: print(mp.nstr(b[0], 5), b[1:4], b[4])
