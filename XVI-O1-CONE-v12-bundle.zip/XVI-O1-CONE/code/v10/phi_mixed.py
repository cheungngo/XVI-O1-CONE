"""v10 item (2a) candidate: phi(n) = int_0^1 T_1(x; n+1, n) dx (scheme Z), with PSLQ identification over {1, psi1(n), pi^2}.
Results cached per n in logs/v10/jet/phi/<n>.json (resumable)."""
import mpmath as mp, json, sys, os
sys.path.insert(0, '/workspace/XVI-O1-CONE/code/v10')
from t1_fp import XY
mp.mp.dps = 40
D = '/workspace/XVI-O1-CONE/logs/v10/jet/phi'; os.makedirs(D, exist_ok=True)
def T1(x, mu, nu, K=64, r=mp.mpf('0.04')):
    h = (mu + nu)/2; co = [0, 0, 0]
    for j in range(K):
        t = r*mp.expj(2*mp.pi*(j + mp.mpf(1)/2)/K); X, Y = XY(t, x)
        f = mp.hyp2f1(h, h+1, mu+1, X)*mp.hyp2f1(h, h+1, nu+1, Y)
        co[0] += f/K; co[1] += f*t**(-2)/K; co[2] += f*t**(-4)/K
    co = [mp.re(c) for c in co]
    FP = h*(h+1)*co[0] - 2*(h+1)*co[1] + 2*co[2]
    return (4*x*(1-x))**2/4*mp.gamma(h+2)*mp.gamma(h+1)/(mp.gamma(mu+1)*mp.gamma(nu+1))*x**mu*(1-x)**nu*FP/(h*(h+1))
def phi(n):
    f = os.path.join(D, str(n).replace('/', '_') + '.json')
    if os.path.exists(f): return mp.mpf(json.load(open(f))['phi'])
    nn = mp.mpf(sp_frac(n))
    v = mp.quad(lambda x: T1(x, nn + 1, nn), [0, mp.mpf(1)/2, 1], method='gauss-legendre')
    json.dump({'n': str(n), 'phi': mp.nstr(v, 38)}, open(f, 'w')); return v
def sp_frac(s):
    from fractions import Fraction
    q = Fraction(s); return mp.mpf(q.numerator)/q.denominator
if __name__ == '__main__':
    out = {}
    for n in sys.argv[1:]:
        v = phi(n); nn = sp_frac(n)
        mp.mp.dps = 30
        rel = mp.pslq([v, 1, mp.psi(1, nn), mp.pi**2], maxcoeff=10**6, maxsteps=10**6) if nn > 0 else None
        mp.mp.dps = 40
        out[n] = {'phi': mp.nstr(v, 40), 'pslq[phi,1,psi1(n),pi^2]': rel}
        print(n, out[n], flush=True)
