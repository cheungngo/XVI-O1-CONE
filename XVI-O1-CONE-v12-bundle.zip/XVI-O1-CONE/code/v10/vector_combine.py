"""v10 item (6): combine logs/v10/vector_fp/<alpha>.json with the D01/D03 hidden densities (logs/v8/slice/hidden_mixed.json).
J_key = sum_pairs sum_families [ -R(1) S_nu/2 - sum_j r_j S_j ],  value_key = -i pref_G J (v7 normalisation, before nothing else).
Checks: k-zeta pole residue vs v9 log coefficient (alpha/2) L_key (Prop. v9vector)."""
import json, glob, os
import sympy as sp, mpmath as mp
from fractions import Fraction as Fr
mp.mp.dps = 30
x, q0, q3 = sp.symbols('x q0 q3'); I = sp.I; pi = sp.pi; kap = sp.Symbol('kappa')
H = json.load(open('/workspace/XVI-O1-CONE/logs/v8/slice/hidden_mixed.json'))
pref = {'D01': kap**2/2, 'D03': -kap**2}
out = {}
for f in sorted(glob.glob('/workspace/XVI-O1-CONE/logs/v10/vector_fp/*.json')):
    al = os.path.basename(f)[:-5].replace('_', '/'); a = sp.Rational(Fr(al).numerator, Fr(al).denominator)
    V = json.load(open(f)); res = {}
    for G in ('D01', 'D03'):
        for key, pairs in H[G].items():
            st_set = {eval(st) for st, _ in pairs}
            if not st_set <= {(0, 1), (1, 0)}: continue
            FP = 0; POLE = 0; Lkey = 0
            for st, rho in pairs:
                r = sp.sympify(rho, locals={'x': x, 'q0': q0, 'q3': q3, 'I': I, 'pi': pi})
                R = sp.expand(sp.integrate(r, (x, 0, x)))
                Lkey += sp.integrate(r*x*(x-1), (x, 0, 1))
                rj = [R.coeff(x, j) for j in (1, 2, 3)]; R1 = R.subs(x, 1)
                assert sp.expand(R - sum(rj[j-1]*x**j for j in (1, 2, 3))) == 0
                for fam in ('kpos', 'kneg'):
                    d = V[f'({st[1]}, {st[4]})' + fam] if False else V[str(eval(st)) + fam]
                    fp = [sp.Float(c['FP'], 25) for c in d]; po = [sp.Float(c['pole'], 25) for c in d]
                    FP += -R1*fp[0]/2 - sum(rj[j]*fp[j+1] for j in range(3))
                    POLE += -R1*po[0]/2 - sum(rj[j]*po[j+1] for j in range(3))
            val = sp.expand(-I*pref[G]*FP); pole = sp.expand(-I*pref[G]*POLE)
            pred = sp.expand(-I*pref[G]*a/2*Lkey)
            res[f'{G}{key}'] = {'FP_value_kzeta': str(sp.N(val, 15)), 'pole_value': str(sp.N(pole, 12)),
                                 'pole_pred_v9': str(sp.N(pred, 12)), 'pole_dev': str(sp.N(sp.expand(pole - pred), 3))}
    # sums over graphs
    tot = {}
    for k, v in res.items():
        kk = k[3:]; tot[kk] = sp.expand(tot.get(kk, 0) + sp.sympify(v['FP_value_kzeta'], locals={'kappa': kap, 'q0': q0, 'q3': q3}))
    out[al] = {'per_graph': res, 'D01+D03_FP': {k: str(sp.N(v, 12)) for k, v in tot.items()}}
json.dump(out, open('/workspace/XVI-O1-CONE/logs/v10/vector_fp/combined.json', 'w'), indent=1)
for al, o in out.items():
    print(al); print(' sum', o['D01+D03_FP'])
    print(' max pole dev', max(abs(complex(sp.sympify(v['pole_dev'], locals={'kappa': 1, 'q0': 1.3, 'q3': 0.7}).subs({sp.Symbol('kappa'): 1, sp.Symbol('q0'): 1.3, sp.Symbol('q3'): 0.7}))) for v in o['per_graph'].values()))
