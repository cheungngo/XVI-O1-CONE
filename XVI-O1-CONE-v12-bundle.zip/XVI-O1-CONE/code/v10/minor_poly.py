"""v10 item (5): maximal-minor polynomials of the ST matrix over Q(alpha), chamber by chamber.
mode 'pick'  alpha0 branch tag [cert.json]: full exact ST rows at alpha0 (v8 certificate construction; helper functions
             reused read-only from code/v8/apex_certificate.py by source extraction), choose 3 nonsingular maximal
             minors (natural + two shuffled row orders), store alpha-free row tags + columns + gh0 pivots.
mode 'eval'  tag alpha... : at each alpha (same chamber) rebuild ONLY the tagged rows (gh0 pivots fixed) and store the
             exact minors (Q(i)) in logs/v10/minor/<tag>/<alpha>.json (resumable, atomic writes).
Rows/cols/pivots are fixed, so each stored minor is the value of ONE rational function of alpha on the chamber."""
import sys, os, json, time, random
from fractions import Fraction as Fr
mode = sys.argv[1]
if mode == 'pick': a0, br, tag = sys.argv[2], sys.argv[3], sys.argv[4]
else:
    tag = sys.argv[2]; meta = json.load(open(f'logs/v10/minor/{tag}/pick.json')); a0, br = meta['alpha0'], meta['branch']
OUT = f'logs/v10/minor/{tag}'; os.makedirs(OUT, exist_ok=True)
ARGS = list(sys.argv)
src = open('/workspace/XVI-O1-CONE/code/v8/apex_certificate.py').read()
head = src[:src.index("res = {'alpha'")]
def setup(alpha_s):
    g = {}; sys.argv = ['x', alpha_s, br]; exec(head, g); sys.argv = ARGS; return g
SECT = {'HH': ('h', 'h', True), 'CB': ('cb', 'c', False), 'CK': ('K', 'c', False), 'PP': ('phi', 'phi', True)}
def gh0_cands(g):
    return {name: (g['candidates'](g['S'], F1, F2, 4), F1, F2, bose) for name, (F1, F2, bose) in SECT.items()}
def row_tags(g, basis):
    S = g['S']; Ops = g['Ops']; AT = {F: g['unit_atoms'](F, g['DM']) for F in g['FIELDS']}
    RS = {}
    for name, (cands, F1, F2, bose) in basis['all'].items():
        A = set(); B = set()
        for c in cands:
            (C1, n1, m1), (C2, n2, m2) = c[0], c[1]
            for (C, n, m), tgt in (((C1, n1, m1), A), ((C2, n2, m2), B)):
                tgt.add((C, (n, m))); tgt.add((g['REFL'][C], (-n, m)))
        if bose: A = B = A | B
        RS[name] = (A, B)
    nz = g['nonzero_jets']; QGEN = g['QGEN']; negq = g['negq']
    def relevant(F, ops, targets):
        return [(i, cfg) for i, (lab, cfg) in enumerate(AT[F]) if any(nz(op(cfg)) & targets for op in ops)]
    RHH = RS['HH'][0]; RCKA, RCKB = RS['CK']; RCBA, RCBB = RS['CB']
    o, on = Ops(S, QGEN), Ops(S, negq(QGEN))
    h_rel = relevant('h', [lambda c: c, lambda c: on.E(c)], RHH | RCKA)
    c_rel = relevant('c', [lambda c: c, lambda c: o.K2(c)], RHH | RCKB | RCBB)
    b_rel = relevant('b', [lambda c: c, lambda c: on.C2T(c)], RCBA | RCKA)
    def ak(F, i):   # alpha-free atom key (C, n, j, component) with m = eps*nu + 2j
        C, n, m, ci = AT[F][i][0]; comps, dim, kind = g['FIELDS'][F]; sw = comps[C][0]
        a = S.a(sw, n); e = S.eps(kind, sw, n); return (C, n, str((m - e*abs(a))/2), ci)
    tags = []
    for (hi, h) in h_rel:
        for (ci, c) in c_rel:
            if AT['h'][hi][0][1] + AT['c'][ci][0][1] != 0: continue
            for qi in range(len(g['QGRID'])): tags.append(('hc', ak('h', hi), ak('c', ci), qi))
    for (bi, b) in b_rel:
        for (ci, c) in c_rel:
            if AT['b'][bi][0][1] + AT['c'][ci][0][1] != 0: continue
            for qi in range(len(g['QGRID'])): tags.append(('bc', ak('b', bi), ak('c', ci), qi))
    idx = {F: {ak(F, i): i for i in range(len(AT[F]))} for F in ('h', 'c', 'b')}
    return tags, (AT, idx)
def build_row(g, ATI, order, basis, t):
    AT, idx = ATI; t = (t[0], idx['h' if t[0] == 'hc' else 'b'][tuple(t[1])], idx['c'][tuple(t[2])], t[3])
    S = g['S']; Ops = g['Ops']; negq = g['negq']; q = g['QGRID'][t[3]]; ev = g['eval_sym']; GQ = g['GQ']
    def Cv(name, i, a, b, q): F1, F2, bose = basis['sect'][name]; return ev(basis['b'][name][i], a, b, q, bose)
    row = []
    if t[0] == 'hc':
        h = AT['h'][t[1]][1]; c = AT['c'][t[2]][1]; K2c = Ops(S, q).K2(c); Eh = Ops(S, negq(q)).E(h)
        for (name, i) in order:
            row.append(2 * Cv(name, i, h, K2c, q) if name == 'HH' else (Cv(name, i, Eh, c, q) if name == 'CK' else GQ(0)))
    else:
        b = AT['b'][t[1]][1]; c = AT['c'][t[2]][1]; C2Tb = Ops(S, negq(q)).C2T(b)
        for (name, i) in order:
            row.append(Cv(name, i, b, c, q) if name == 'CB' else (Cv(name, i, C2Tb, c, q) if name == 'CK' else GQ(0)))
    return row
def make_basis(g, piv):
    allc = gh0_cands(g); b = {k: [allc[k][0][i] for i in piv[k]] for k in allc}
    order = [(k, i) for k in ['HH', 'CB', 'CK', 'PP'] for i in range(len(b[k]))]
    return {'all': allc, 'b': b, 'sect': {k: allc[k][1:] for k in allc}}, order
def tup(x): return [str(x.re), str(x.im)]
if mode == 'pick':
    T0 = time.time(); g = setup(a0)
    if len(ARGS) > 5: cert = json.load(open(ARGS[5])); piv = {k: cert['gh0'][k]['pivot_candidates'] for k in cert['gh0']}
    else:
        piv = {}; AT = {F: g['unit_atoms'](F, g['DM']) for F in g['FIELDS']}
        for name, (cands, F1, F2, bose) in gh0_cands(g).items():
            cols = [(x, y, q) for x in AT[F1] for y in AT[F2] if x[0][1] + y[0][1] == 0 for q in g['QGRID']]
            rows = [[g['eval_sym'](c, x[1], y[1], q, bose) for (x, y, q) in cols] for c in cands]
            piv[name] = g['rref_rows'](rows)[1]
    basis, order = make_basis(g, piv)
    tags, AT = row_tags(g, basis)
    rows = [build_row(g, AT, order, basis, t) for t in tags]
    print('rows built', len(rows), round(time.time() - T0, 1), flush=True)
    minors = []; rng = random.Random(7); r = None
    for k in range(3):
        idx = list(range(len(rows)))
        if k: rng.shuffle(idx)
        rr, pr, _ = g['rref_rows']([rows[i] for i in idx]); pr = [idx[i] for i in pr]; r = rr
        sub = [rows[i] for i in pr]; rc, pc, _ = g['rref_rows']([list(c) for c in zip(*sub)])
        D = g['det']([[sub[i][j] for j in pc] for i in range(rr)])
        minors.append({'rows': [list(tags[i]) for i in pr], 'cols': pc, 'det_alpha0': tup(D)})
        print('minor', k, rr, round(time.time() - T0, 1), flush=True)
    json.dump({'alpha0': a0, 'branch': br, 'N': len(order), 'rank': r, 'n_rows': len(rows), 'gh0_pivots': piv, 'minors': minors,
               'seconds': round(time.time() - T0, 1)}, open(f'{OUT}/pick.json', 'w'), indent=1)
    print('pick', tag, 'N', len(order), 'rank', r, round(time.time() - T0, 1), flush=True)
else:
    for a in ARGS[3:]:
        fn = f"{OUT}/{a.replace('/', '_')}.json"
        if os.path.exists(fn): continue
        T0 = time.time(); g = setup(a); basis, order = make_basis(g, meta['gh0_pivots'])
        tags, AT = row_tags(g, basis); tagset = {(t[0], tuple(t[1]), tuple(t[2]), t[3]) for t in tags}
        out = []
        for m in meta['minors']:
            miss = [t for t in m['rows'] if (t[0], tuple(t[1]), tuple(t[2]), t[3]) not in tagset]
            assert not miss, ('row tag outside chamber structure', miss[:3], len(tagset))
            sub = [build_row(g, AT, order, basis, tuple(t)) for t in m['rows']]
            out.append(tup(g['det']([[row[j] for j in m['cols']] for row in sub])))
        json.dump({'alpha': a, 'minors': out, 'n_rows_total': len(tags), 'seconds': round(time.time() - T0, 1)}, open(fn + '.tmp', 'w'))
        os.replace(fn + '.tmp', fn); print(a, out[0][1][:40], round(time.time() - T0, 1), flush=True)
