"""v10 item (1): transverse-jet extension of the v7/v8 slice replay (new code; frozen code is only read and exec'd).
The numerator section of cone_v7.replay is exec'd with ONE change: the external transverse momenta PS1,PS2 are kept
as symbols p1,p2 instead of being set to zero. The loop momentum stays on the longitudinal slice (LS1=LS2=0), as in v7/v8
(coverage limitation, declared). The bubble denominator gains the transverse term: (l-p)^2 = (l0-q0)^2-(l3-q3)^2-p1^2-p2^2.
The pole coefficient (w^2 term of the UV expansion, circle average) is then an exact polynomial in q0,q3,p1,p2.
Output per graph/key/pair (s,t): coefficients by transverse degree and helicity weight (p+ = p1+i p2, p- = p1-i p2).
Usage: python3 jet_replay.py GRAPH   (resumable: skips graphs whose json exists)."""
import sys, json, time
from pathlib import Path
sys.path.insert(0, '/workspace/XVI-O1-CONE/code/v8')
import sympy as sp
import cone_v7 as V7
graph = sys.argv[1]
OUT = Path('/workspace/XVI-O1-CONE/logs/v10/jet')/('jet_'+graph+'.json')
if OUT.exists(): print('exists', OUT); sys.exit(0)
src = Path('/workspace/XVI-O1-CONE/code/v8/cone_v7.py').read_text()
a = src.index('def replay(AR, graph, branch, outdir):'); b = src.index('    # Exact circle average via a Laurent variable')
body = src[a:b].replace('def replay(AR, graph, branch, outdir):', 'def numerators_jet(AR, graph):', 1)
old = 'slice_sub = {LS[1]: 0, LS[2]: 0, PS[1]: 0, PS[2]: 0,'
assert body.count(old) == 1
body = body.replace(old, 'slice_sub = {LS[1]: 0, LS[2]: 0, PS[1]: _P1, PS[2]: _P2,')
body += '    return N, dens, pref, u, v, LS\n'
p1, p2 = sp.symbols('p1 p2'); V7._P1, V7._P2 = p1, p2
exec(body, V7.__dict__)
AR = V7.load_engine('/tmp/o1cone_ro/XVI-P/code/p5_entry')
I = sp.I; q0, q3 = V7.q0, V7.q3
t0 = time.time()
N, dens, pref, u, v, LS = V7.numerators_jet(AR, graph)
z, w = sp.symbols('z w', nonzero=True)
lm0, lm3 = I*(z + 1/z)/2/w, (z - 1/z)/(2*I)/w
l2 = -1/w**2
den = l2 if dens == 'tadpole' else l2*((lm0 - q0)**2 - (lm3 - q3)**2 - p1**2 - p2**2)
def pole(expr):
    e = sp.expand(expr.subs({LS[0]: lm0, LS[3]: lm3}))
    if e == 0: return sp.Integer(0)
    ser = sp.series(e/den, w, 0, 3).removeO()
    g2 = sp.expand(ser).coeff(w, 2)
    return sp.expand(sp.cancel(I*V7.laurent_coefficient(g2, z, 0)/(2*sp.pi)))
pp, pm = sp.symbols('pp pm')   # p+ , p-
res = {}
for key, e in N.items():
    e = sp.expand(e)
    if e == 0: continue
    pairs = {}
    for mon, cf in sp.Poly(e, *u, *v).terms():
        s = [i for i in range(3) if mon[i]][0]; t = [i for i in range(3) if mon[3+i]][0]
        if dens == 'tadpole': t = s
        pairs[(s, t)] = pairs.get((s, t), 0) + pole(cf)
    kd = {}
    for (s, t), pv in pairs.items():
        pv = sp.expand(-I*pref*pv)          # same normalisation as the v7 value (before the channel constant)
        if pv == 0: continue
        pv2 = sp.expand(pv.subs({p1: (pp + pm)/2, p2: (pp - pm)/(2*I)}))
        byw = {}
        for mon, cf in sp.Poly(pv2, pp, pm).terms():
            deg, wt = mon[0] + mon[1], mon[0] - mon[1]
            byw.setdefault(f'{deg},{wt}', {})[f'{mon[0]},{mon[1]}'] = str(sp.factor(cf))
        kd[str((s, t))] = byw
    if kd: res[str(key)] = kd
OUT.write_text(json.dumps({'graph': graph, 'dens': dens, 'pref': str(pref), 'status': 'ALGEBRAIC_SLICE_ONLY_TRANSVERSE_EXTERNAL',
    'coverage': 'loop momentum on longitudinal slice (LS1=LS2=0); external p1,p2 exact', 'keys': res,
    'seconds': time.time() - t0}, indent=1))
print('done', graph, len(res), round(time.time() - t0, 1))
