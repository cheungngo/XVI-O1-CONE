#!/bin/bash
# v10 item (5): picks + evaluations for every chamber (resumable: pick skipped if pick.json exists, evals cached)
cd /workspace/XVI-O1-CONE
run() { tag=$1; a0=$2; br=$3; cert=$4; shift 4
  [ -s logs/v10/minor/$tag/pick.json ] || python3 code/v10/minor_poly.py pick $a0 $br $tag $cert
  python3 code/v10/minor_poly.py eval $tag "$@"; }
run CR_c1 3/10 CR logs/v8/cert/apex_cert_3_10_CR.json 3/10 13/50 7/26 5/18 2/7 7/24 3/10 4/13 11/35 17/53 33/100 26/79
run CR_c2 41/100 CR "" 41/100 7/20 4/11 3/8 2/5 5/12 3/7 4/9 9/20 6/13 7/15 12/25 49/100 10/29
run CR_c3 3/5 CR "" 3/5 51/100 8/15 6/11 5/9 4/7 7/12 3/5 8/13 5/8 9/14 13/20 33/50 23/36
run CR_c4 7071/10000 CR logs/v8/cert/apex_cert_7071_10000_CR.json 67/100 7/10 5/7 8/11 3/4 7/9 4/5 5/6 6/7 7/8 9/10 19/20 99/100 41/42
run F_c1 3/10 F logs/v8/cert/apex_cert_3_10_F.json 13/50 7/26 5/18 2/7 7/24 3/10 4/13 11/35 17/53 33/100 26/79
run F_c2 41/100 F "" 41/100 7/20 4/11 3/8 2/5 5/12 3/7 4/9 9/20 6/13 7/15 12/25 49/100 10/29
run F_c3 3/5 F "" 3/5 51/100 8/15 6/11 5/9 4/7 7/12 8/13 5/8 9/14 13/20 33/50 23/36
run F_c4 7071/10000 F logs/v8/cert/apex_cert_7071_10000_F.json 7071/10000 67/100 7/10 5/7 8/11 3/4 7/9 4/5 5/6 6/7 7/8 9/10 19/20 99/100 41/42
echo ALLDONE
