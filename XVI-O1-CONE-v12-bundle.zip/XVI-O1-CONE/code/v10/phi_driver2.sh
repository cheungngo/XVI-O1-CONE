#!/bin/bash
cd /workspace/XVI-O1-CONE
cat logs/v10/jet/phi_grid2.txt | xargs -P 7 -I{} sh -c 'python3 code/v10/phi_mixed.py {} >> logs/v10/jet/phi_driver2.log 2>&1'
echo ALLDONE >> logs/v10/jet/phi_driver2.log
