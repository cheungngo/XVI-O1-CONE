#!/bin/bash
cd /workspace/XVI-O1-CONE
echo 3/10 41/100 3/5 7071/10000 | tr ' ' '\n' | xargs -P 2 -I{} sh -c 'python3 code/v10/vector_fp.py {} >> logs/v10/vector_fp/driver.log 2>&1'
echo ALLDONE >> logs/v10/vector_fp/driver.log
