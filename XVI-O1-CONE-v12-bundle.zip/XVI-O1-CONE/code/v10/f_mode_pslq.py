"""v10 item (4): PSLQ identification of the F k=-1 mode I(mu, 2-mu) (mu = 1/alpha in (1,2)) at 50 digits.
Values from the closed-form quadrature I_gen (v9), dps 60; resumable cache logs/v10/fmode/<mu>.json."""
import sys, os, json
sys.path.insert(0, '/workspace/XVI-O1-CONE/code/v9')
import mpmath as mp
from modefun import I_gen
mp.mp.dps = 60
os.makedirs('logs/v10/fmode', exist_ok=True)
for m in sys.argv[1:]:
    fn = f"logs/v10/fmode/{m.replace('/', '_')}.json"
    if os.path.exists(fn): continue
    p, q = map(int, m.split('/')); mu = mp.mpf(p)/q
    v = I_gen(mu, 2 - mu)
    json.dump({'mu': m, 'I_F': mp.nstr(v, 55)}, open(fn + '.tmp', 'w')); os.replace(fn + '.tmp', fn); print(m, mp.nstr(v, 50), flush=True)
