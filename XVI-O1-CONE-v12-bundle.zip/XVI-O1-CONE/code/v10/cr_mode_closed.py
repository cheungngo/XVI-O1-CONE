"""v10 item (4): exact closed form of the CR k=-1 mode I(mu, mu-2) = -((mu-1)/mu) sum_n (n+1)! K_n/(mu+1)_n,
K_n = 2/(n+4) - 5/(n+3) + 3/(n+2).   beta = mu-1.
 (n+1)! G(mu+1)/G(mu+1+n) = mu(mu-1) B(n+2, beta);  sum_n s^{n+1}/(n+b) = s^{1-b}[-log(1-s) - sum_{j<b} s^j/j];
 S_b = mu(mu-1) G_b,  G_b = lim_{a->2-b} [ B(a,beta)(psi(a+beta)-psi(beta)) - sum_{j<b} B(a+j,beta)/j ]  (analytic continuation),
 Laurent data: Gamma(-k+e) = (-1)^k/k! [1/e + psi(k+1)] + O(e);  G(beta)/G(beta-k+e) = P_k [1 - e psi(beta-k)],
 P_k = (beta-1)...(beta-k);  psi(beta-k) = psi(beta) - sum_{i=1}^k 1/(beta-i);  psi1(beta-k) = psi1(beta) + sum 1/(beta-i)^2.
Symbols: Ps = psi(beta), T = psi1(beta), g = Euler gamma (must cancel).  Checked against direct sums and the 30-digit series."""
import sympy as sp, mpmath as mp, json, sys
sys.path.insert(0, '/workspace/XVI-O1-CONE/code/v9')
mu, e, Ps, T, g = sp.symbols('mu epsilon Psi T gamma_E'); be = mu - 1
def psi_shift(k): return Ps - sum(1/(be - i) for i in range(1, k+1))
def psi1_shift(k): return T + sum(1/(be - i)**2 for i in range(1, k+1))
def H(k): return sum(sp.Rational(1, i) for i in range(1, k+1))
def Pk(k): return sp.prod([be - i for i in range(1, k+1)]) if k else sp.Integer(1)
def Bexp(aint):
    """Laurent expansion (c_{-1}, c_0) of B(aint+e, beta) for integer aint."""
    if aint >= 1:
        return 0, sp.gamma(aint)*sp.prod([1/(be + i) for i in range(0, aint)])   # B(n,beta) = (n-1)!/(beta)_n
    k = -aint; pre = (-1)**k/sp.factorial(k)*Pk(k)
    return pre, pre*((-g + H(k)) - psi_shift(k))
def BDexp(aint):
    """finite part and pole of B(aint+e,beta)*(psi(aint+e+beta)-psi(beta))"""
    if aint >= 1:
        D0 = sum(1/(be + i) for i in range(0, aint)); return 0, Bexp(aint)[1]*D0
    k = -aint; pre = (-1)**k/sp.factorial(k)*Pk(k)
    D0 = psi_shift(k) - Ps; D1 = psi1_shift(k)
    # pre [1/e + psi(k+1)][1 - e psi(beta-k)][D0 + e D1]
    pole = pre*D0
    fin = pre*(D1 + ((-g + H(k)) - psi_shift(k))*D0)
    return pole, fin
def G(b):
    a0 = 2 - b
    pole, fin = BDexp(a0)
    for j in range(1, b):
        p, f = Bexp(a0 + j); pole -= sp.Rational(1, j)*p; fin -= sp.Rational(1, j)*f
    assert sp.simplify(pole) == 0, ('pole', b, sp.simplify(pole))
    return sp.simplify(fin)
Gs = {b: G(b) for b in (2, 3, 4)}
for b in Gs: print('G', b, Gs[b])
I_cr = sp.expand(-(mu-1)**2*(2*Gs[4] - 5*Gs[3] + 3*Gs[2]))
assert I_cr.coeff(g) == 0 and sp.simplify(I_cr.coeff(Ps)) == 0, 'gamma/psi must cancel'
R1 = sp.factor(I_cr.subs({T: 0, Ps: 0, g: 0})); R2 = sp.factor(I_cr.coeff(T))
print('I_CR = R1 + R2 psi1(mu-1):  R1 =', R1, '  R2 =', R2)
mp.mp.dps = 34
from modefun import I_minus
f1 = sp.lambdify(mu, R1, 'mpmath'); f2 = sp.lambdify(mu, R2, 'mpmath')
chk = {}
for m in sys.argv[1:] or ['5/3', '10000/7071']:
    p, q = map(int, m.split('/')); mv = mp.mpf(p)/q
    v1 = I_minus(mv); v2 = f1(mv) + f2(mv)*mp.psi(1, mv-1)
    chk[m] = {'series': mp.nstr(v1, 30), 'closed': mp.nstr(v2, 30), 'absdiff': mp.nstr(abs(v1-v2), 3)}; print(m, chk[m], flush=True)
json.dump({'G': {b: str(v) for b, v in Gs.items()}, 'R1': str(R1), 'R2': str(R2),
           'form': 'I_CR(mu) = R1(mu) + R2(mu)*psi1(mu-1), mu = 1/alpha', 'checks_dps34': chk},
          open('/workspace/XVI-O1-CONE/logs/v10/cr_mode_closed.json', 'w'), indent=1)
