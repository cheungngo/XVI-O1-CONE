"""Cross-check of t1_fp.T1 (closed finite part) against the independent shell continuation (mixed_r2_check.shells_x) at mixed (mu,nu)."""
import mpmath as mp, json, sys
sys.path.insert(0, '/workspace/XVI-O1-CONE/code/v10')
mp.mp.dps = 50
from t1_fp import T1
import importlib.util
spec = importlib.util.spec_from_file_location('mc', '/workspace/XVI-O1-CONE/code/v10/mixed_r2_check.py')
src = open('/workspace/XVI-O1-CONE/code/v10/mixed_r2_check.py').read().split('from mixed_r2 import shells')[0]
ns = {}; exec(src, ns)
out = []
for (x, mu, nu) in [('0.3', '1.3', '0.6'), ('0.55', '2.2', '0.7'), ('0.8', '1.75', '0.75'), ('0.4', '3.5', '1.5')]:
    x, mu, nu = mp.mpf(x), mp.mpf(mu), mp.mpf(nu)
    a = T1(x, mu, nu); b, r = ns['zfit'](ns['shells_x'](1, mu, nu, x), mp.mpf(1)/2)
    out.append([str(x), str(mu), str(nu), mp.nstr(a, 25), mp.nstr(b, 25), mp.nstr(abs(a-b), 3), mp.nstr(r, 3)])
    print(out[-1], flush=True)
json.dump(out, open('/workspace/XVI-O1-CONE/logs/v10/jet/t1_fp_check.json', 'w'), indent=1)
