"""v10 item (4): verify the identified closed forms at fresh angles (not used in the fit), 50 digits.
 CR mode (derived):     I_CR(mu) = (mu-1)(6mu^2+3mu-2)/6 - (mu-1)^3(mu+1) psi1(mu-1)
 F mode (PSLQ, fitted on mu in {6/5,5/4,4/3,7/5,3/2,8/5,5/3}, checked on 7/4, 9/5):
                        I_F(mu)  = (mu-1)(59mu^3-57mu^2-62mu+48)/36 - (mu-1)^3(mu+1) pi^2/6
 DeltaJ(alpha) = I_CR - I_F = (mu-1)(-59mu^3+93mu^2+80mu-60)/36 - (mu-1)^3(mu+1)[psi1(mu-1) - pi^2/6],  mu = 1/alpha."""
import sys, json
sys.path.insert(0, '/workspace/XVI-O1-CONE/code/v9')
import mpmath as mp
from modefun import I_gen, I_minus
mp.mp.dps = 55
def Icr(m): return (m-1)*(6*m**2+3*m-2)/6 - (m-1)**3*(m+1)*mp.psi(1, m-1)
def If(m): return (m-1)*(59*m**3-57*m**2-62*m+48)/36 - (m-1)**3*(m+1)*mp.pi**2/6
def dJ(m): return (m-1)*(-59*m**3+93*m**2+80*m-60)/36 - (m-1)**3*(m+1)*(mp.psi(1, m-1) - mp.pi**2/6)
fresh = {'sqrt2': mp.sqrt(2), '10000/7071': mp.mpf(10000)/7071, '137/100': mp.mpf(137)/100, '193/100': mp.mpf(193)/100,
         'golden': (1+mp.sqrt(5))/2, 'pi/2': mp.pi/2, '5/2 (alpha=2/5)': mp.mpf(5)/2, '29/10 (alpha=10/29)': mp.mpf(29)/10,
         '101/100': mp.mpf(101)/100}
out = {}
for k, m in fresh.items():
    f_num = I_gen(m, 2-m); c_num = I_gen(m, m-2)
    out[k] = {'mu': mp.nstr(m, 20), 'F_quad': mp.nstr(f_num, 45), 'F_closed_diff': mp.nstr(abs(f_num - If(m)), 3),
              'CR_quad': mp.nstr(c_num, 45), 'CR_closed_diff': mp.nstr(abs(c_num - Icr(m)), 3),
              'DeltaJ_closed': mp.nstr(dJ(m), 40)}
    print(k, out[k]['F_closed_diff'], out[k]['CR_closed_diff'], out[k]['DeltaJ_closed'][:25], flush=True)
# against the v9 table (25 digits)
import glob
v9 = {}
for f in glob.glob('/workspace/XVI-O1-CONE/logs/v9/hidden/dJ_*.json'):
    d = json.load(open(f)); p, q = map(int, d['alpha'].split('/')); m = mp.mpf(q)/p
    v9[d['alpha']] = mp.nstr(abs(mp.mpf(d['DeltaJ']) - dJ(m)), 3)
print('v9 table max diff', max(v9.values(), key=lambda s: mp.mpf(s)))
json.dump({'fresh': out, 'v9_table_absdiff': v9}, open('/workspace/XVI-O1-CONE/logs/v10/dJ_closed_verify.json', 'w'), indent=1)
