"""v10 item (1)/(2): analysis of logs/v10/jet/jet_<G>.json.
(a) order-0 check: sum_s pole^{(0)}_{ss} z_s must equal the v8 catalogue value (logs/v8/replay/spec_<G>_<B>.json) on every computed key;
(b) jet census: by transverse degree/weight and channel pair;
(c) declared dressing of the same-channel weight-0 p_perp^2 terms with d_s (scheme A = Theorem D) and d_s+11 alpha/180 (scheme Z).
Everything else (mixed pairs at jet level, weight +-1, +-2 terms, degree 4) is listed as OPEN, never as zero."""
import json, sys
from pathlib import Path
sys.path.insert(0, '/workspace/XVI-O1-CONE/code/v8')
import sympy as sp
import cone_v7 as V7
al = V7.alpha
L = Path('/workspace/XVI-O1-CONE/logs/v10/jet')
def Dab(a, b):
    return V7.D(a, b)
def dws(branch, scheme):
    a = al
    d = [Dab(a, 0), Dab(a, a), Dab(a, 2*a - 1) if branch == 'F' else Dab(a, 2*a)]
    if scheme == 'Z': d = [x + 11*a/180 for x in d]
    return d
G = ['D01', 'D02', 'D03', 'D04', 'D05a', 'D06', 'D11', 'D12', 'D13']
report = {'order0_check': {}, 'census': {}, 'dressed_r2': {}, 'open_jet_entries': {}}
for g in G:
    f = L/f'jet_{g}.json'
    if not f.exists(): report['census'][g] = 'NOT_RUN'; continue
    J = json.loads(f.read_text())['keys']
    cen = {}
    for key, kd in J.items():
        for pair, byw in kd.items():
            s, t = eval(pair)
            for dw in byw:
                tag = ('same' if s == t else 'mixed') + ':' + dw
                cen[tag] = cen.get(tag, 0) + 1
    report['census'][g] = cen
    for br in ('CR', 'F'):
        spec = json.loads(Path(f'/workspace/XVI-O1-CONE/logs/v8/replay/spec_{g}_{br}.json').read_text())
        vals = spec['Gamma_pole_coeff_of_1/(4-d)']; st = spec['key_status']
        cs = V7.physical_cs(br); bad = []; nchk = 0
        for key in st:
            if st[key] == 'EXCLUDED_MIXED_CHANNEL': continue
            tot = 0; mixed0 = False
            for pair, byw in J.get(key, {}).items():
                s, t = eval(pair)
                if '0,0' in byw:
                    c0 = sp.sympify(byw['0,0']['0,0'])
                    if s != t: mixed0 = True
                    tot += c0*cs[s]
            ref = sp.sympify(vals.get(key, 0), locals={'alpha': al})
            nchk += 1
            if mixed0 or sp.simplify(tot - ref) != 0: bad.append(key)
        report['order0_check'][f'{g}_{br}'] = {'checked_keys': nchk, 'mismatch': bad}
        for sch in ('A', 'Z'):
            d = dws(br, sch); dr = {}
            for key, kd in J.items():
                val = 0; part = False
                for pair, byw in kd.items():
                    s, t = eval(pair)
                    if '2,0' in byw:
                        if s == t: val += sp.sympify(byw['2,0']['1,1'])*d[s]
                        else: part = True
                if val != 0 or part:
                    dr[key] = {'same_channel_value_coeff_of_p+p-': str(sp.factor(val)), 'PARTIAL_mixed_missing': part}
            report['dressed_r2'][f'{g}_{br}_{sch}'] = dr
    op = {}
    for key, kd in J.items():
        for pair, byw in kd.items():
            s, t = eval(pair)
            for dw in byw:
                deg, wt = map(int, dw.split(','))
                if deg == 0: continue
                if deg == 2 and wt == 0 and s == t: continue
                op.setdefault(dw + (':mixed' if s != t else ':same'), 0)
                op[dw + (':mixed' if s != t else ':same')] += 1
    report['open_jet_entries'][g] = op
# alpha=1 (F) and alpha=1/2 (CR=F) checks of the dressed same-channel values (scheme A)
chk = {}
for k, dr in report['dressed_r2'].items():
    if not k.endswith('_A'): continue
    for key, e in dr.items():
        v = sp.sympify(e['same_channel_value_coeff_of_p+p-'], locals={'alpha': al})
        if k.split('_')[1] == 'F': chk.setdefault('alpha1_F_nonzero', []).append(k + key) if sp.simplify(v.subs(al, 1)) != 0 else None
for g in G:
    a, b = report['dressed_r2'].get(f'{g}_CR_A', {}), report['dressed_r2'].get(f'{g}_F_A', {})
    for key in set(a) | set(b):
        va = sp.sympify(a.get(key, {}).get('same_channel_value_coeff_of_p+p-', 0), locals={'alpha': al}); vb = sp.sympify(b.get(key, {}).get('same_channel_value_coeff_of_p+p-', 0), locals={'alpha': al})
        if sp.simplify((va - vb).subs(al, sp.Rational(1, 2))) != 0: chk.setdefault('half_CR_ne_F', []).append(g + key)
report['checks'] = chk
(L/'jet_analysis.json').write_text(json.dumps(report, indent=1))
print(json.dumps({k: report[k] for k in ('order0_check', 'census', 'open_jet_entries', 'checks')}, indent=1))
