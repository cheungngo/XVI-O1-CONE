"""Checks of the scheme-Z shell continuation: (i) w=-1 continued sum vs 1/(2(mu+nu)); (ii) pointwise T_1(x;mu,mu) vs mu(mu^2-1)/3."""
import mpmath as mp, json, sys
sys.path.insert(0, '/workspace/XVI-O1-CONE/code/v10')
mp.mp.dps = 50
lg = mp.loggamma
def zfit(t, a, J=14, N0=120):
    Nmax = len(t); Ns = list(range(Nmax - 2*J, Nmax, 2))[:J]
    A = mp.matrix([[mp.mpf(n)**(a - j) for j in range(J)] for n in Ns]); c = mp.lu_solve(A, mp.matrix([t[n] for n in Ns]))
    resid = max(abs(t[n] - sum(c[j]*mp.mpf(n)**(a-j) for j in range(J))) for n in range(Nmax - 2*J - 20, Nmax - 2*J))
    return sum(t[:N0]) + sum(c[j]*mp.zeta(j - a, N0) for j in range(J)), resid
def shells_x(w, mu, nu, x, Nmax=260):
    h = (mu + nu)/2; out = []
    for N in range(Nmax):
        s = 0
        for k in range(N + 1):
            l = N - k
            s += mp.exp(lg(N+h+w+1) + lg(N+h+1) - lg(k+1) - lg(l+1) - lg(k+mu+1) - lg(l+nu+1) + (2*k+mu)*mp.log(x) + (2*l+nu)*mp.log(1-x))
        out.append((4*x*(1-x))**(w+1)/4*s)
    return out
from mixed_r2 import shells
res = {}
v, r = zfit(shells(-1, mp.mpf('1.3'), mp.mpf('0.6'), 260), mp.mpf(-3)/2); res['w-1_int'] = [mp.nstr(v, 20), mp.nstr(1/mp.mpf('3.8'), 20), mp.nstr(r, 3)]
print(res, flush=True)
for x in ['0.5', '0.3']:
    v, r = zfit(shells_x(1, mp.mpf('1.3'), mp.mpf('1.3'), mp.mpf(x)), mp.mpf(1)/2); res['T1_same_x'+x] = [mp.nstr(v, 20), mp.nstr(mp.mpf('1.3')*(mp.mpf('1.3')**2-1)/3, 20), mp.nstr(r, 3)]
    print(res, flush=True)
json.dump(res, open('/workspace/XVI-O1-CONE/logs/v10/jet/mixed_r2_check.json', 'w'), indent=1)
