"""v10 item (6): finite parts of the vector-type hidden keys (1,1),(2,2),(6,6),(8,8) and (1,6),(2,8),(6,1),(8,2)
in a DECLARED scheme: per-mode scheme Z (radial Mellin; Tr_mode e^{-A_mu} = -mu/2), same-k pairing, k-zeta regulator |k|^{-eps}
on the mode sum, finite part = eps^0 term (pole coefficient reported and checked against v9 Prop. v9log/v9vector).
Per mode, for a pair density rho(x) with R(x)=int_0^x rho:   I_rho(mu,nu) = -R(1) nu/2 - (mu^2-nu^2) int_0^1 R g(x;mu,nu) dx
(integration by parts; f(1)-f(0)=(mu-nu)/2 is consistent with int g = 1/(2(mu+nu))).
Channels: 0: |k|/alpha ; 1: |k+alpha|/alpha (no branch flip).  Pair (s,t): mu from channel s (u-line, weight 1-x), nu from t (x).
Output logs/v10/vector_fp/<alpha>.json (resumable)."""
import mpmath as mp, json, sys, os
from fractions import Fraction as Fr
import sympy as sp
mp.mp.dps = 40
OUT = '/workspace/XVI-O1-CONE/logs/v10/vector_fp'; os.makedirs(OUT, exist_ok=True)
def g(x, mu, nu):
    d = mu - nu; h = (mu + nu)/2
    return mp.gamma(h)*mp.gamma(h+1)/(4*mp.gamma(mu+1)*mp.gamma(nu+1))*mp.hyp2f1(d/2+1, d/2, mu+1, x)*mp.hyp2f1(1-d/2, -d/2, nu+1, 1-x)
def moments(mu, nu):
    # [nu, (mu^2-nu^2) int x^j g, j=1..3]
    f = lambda j: mp.quad(lambda x: x**j*g(x, mu, nu), [0, 0.5, 1], method='gauss-legendre')
    c = mu*mu - nu*nu
    return [nu] + [c*f(j) for j in (1, 2, 3)]
def families(pair, a):
    s, t = pair
    ch = lambda c, k: abs(k + c*a)/a
    # k >= 0 family indexed by m=k (regulator m^{-eps} for m>=1), k<0 family indexed by m=-k>=1
    return {'kpos': (lambda m: (ch(s, m), ch(t, m)), 0), 'kneg': (lambda m: (ch(s, -m), ch(t, -m)), 1)}
def regsum(fun, m0, M=90, J=10, K=50):
    vals = {m: fun(m) for m in range(m0, M + 1)}
    nc = len(vals[m0]); res = []
    for c in range(nc):
        Ms = list(range(M - 2*(J + 2) + 2, M + 1, 2))
        pw = [1, 0] + [-j for j in range(1, J + 1)]
        A = mp.matrix([[(mp.mpf(m)/M)**p for p in pw] for m in Ms]); b = mp.matrix([vals[m][c] for m in Ms])
        co = mp.lu_solve(A, b)
        co = [co[i]*mp.mpf(M)**(-pw[i]) for i in range(len(pw))]
        chk = max(abs(vals[m][c] - sum(co[i]*mp.mpf(m)**pw[i] for i in range(len(pw)))) for m in range(M - 2*(J+2) - 10, M - 2*(J+2)))
        head = sum(vals[m][c] for m in range(m0, K))
        tail = co[0]*mp.zeta(-1, K) + co[1]*mp.zeta(0, K) + co[2]*(-mp.digamma(K)) + sum(co[2+j-1]*mp.zeta(j, K) for j in range(2, J + 1))
        res.append({'FP': head + tail, 'pole': co[2], 'lin': co[0], 'const': co[1], 'fitcheck': chk})
    return res
if __name__ == '__main__':
    for al in sys.argv[1:]:
        f = os.path.join(OUT, al.replace('/', '_') + '.json')
        if os.path.exists(f): continue
        a = mp.mpf(Fr(al).numerator)/Fr(al).denominator
        out = {}
        for pair in [(0, 1), (1, 0)]:
            for name, (fun, m0) in families(pair, a).items():
                r = regsum(lambda m: moments(*fun(m)), m0)
                out[f'{pair}{name}'] = [{k: mp.nstr(v, 20) for k, v in d.items()} for d in r]
                print(al, pair, name, [d['FP'] for d in out[f'{pair}{name}']], flush=True)
        json.dump(out, open(f, 'w'), indent=1)
