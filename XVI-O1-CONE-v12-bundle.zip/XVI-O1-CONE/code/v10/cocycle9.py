"""v10 item (5): the ninth cocycle on F above 1/2 and the alpha-degree of ST row entries.
For each alpha (chamber tag fixed pivots), build ALL ST rows exactly, compute Z(alpha); intersect the Z(alpha) over the
list (exact).  If dim of the intersection is 9 = dim Z(alpha), Z is alpha-independent on the sampled set.
Degree test: every row entry, as a function of t = 1/alpha, is fitted by a polynomial through deg+1 points and checked
at all other points (reports the maximal degree needed, over all entries)."""
import sys, json, time
from fractions import Fraction as Fr
tag = sys.argv[1]; alist = sys.argv[2:]
sys.argv = ['minor_poly.py', 'eval', tag]
src = open('/workspace/XVI-O1-CONE/code/v10/minor_poly.py').read(); src = src[:src.index("if mode == 'pick':\n    T0")]
exec(src)
ROWS = {}; Zs = {}
for a in alist:
    T0 = time.time(); g = setup(a); basis, order = make_basis(g, meta['gh0_pivots']); tags, ATI = row_tags(g, basis)
    key = lambda t: (t[0], tuple(t[1]), tuple(t[2]), t[3])
    rows = {key(t): [g['GQ'].c(x) for x in build_row(g, ATI, order, basis, t)] for t in tags}
    ROWS[a] = rows; Z = g['nullspace'](list(rows.values()), len(order)); Zs[a] = Z
    print(a, 'rows', len(rows), 'dimZ', len(Z), round(time.time() - T0, 1), flush=True)
common = set.intersection(*[set(r) for r in ROWS.values()])
# intersection of Z spaces: vectors z with ST(alpha) z = 0 for all alpha  <=> nullspace of stacked rows
stack = []
for a in alist: stack += [ROWS[a][k] for k in common]
# dedupe identical rows
seen = set(); st2 = []
for r in stack:
    h = tuple((x.re, x.im) for x in r)
    if h not in seen: seen.add(h); st2.append(r)
Zc = g['nullspace'](st2, len(order))
print('common rows', len(common), 'distinct stacked rows', len(st2), 'dim common Z', len(Zc), flush=True)
# degree test on common rows
tvals = [1/Fr(a) for a in alist]
def lagrange_fit_check(vals):
    n = len(vals)
    for d in range(0, n - 1):
        pts = list(zip(tvals[:d+1], vals[:d+1]))
        ok = True
        for t, v in zip(tvals[d+1:], vals[d+1:]):
            s = 0
            for i, (ti, vi) in enumerate(pts):
                L = 1
                for j, (tj, _) in enumerate(pts):
                    if j != i: L *= (t - tj)/(ti - tj)
                s += vi*L
            if s != v: ok = False; break
        if ok: return d
    return None
maxdeg = 0; undetermined = 0
for k in common:
    for j in range(len(order)):
        for part in ('re', 'im'):
            vals = [getattr(ROWS[a][k][j], part) for a in alist]
            if all(v == vals[0] for v in vals): continue
            d = lagrange_fit_check(vals)
            if d is None: undetermined += 1
            else: maxdeg = max(maxdeg, d)
res = {'tag': tag, 'alphas': alist, 'dimZ': {a: len(Zs[a]) for a in alist}, 'n_common_rows': len(common),
       'dim_common_Z': len(Zc), 'max_entry_degree_in_1_over_alpha': maxdeg, 'entries_without_low_degree_fit': undetermined,
       'common_Z_basis': [[[str(x.re), str(x.im)] for x in z] for z in Zc],
       'order': [list(o) for o in order], 'labels': {str(i): list(map(str, basis['b'][o[0]][o[1]][:2])) + [basis['b'][o[0]][o[1]][4]] for i, o in enumerate(order)}}
json.dump(res, open(f'logs/v10/minor/{tag}/cocycle9.json', 'w'), indent=1)
print({k: v for k, v in res.items() if k not in ('common_Z_basis', 'order', 'labels')})
