"""v10 item (2a): Feynman-fraction density of the D04 transverse-jet pole (pair (1,0): graviton channel 1 on the l-line,
phi channel 0 on the (l-p) line, x = fraction of the (l-p) line as in v8 slice_engine.x_density).
On the slice (l_perp=0):  D = (1-x) l^2 + x (l-p)^2 = (l_L - x p_L)^2 + x(1-x) P_L^2 - x p_perp^2."""
import sys, json
from pathlib import Path
sys.path.insert(0, '/workspace/XVI-O1-CONE/code/v8')
import sympy as sp
import cone_v7 as V7
import slice_engine as SE
src = Path('/workspace/XVI-O1-CONE/code/v8/cone_v7.py').read_text()
a = src.index('def replay(AR, graph, branch, outdir):'); b = src.index('    # Exact circle average via a Laurent variable')
body = src[a:b].replace('def replay(AR, graph, branch, outdir):', 'def numerators_jet(AR, graph):', 1)
body = body.replace('slice_sub = {LS[1]: 0, LS[2]: 0, PS[1]: 0, PS[2]: 0,', 'slice_sub = {LS[1]: 0, LS[2]: 0, PS[1]: _P1, PS[2]: _P2,')
body += '    return N, dens, pref, u, v, LS\n'
p1, p2 = sp.symbols('p1 p2'); V7._P1, V7._P2 = p1, p2
exec(body, V7.__dict__)
AR = V7.load_engine('/tmp/o1cone_ro/XVI-P/code/p5_entry')
N, dens, pref, u, v, LS = V7.numerators_jet(AR, 'D04')
I = sp.I; q0, q3 = V7.q0, V7.q3
x, w, L0, L3, ps = sp.symbols('x w L0 L3 ps')
pairs = SE.split_pairs(N[(0, 0)], u, v, dens)
eta = {(0, 0): 1, (3, 3): -1, (0, 3): 0, (3, 0): 0}
res = {}
for st, cf in pairs.items():
    e = sp.expand(cf.subs({LS[0]: L0/w + x*q0, LS[3]: L3/w + x*q3}, simultaneous=True))
    den = ((L0**2 - L3**2)/w**2 + x*(1 - x)*(q0**2 - q3**2) - x*(p1**2 + p2**2))**2
    ser = sp.series(e/den, w, 0, 3).removeO()
    g2 = sp.expand(ser).coeff(w, 2)
    rho = sp.expand(-I*pref*SE.angular_pole(g2, L0, L3, eta))
    rho = sp.expand(rho.subs({p1: sp.sqrt(ps), p2: 0}))
    res[str(st)] = {'p_perp^2': str(sp.factor(rho.coeff(ps, 1))), 'p_perp^0': str(sp.factor(rho.coeff(ps, 0))),
                    'int_p_perp^2': str(sp.factor(sp.integrate(rho.coeff(ps, 1), (x, 0, 1)))),
                    'int_p_perp^0': str(sp.factor(sp.integrate(rho.coeff(ps, 0), (x, 0, 1))))}
print(json.dumps(res, indent=1))
json.dump(res, open('/workspace/XVI-O1-CONE/logs/v10/jet/density_D04.json', 'w'), indent=1)
