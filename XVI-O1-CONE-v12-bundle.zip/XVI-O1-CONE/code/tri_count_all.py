"""v3 item (5): trilinear apex candidates with ALL lattice jets (n != 0 allowed), rotation charge n1+n2+n3=0.
Needed at resonant alpha, where n != 0 jets can enter the integer power-counting window."""
import sys
from fractions import Fraction as Fr
sys.path.insert(0, '/workspace/XVI-O1-CONE/code')
import apex_jets as AJ
from apex_jets import pairings, FIELDS, SCA
FIELDS['phis'] = (SCA, 2, 'scalar')
def tri_cands(S, F1, F2, F3, T):
    out = []
    d = [FIELDS[F][1] for F in (F1, F2, F3)]
    J = [S.jets(F, T) for F in (F1, F2, F3)]
    for j1 in J[0]:
        for j2 in J[1]:
            for j3 in J[2]:
                if j1[1] + j2[1] + j3[1] != 0: continue
                k = Fr(T) - sum(d) - Fr(j1[2]) - Fr(j2[2]) - Fr(j3[2])
                if k.denominator != 1 or k < 0: continue
                k = int(k); r = [FIELDS[F][0][j[0]][1] for F, j in ((F1, j1), (F2, j2), (F3, j3))]
                for k1 in range(k + 1):
                    k2 = k - k1
                    slots = [('A', i) for i in range(r[0])] + [('B', i) for i in range(r[1])] + [('C', i) for i in range(r[2])] + [('p1', i) for i in range(k1)] + [('p2', i) for i in range(k2)]
                    if len(slots) % 2: continue
                    seen = set()
                    for pr in pairings(slots):
                        key = tuple(sorted(tuple(sorted((x[0], x[1] if x[0] not in ('p1', 'p2') else 0) for x in pair)) for pair in pr))
                        if key in seen: continue
                        seen.add(key); out.append((j1, j2, j3, r, k1, k2, pr))
    return out
