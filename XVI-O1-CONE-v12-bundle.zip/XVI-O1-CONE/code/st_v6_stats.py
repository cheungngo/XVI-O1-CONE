"""v6: per-graph contributions to the hh ST row (CR, F): how many coefficient equations are nontrivial cancellations."""
import sys, json, sympy as sp
res = {}
for br in ['CR', 'F']:
    sys.argv = ['st_v6.py', 'logs/v4/spec_{g}_' + br + '.json', br]
    src = open('code/st_v6.py').read().split("out = {'branch'")[0]
    ns = {}; exec(src, ns)
    per = {}
    allm = set()
    for g in ['D01', 'D02', 'D03', 'D11', 'D12']:
        t1, _ = ns['row']([g]) if g != 'D12' else ns['row'](['D12'])
        C = ns['coeffs'](t1); per[g] = C; allm |= set(C)
    _, t2 = ns['row'](['D01']); G = ns['coeffs'](t2); allm |= set(G)
    lam = -2 * sp.I
    rows = []
    for m in sorted(allm):
        contrib = {g: per[g].get(m, 0) for g in per}; gk = G.get(m, 0)
        tot = sp.simplify(sum(contrib.values()) + lam * gk)
        rows.append({'monomial(h00,h03,h33,f0,c0,c3,q0,q3)': str(m), **{g: str(v) for g, v in contrib.items()}, 'lam*G': str(sp.factor(lam * gk)), 'total': str(tot)})
    res[br] = {'n_monomials_with_any_nonzero_contribution': len(allm), 'n_cancelling_between_graphs': sum(1 for r in rows if r['lam*G'] == '0'), 'rows': rows}
    print(br, len(allm), 'monomials;', res[br]['n_cancelling_between_graphs'], 'cancel among hh graphs alone; all totals zero:', all(r['total'] == '0' for r in rows))
json.dump(res, open('logs/v6/st_v6_stats.json', 'w'), indent=1)
