"""v6 item (a): predict the ST convention constant lam from XVI-P tree normalisations (read-only import).
ST (one loop, b eliminated, ghost equation used):  sum_a [dS/dK'_a] [dG1/dh_a] + sum_a [dG1/dK'_a] [dS_inv/dh_a] = 0,
dS/dK'_a = val(V_K_c)(a,mu) c^mu = i*A_GH*(p_m c_n + p_n c_m)   (XVI-P check K_c_equals_a_dc_plus_dc; p = c-leg momentum),
dS_inv/dh_a = N * Eup_a(h)  (fit N on de Donder-satisfying h, where the F^T F gauge-fixing part vanishes).
=> lam_pred = N / (i*A_GH) in the normalisation of st_v6.py."""
import sys, json, sympy as sp
sys.path.insert(0, '/tmp/o1cone_ro/XVI-P/code/p5_entry')
import amplitude_rules as AR
F = AR.F; I = sp.I
q0, q3 = sp.symbols('q0 q3')
V2 = F.grav_vertex(2)
k = [F.ksym(leg) for leg in range(2)]
names = {4 * leg + r: k[leg][r] for leg in range(2) for r in range(4)}
print('V2 phase', V2.phase, 'legs', getattr(V2, 'legs', None), 'A_GH', F.A_GH, 'HC', F.HC)
ETA = [1, -1, -1, -1]; HC = list(F.HC)
p = [q0, 0, 0, q3]
def V2ab(a, b, s0=1):
    P = V2.T.get((a, b))
    if P is None: return 0
    e = (I ** V2.phase) * P.to_sympy(names)
    return sp.expand(e.subs({**{k[0][r]: s0 * p[r] for r in range(4)}, **{k[1][r]: -s0 * p[r] for r in range(4)}}))
LAT = [0, 3, 9, 4, 7]
h = sp.symbols('x0:10')
# de Donder-satisfying lattice h: F_nu = p^mu h_mu nu - 1/2 p_nu tr h = 0
hm = [[0]*4 for _ in range(4)]
for i, (m, n) in enumerate(HC):
    if i in LAT: hm[m][n] = hm[n][m] = (h[4] if i == 7 else h[i])
pu = [ETA[i] * p[i] for i in range(4)]
tr = sum(ETA[i] * hm[i][i] for i in range(4))
Fdd = [sp.expand(sum(pu[m] * hm[m][n] for m in range(4)) - sp.Rational(1, 2) * p[n] * tr) for n in range(4)]
sol = sp.solve([Fdd[0], Fdd[3]], [h[0], h[3]], dict=True)[0]; print('de Donder solution', sol)
hv = {i: (sol.get(h[i], h[i]) if i in LAT else 0) for i in range(10)}
hv[7] = hv[4]  # helicity-zero transverse trace f0
# my E (lower) and Eup with (2-delta)
hm2 = [[0]*4 for _ in range(4)]
for i, (m, n) in enumerate(HC): hm2[m][n] = hm2[n][m] = hv[i]
tr2 = sum(ETA[i] * hm2[i][i] for i in range(4)); p2 = q0**2 - q3**2
ph = [sum(pu[r] * hm2[r][n] for r in range(4)) for n in range(4)]; pph = sum(pu[n] * ph[n] for n in range(4))
El = [[p2*hm2[m][n] - p[m]*ph[n] - p[n]*ph[m] + p[m]*p[n]*tr2 + (ETA[m] if m == n else 0)*(pph - p2*tr2) for n in range(4)] for m in range(4)]
Eup = {i: (2 - (m == n)) * ETA[m] * ETA[n] * El[m][n] for i, (m, n) in enumerate(HC)}
out = {}
for s0 in (1, -1):
    Vh = {a: sp.expand(sum(V2ab(a, b, s0) * hv[b] for b in range(10))) for a in range(10)}
    ratios = set()
    for a in range(10):
        if sp.expand(Eup[a]) != 0:
            ratios.add(sp.simplify(Vh[a] / Eup[a]))
        elif Vh[a] != 0: ratios.add('mismatch')
    out[str(s0)] = [str(r) for r in ratios]
    print('momentum sign', s0, 'V2 h / Eup ratios:', ratios)
N = list(sp.sympify(out['1'][0]) for _ in [0])[0] if len(out['1']) == 1 else None
lam = sp.simplify(N / (I * F.A_GH)) if N is not None else None
print('N =', N, ' A_GH =', F.A_GH, ' lam_pred =', lam)
json.dump({'N': str(N), 'A_GH': str(F.A_GH), 'lam_pred': str(lam), 'ratios': out}, open('/workspace/XVI-O1-CONE/logs/v6/st_norm.json', 'w'), indent=1)
