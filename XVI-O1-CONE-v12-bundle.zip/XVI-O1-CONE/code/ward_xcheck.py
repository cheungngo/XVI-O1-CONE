"""(F) Second implementation of the spin-2 Ward residual: identical residual as ward_scan.py, but with the kernel
S_b(u,psi) evaluated by the explicit angular MODE SUM (with explicit E0 flips for CR labels b>1, b<0) instead of the
closed Bernoulli/exponential form.  usage: ward_xcheck.py <alpha> <geom|fried> <r>"""
import mpmath as mp, sys, json
mp.mp.dps = 20
sys.path.insert(0, '/workspace/XVI-O1-CONE/code')
import tensor
def S_modes(b, u, psi):
    f = lambda n: mp.exp(1j * (n + b) * psi - abs(n + b) * u)
    s = mp.nsum(f, [-mp.inf, mp.inf])
    if b > 1: s += mp.exp(1j * (b - 1) * psi) * (mp.exp((b - 1) * u) - mp.exp(-(b - 1) * u))
    if b < 0: s += mp.exp(1j * b * psi) * (mp.exp(-b * u) - mp.exp(b * u))
    return s
tensor.S = S_modes
from tensor import ten_kernel, vec_kernel, bgeom, bfried
al = mp.mpf(sys.argv[1]); mode = sys.argv[2]; rr = sys.argv[3]
br = {'geom': bgeom, 'fried': bfried}[mode]
xp = (mp.mpf("0.35"), mp.mpf("0.8"), mp.mpf("0.45"), mp.mpf("0.2"))
def dx(fun, i, pt): return mp.diff(lambda s: fun(tuple(pt[k] + (s if k == i else 0) for k in range(4))), 0)
half = mp.mpf(1) / 2
x = (mp.mpf("0.1"), mp.mpf(rr), mp.mpf("0.2"), mp.mpf("0.05"))
def hbar(y, mu, nu, rho, sg):
    W = ten_kernel(al, y, xp, br); val = W[((mu, nu), (rho, sg))]
    if mu == nu: val -= half * sum(W[((l, l), (rho, sg))] for l in range(4))
    return val
row = {'alpha': sys.argv[1], 'mode': mode, 'r': rr, 'impl': 'mode-sum'}
for (nu, rho, sg) in [(1, 1, 1), (2, 2, 2), (1, 1, 2)]:
    lhs = sum(dx(lambda y: hbar(y, mu, nu, rho, sg), mu, x) for mu in range(4))
    rhs = dx(lambda y: vec_kernel(al, x, y)[nu][sg], rho, xp) + dx(lambda y: vec_kernel(al, x, y)[nu][rho], sg, xp)
    row[str((nu, rho, sg))] = [mp.nstr(abs(lhs + rhs), 6), mp.nstr(abs(rhs), 6)]
    print(row, flush=True)
json.dump(row, open('/workspace/XVI-O1-CONE/logs/v2_wardx_%s_%s_%s.json' % (sys.argv[1], mode, rr), 'w'), indent=1)
