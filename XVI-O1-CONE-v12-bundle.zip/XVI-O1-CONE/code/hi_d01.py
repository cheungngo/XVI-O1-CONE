"""v6 item (c): exact obstruction to (H_I) for D01 on CR.  Composite trace of the S=2 -> 3 raising operator
X = (d_r - nu/r) acting on both arguments of the CR-minus-F radial heat-kernel difference in the flipped channel
(nu = 2 - 1/alpha), diagonal integrated with r dr.  Diagonal ~ c0 r^(-2nu-2): NOT integrable (any nu>0).
Mellin (homogeneous) extension R(z) = int r^(1+z) D(r) dr, continued to z=0 (unique iff 2nu not integer).
Scale invariance: R(0) = kappa_*/s.  Prints s*R(0) for several alpha."""
import mpmath as mp, json
mp.mp.dps = 60
def run(alpha, s=mp.mpf(1)):
    nu = 2 - 1/mp.mpf(alpha)
    def dK(r, rp):
        x = r*rp/(2*s)
        return mp.e**(-(r**2+rp**2)/(4*s))/(2*s) * (2*mp.sin(mp.pi*nu)/mp.pi) * mp.besselk(nu, x)
    A = mp.sin(mp.pi*nu)/(mp.pi*s)
    def K(m, x): return mp.besselk(m, x)
    def Kp(x): return -(K(nu-1, x) + K(nu+1, x))/2
    def Kpp(x): return (K(nu-2, x) + 2*K(nu, x) + K(nu+2, x))/4
    def D(r):
        # analytic: dK = A exp(-(r^2+r'^2)/4s) K_nu(r r'/2s); X = (d_r - nu/r), X' = (d_r' - nu/r'), at r'=r
        x = r*r/(2*s); E = mp.e**(-r*r/(2*s)); c = 1/(2*s)
        # derivatives of g(r,r') = exp(-(r^2+r'^2)/4s) K_nu(c r r')
        g = E*K(nu, x)
        gr = E*(-r/(2*s)*K(nu, x) + c*r*Kp(x))          # d/dr (same as d/dr' by symmetry at r=r')
        grr = E*((r/(2*s))**2*K(nu, x) - (r/(2*s))*c*r*Kp(x)*2 + c*Kp(x) + (c*r)**2*Kpp(x))  # d^2/dr dr'
        return A*(grr - 2*nu/r*gr + nu**2/r**2*g)
    c0 = (1/(2*s))*(4*s)**nu*4*nu**2/mp.gamma(1-nu)
    eps = mp.mpf('1e-9')
    c1 = (D(eps) - c0*eps**(-2*nu-2))*eps**(2*nu)          # next term c1 r^(-2nu)
    head = c1*eps**(2-2*nu)/(2-2*nu)                        # int_0^eps r * c1 r^(-2nu)
    inner = head + mp.quad(lambda r: r*(D(r) - c0*r**(-2*nu-2)), [eps, mp.mpf('1e-6'), mp.mpf('1e-3'), mp.mpf('0.25'), 1])
    inner_check = (D(eps*10) - c0*(eps*10)**(-2*nu-2))*(eps*10)**(2*nu)
    print('  c1 stability', mp.nstr(c1, 10), mp.nstr(inner_check, 10), flush=True)
    outer = mp.quad(lambda r: r*D(r), [1, 4, 12, mp.inf])
    R0 = inner + c0/(-2*nu) + outer
    return nu, s*R0
out = {}
for a in ['0.6', '0.7', '0.75', '0.8', '0.9']:
    nu, v = run(mp.mpf(a))
    out[a] = {'nu': mp.nstr(nu, 12), 's*R(0)': mp.nstr(v, 15)}
    print(a, out[a], flush=True)
nu, v2 = run(mp.mpf('0.8'), s=mp.mpf(3)); print('s-check alpha=0.8, s=3:', mp.nstr(v2, 15))
out['s_check_0.8_s3'] = mp.nstr(v2, 15)
json.dump(out, open('/workspace/XVI-O1-CONE/logs/v6/hi_d01.json', 'w'), indent=1)
