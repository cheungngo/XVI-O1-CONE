"""v4: linearised ST (sigma_0) hh-row test on the apex pole, constant-profile S=0 sector (lattice components
h_00,h_03,h_33, transverse trace f0 (h11=h22); ghost c^0,c^3; K_ab).  Row: 2 B_hh(K2 c(p), h(-p)) + lam * G_Kc(E h, c) = 0.
lam (and the K off-diagonal weight w) are convention constants: they must be alpha-INDEPENDENT and fit ALL samples.
B_hh = D01+D02+D03+D11+D12 (spectral, CR or F); G_Kc = D13 (spectral)."""
import json, sys, random, sympy as sp
br = sys.argv[1] if len(sys.argv) > 1 else 'CR'
q0, q3, al = sp.symbols('q0 q3 alpha'); ka = sp.Symbol('kappa')
HC = [(0,0),(0,1),(0,2),(0,3),(1,1),(1,2),(1,3),(2,2),(2,3),(3,3)]
ETA = [1,-1,-1,-1]
def load(g):
    return {eval(k): sp.sympify(v) for k, v in json.load(open(f'/workspace/XVI-O1-CONE/logs/v4/spec_{g}_{br}.json'))['Gamma_pole_coeff_of_1/(4-d)'].items()}
LAT = {0, 3, 9, 4, 7}
Bhh = {}
for g in ['D01', 'D02', 'D03', 'D11', 'D12']:
    for k, v in load(g).items():
        if k[0] in LAT and k[1] in LAT: Bhh[k] = Bhh.get(k, 0) + v
GKc = {k: v for k, v in load('D13').items() if k[0] in LAT and k[1] in (0, 3)}
def B(x, y):   # x at +p, y at -p ; dicts comp->value
    return sum(v * x.get(a, 0) * y.get(b, 0) for (a, b), v in Bhh.items())
def G(K, c):
    return sum(v * K.get(a, 0) * c.get(n, 0) for (a, n), v in GKc.items())
def full(hc):  # comp dict -> 4x4 symmetric lower-index matrix
    M = [[0]*4 for _ in range(4)]
    for i, (m, n) in enumerate(HC):
        if i in hc: M[m][n] = M[n][m] = hc[i]
    return M
def comps(M, w):
    return {0: M[0][0], 3: w * M[0][3], 9: M[3][3], 4: M[1][1], 7: M[2][2]}
def E(hc, p):   # linearised Einstein-type operator (overall factor -> lam), lower indices, mostly minus
    h = full(hc); pu = [ETA[i]*p[i] for i in range(4)]
    tr = sum(ETA[i]*h[i][i] for i in range(4)); p2 = sum(ETA[i]*p[i]**2 for i in range(4))
    ph = [sum(pu[r]*h[r][n] for r in range(4)) for n in range(4)]; pph = sum(pu[n]*ph[n] for n in range(4))
    return [[p2*h[m][n] - p[m]*ph[n] - p[n]*ph[m] + p[m]*p[n]*tr + (ETA[m] if m == n else 0)*(pph - p2*tr) for n in range(4)] for m in range(4)]
def K2(c, p):   # c^nu upper -> delta h_{mu nu} = p_mu c_nu + p_nu c_mu (factor -> lam)
    cl = [ETA[i]*c.get(i, 0) for i in range(4)]
    return [[p[m]*cl[n] + p[n]*cl[m] for n in range(4)] for m in range(4)]
random.seed(1)
lam = sp.Symbol('lam')
p = [q0, 0, 0, q3]; mp = [-x for x in p]
out = {}
for w in [1, 2, sp.Rational(1, 2)]:
    eqs = []
    for s in range(6):
        hc = {i: random.randint(-5, 5) for i in (0, 3, 9)}; f0 = random.randint(-5, 5); hc[4] = f0; hc[7] = f0
        c = {0: random.randint(-5, 5), 3: random.randint(-5, 5)}
        sub = {q0: random.randint(1, 9), q3: random.randint(1, 9)}
        dh = comps(K2(c, p), 1)
        Eh = comps(E(hc, mp), w)
        r = sp.expand((2 * B(dh, hc) + lam * G(Eh, c)).subs(sub))
        eqs.append(r)
    # solve lam from first nonzero-in-lam eq, test rest as polynomials in alpha
    sol = None
    for e in eqs:
        cl = sp.expand(e).coeff(lam)
        if sp.simplify(cl) != 0:
            sol = sp.simplify(-(e - cl*lam) / cl); break
    res = [sp.factor(sp.simplify(e.subs(lam, sol))) for e in eqs] if sol is not None else None
    out[str(w)] = {'lam': str(sp.factor(sol)) if sol is not None else None, 'residuals': [str(x) for x in res] if res else None,
                   'hh_only_residuals': [str(sp.factor(e.subs(lam, 0))) for e in eqs]}
    print(w, 'lam =', sp.factor(sol) if sol is not None else None, 'residuals:', res, flush=True)
json.dump({'branch': br, 'fits': out}, open(f'/workspace/XVI-O1-CONE/logs/v4/st_const_{br}.json', 'w'), indent=1)
