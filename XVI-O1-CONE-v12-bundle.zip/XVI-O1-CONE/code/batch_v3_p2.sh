#!/bin/bash
cd /workspace/XVI-O1-CONE
mkdir -p logs/v3/p2
for a in 1/3 1/2 2/3 7071/10000; do for b in CR F; do
 echo "== $a $b p2"; timeout 900 python3 code/apex_run.py $a $b 2 2>&1 | grep -v '^ ' | head -6
done; done
echo BATCH_DONE
