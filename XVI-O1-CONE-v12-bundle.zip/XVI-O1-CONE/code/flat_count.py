"""(A1) Flat-bulk sanity count inside the apex-engine machinery: same slot/pairing enumerator (apex_jets.pairings),
same modular rank routine, index range D=4 (no transverse jets; all directions 'longitudinal'), power counting of the
bulk kappa^2 d^4x two-point counterterm: [F1]+[F2]+k = 6.  Expected XVI-P p14r domain: h.h 5, c.cb 2, c.K 3, phi.phi 1."""
import sys, random, itertools, json
sys.path.insert(0, '/workspace/XVI-O1-CONE/code')
import apex_jets as AJ
from apex_jets import pairings, rank_and_basis
D = 4
FL = {'h': (2, 1, True), 'K': (2, 2, True), 'c': (1, 1, False), 'cb': (1, 1, False), 'phi': (0, 1, False)}  # rank, dim, symmetric
def cands(F1, F2, T=6):
    r1, d1, _ = FL[F1]; r2, d2, _ = FL[F2]; k = T - d1 - d2
    slots = [('A', i) for i in range(r1)] + [('B', i) for i in range(r2)] + [('p', i) for i in range(k)]
    if len(slots) % 2: return [], k
    seen = set(); out = []
    for pr in pairings(slots):
        key = tuple(sorted(tuple(sorted((x[0], x[1] if x[0] != 'p' else 0) for x in pair)) for pair in pr))
        if key in seen: continue
        seen.add(key); out.append(pr)
    return out, k
def rt(F):
    r, _, sym = FL[F]; P = AJ.P
    t = {idx: random.randrange(P) for idx in itertools.product(range(D), repeat=r)}
    if sym and r == 2:
        for a in range(D):
            for b in range(a): t[(a, b)] = t[(b, a)]
    return t
def ev(pr, F1, F2, t1, t2, q):
    r1 = FL[F1][0]; r2 = FL[F2][0]; P = AJ.P
    k = sum(1 for pair in pr for x in pair if x[0] == 'p')
    tot = 0
    for idx in itertools.product(range(D), repeat=r1 + r2 + k):
        lab = {('A', i): idx[i] for i in range(r1)}; lab.update({('B', i): idx[r1 + i] for i in range(r2)})
        lab.update({('p', i): idx[r1 + r2 + i] for i in range(k)})
        if any(lab[x] != lab[y] for x, y in pr): continue
        v = t1[tuple(idx[:r1])] * t2[tuple(idx[r1:r1 + r2])] % P
        for i in range(k): v = v * q[idx[r1 + r2 + i]] % P
        tot = (tot + v) % P
    return tot
res = {}
for pi, p in enumerate(AJ.PRIMES):
    AJ.setprime(p); random.seed(7 + pi); P = AJ.P
    for name, (F1, F2, bose) in {'h.h': ('h', 'h', True), 'c.cb': ('cb', 'c', False), 'c.K': ('K', 'c', False), 'phi.phi': ('phi', 'phi', True)}.items():
        cl, k = cands(F1, F2)
        smp = [(rt(F1), rt(F2), [random.randrange(P) for _ in range(D)]) for _ in range(len(cl) + 8)]
        rows = []
        for pr in cl:
            row = []
            for (a, b, q) in smp:
                v = ev(pr, F1, F2, a, b, q)
                if bose: v = (v + ev(pr, F1, F2, b, a, [(-x) % P for x in q])) % P
                row.append(v)
            rows.append(row)
        res.setdefault(name, []).append({'raw_patterns': len(cl), 'k': k, 'rank': rank_and_basis(rows)[0]})
print(json.dumps(res))
json.dump(res, open('/workspace/XVI-O1-CONE/logs/v2_flat_count.json', 'w'), indent=1)
