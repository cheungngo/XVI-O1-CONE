"""v3 item (1): one-point ('inner') apex degrees of bubble integrands.  At a cubic vertex x with two propagator legs
(other ends fixed away from W) and one external leg, the integrand near W is a sum of terms r^s e^{i(sum n)phi} with
s = m1 + m2 + m3 - k, k <= 2 transverse derivatives, m from the I-B-G-S v2 lattice:
  nu = |n t + sigma|, F jet m = nu + 2j;  CR flips (sigma,n) in {(2,-1),(-2,1)} to E0 (m = -nu + 2j) when t<2.
Angular integral forces n1+n2+n3 = 0.  Non-local-integrability: s <= -2.  We list, on a grid of alpha and on both
branches, the minimal s with sum n = 0 and whether some s <= -2 is an INTEGER (unregulated log; needs a new regulator)
or only non-integer (unique homogeneous extension, Hormander Thm 3.2.3).  Legs: graviton sigma in {0,+-1,+-2},
ghost/vector sigma in {0,+-1}, scalar sigma=0."""
import json, itertools
from fractions import Fraction as Fr
SIG = {'h': [0, 1, -1, 2, -2], 'c': [0, 1, -1], 'phi': [0]}
def jets(field, t, br, nmax=3, jmax=1):
    out = []
    for s in SIG[field]:
        for n in range(-nmax, nmax + 1):
            nu = abs(n * t + s)
            flip = (br == 'CR' and field == 'h' and (s, n) in ((2, -1), (-2, 1)) and t < 2)
            for j in range(jmax + 1):
                m = (-nu if flip else nu) + 2 * j
                if not flip and nu == 0 and j == 0: pass
                out.append((n, m, flip))
    return out
GRAPHS = {'D01': ('h', 'h', 'h'), 'D03': ('c', 'c', 'h'), 'D04a': ('h', 'phi', 'phi'), 'D04b': ('phi', 'h', 'phi'),
          'D11': ('phi', 'phi', 'h'), 'D13a': ('c', 'h', 'K'), 'D13b': ('c', 'h', 'c')}
def scan(alpha, br):
    t = 1 / alpha; res = {}
    for gname, (L1, L2, E) in GRAPHS.items():
        Ej = 'h' if E in ('h', 'K') else E
        J1 = jets(L1, t, br); J2 = jets(L2, t, br); J3 = jets(Ej, t, br)
        worst = None; integer_bad = []
        for (n1, m1, f1), (n2, m2, f2), (n3, m3, f3) in itertools.product(J1, J2, J3):
            if n1 + n2 + n3 != 0: continue
            for k in (0, 1, 2):
                s = m1 + m2 + m3 - k
                if worst is None or s < worst: worst = s
                if s <= -2 + 1e-12:
                    isint = abs(s - round(s)) < 1e-9
                    if isint and (n1, n2, n3) != (0, 0, 0): integer_bad.append((n1, n2, n3, round(s, 6), k, f1, f2, f3))
        res[gname] = {'min_s': round(worst, 6), 'integer_nonlocal': integer_bad[:6], 'n_integer_nonlocal': len(integer_bad)}
    return res
out = {}
grid = [Fr(k, 97) for k in range(1, 97)] + [Fr(1, 3), Fr(1, 2), Fr(2, 3), Fr(3, 4), Fr(4, 5), Fr(4, 7), Fr(3, 5), Fr(7071, 10000)]
for a in grid:
    for br in ('CR', 'F'):
        r = scan(float(a), br)
        bad = {g: v['n_integer_nonlocal'] for g, v in r.items() if v['n_integer_nonlocal']}
        out[f'{a}_{br}'] = {'bad': bad, 'min_s': {g: v['min_s'] for g, v in r.items()}, 'examples': {g: v['integer_nonlocal'] for g, v in r.items() if v['n_integer_nonlocal']}}
json.dump(out, open('/workspace/XVI-O1-CONE/logs/v3/inner_degrees.json', 'w'), indent=1)
crbad = sorted({k.split('_')[0] for k, v in out.items() if k.endswith('_CR') and v['bad']}, key=lambda s: float(Fr(s)))
fbad = sorted({k.split('_')[0] for k, v in out.items() if k.endswith('_F') and v['bad']}, key=lambda s: float(Fr(s)))
print('CR alphas with integer non-local inner degree:', crbad)
print('F  alphas with integer non-local inner degree (count):', len(fbad), fbad[:12], '...')
for a in ['7071/10000', '2/3', '1/2', '1/3']:
    print(a, 'CR', out[a + '_CR']['bad'], out[a + '_CR']['min_s']); print(a, 'F', out[a + '_F']['bad'])
