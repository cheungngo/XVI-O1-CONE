#!/usr/bin/env python3
"""v8 artifact appendix: SHA-256 of every v8 program/log used, frozen-tree digests (before/after),
environment; writes v8src/artifacts.tex, logs/v8/tree_hashes_v8.json, logs/v8/env.json,
logs/v8/artifact_manifest_v8.sha256."""
import hashlib, glob, os, subprocess, json, sys, platform
R = '/workspace/XVI-O1-CONE/'
def sha(p): return hashlib.sha256(open(p, 'rb').read()).hexdigest()
def tree(t):
    cmd = f"cd /workspace/XVI-{t} && find . -type f -not -path './.pytest_cache/*' -not -name '*.pyc' | sort | xargs sha256sum | sha256sum"
    return subprocess.run(cmd, shell=True, capture_output=True, text=True, env={**os.environ, 'LC_ALL': 'C.UTF-8'}).stdout.split()[0]
before = dict(l.split()[:2] for l in open(R + 'logs/frozen_v8_before.sha') if l.strip())
after = {t: tree(t) for t in 'PQR'}
py = {}
for t in 'PQR':
    m = json.load(open(R + f'logs/v8/manifest_XVI{t}.json')); py['XVI-' + t] = [m['tree_sha256'], len(m['files'])]
th = {'shell': {'XVI-' + t: after[t] for t in 'PQR'}, 'before': {'XVI-' + t: before['XVI' + t] for t in 'PQR'},
      'identical_before_after': {('XVI-' + t): before['XVI' + t] == after[t] for t in 'PQR'}, 'py': py, 'locale': 'C.UTF-8'}
json.dump(th, open(R + 'logs/v8/tree_hashes_v8.json', 'w'), indent=1)
import sympy
env = {'python': sys.version.split()[0], 'sympy': sympy.__version__, 'platform': platform.platform()}
try: env['pdftex'] = subprocess.run(['pdflatex', '--version'], capture_output=True, text=True).stdout.splitlines()[0]
except Exception as e: env['pdftex'] = 'unavailable'
json.dump(env, open(R + 'logs/v8/env.json', 'w'), indent=1)
G = lambda pat: sorted(glob.glob(pat, root_dir=R))
groups = [
 ('Base source (read-only)', ['XVI-O1-CONE-v7.tex']),
 ('v8 programs', G('code/v8/*.py') + G('code/v8/*.sh') + ['code/build_v8.py', 'code/artifacts_v8.py']),
 ('v8 source fragments', G('v8src/*.tex') + G('v8src/*.json')),
 ('v7-program runs', G('logs/v8/v7_*.json')),
 ('Replay', G('logs/v8/replay/*.json')),
 ('Ward scan', G('logs/v8/ward/*.json')),
 ('Exact certificates and maps', [f for f in G('logs/v8/cert/*.json')]),
 ('Exact sampled port', G('logs/v8/apex_exact/*.json')),
 ('Slice / evanescent / hidden pairs', G('logs/v8/slice/*.json')),
 ('Duhamel corroboration', G('logs/v8/duhamel_mode_check*.json')),
 ('Manifests, environment', G('logs/v8/manifest_*.json') + ['logs/v8/tree_hashes_v8.json', 'logs/v8/env.json']),
]
groups = [(t, [f for f in fs if not f.startswith('v8src/artifacts')]) for t, fs in groups]
rows, man = [], []
for title, files in groups:
    rows.append(r'\multicolumn{2}{@{}l}{\textit{%s} (%d files)}\\' % (title, len(files)))
    for f in files:
        h = sha(R + f); man.append(f'{h}  {f}')
        rows.append(r'{\scriptsize\loc{%s}} & \texttt{\tiny %s}\\' % (f, h))
open(R + 'logs/v8/artifact_manifest_v8.sha256', 'w').write('\n'.join(man) + '\n')
cmds = r'''cd /workspace/XVI-O1-CONE
python3 code/v8/cone_v7.py selftest
python3 code/v8/cone_v7.py logs logs/v4 --legacy
bash code/v8/run_replay.sh   # 27 runs
python3 code/v8/cone_v7.py logs logs/v8/replay
python3 code/v8/ward_scan_radial.py 0.85
python3 code/v8/apex_exact_run.py 7071/10000 CR
python3 code/v8/apex_certificate.py 3/10 CR      # also 3/10 F, 7071/10000 CR|F
python3 code/v8/k_support.py 3_10_CR             # per tag
python3 code/v8/hh_map.py 3/10 CR                # per (alpha, branch)
python3 code/v8/exact_values.py 3_10_CR 3_10_F 7071_10000_CR 7071_10000_F
bash code/v8/run_slice.sh && bash code/v8/run_slice2.sh
python3 code/v8/evanescent_combine.py
python3 code/v8/duhamel_mode_check2.py
python3 code/artifacts_v8.py && python3 code/build_v8.py
pdflatex -halt-on-error XVI-O1-CONE-v8.tex   # twice'''
app = r'''
%======================================================================
\section{v8 artifacts, hashes and rerun commands}
\label{app:v8artifacts}
%======================================================================

Paths are relative to \loc{/workspace/XVI-O1-CONE/} on the audit box.
Long jobs were run detached with \loc{setsid} and logged. The
environment is Python~''' + env['python'] + r''', SymPy~''' + env['sympy'] + r''', with \loc{LC_ALL=C.UTF-8}.
The frozen trees were hashed before the first v8 run and after the last
one; the before/after values are identical: ''' + ', '.join(f"XVI-{t}: {'yes' if th['identical_before_after']['XVI-'+t] else 'NO'}" for t in 'PQR') + r'''.
A full manifest is \loc{logs/v8/artifact_manifest_v8.sha256}; the
\TeX{} source and PDF are hashed in \loc{SHA256SUMS_v8}, outside this
document.

\paragraph{Rerun commands.}
\begin{verbatim}
''' + cmds + r'''
\end{verbatim}
The certificate runs take 5--10 minutes each and stay below 2~GB of
memory. The box limit is about 7~GB, so they were run at most three
at a time.

{\small
\begin{longtable}{@{}p{.50\linewidth}p{.46\linewidth}@{}}
\caption{SHA-256 of v8 artifacts.}\\
\toprule
File & SHA-256\\
\midrule
\endfirsthead
\toprule
File & SHA-256\\
\midrule
\endhead
\bottomrule
\endfoot
''' + '\n'.join(rows) + r'''
\end{longtable}}
'''
open(R + 'v8src/artifacts.tex', 'w').write(app)
print(th['identical_before_after'], len(man), env)
