"""(E) Trilinear (three-field) linearised BRST cohomology at the apex, ghost number 1, generic alpha, CR branch.
Minimal BV complex (non-minimal pair cbar,b contractible and dropped): s h = K2 c, s K = E h, s c* = K2^T K,
s phi* = box phi, s c = s phi = 0.  Sectors (phi-parity even, n=0 jets only: proved sufficient at non-resonant alpha):
gh0: HHH(h,h,h) PPH(phi,phi,h) KCH(K,c,h) SCC(c*,c,c) FPC(phi*,phi,c)  [T=5]
gh1: HHC(h,h,c) PPC(phi,phi,c) KCC(K,c,c)                               [T=6]
closure into gh2 HCC(h,c,c) [T=7]; commuting-placeholder conventions: identical bosons polarised with 1/n!,
identical ghosts antisymmetrised; relative signs fixed by sigma0^2=0 (checked).  usage: tri_run.py <alpha> <prime_index>"""
import sys, random, json, time, itertools
from fractions import Fraction as Fr
sys.path.insert(0, '/workspace/XVI-O1-CONE/code')
import apex_jets as AJ
from apex_jets import Setup, Ops, rand_cfg, reflect, rank_and_basis, nullspace, FIELDS, SCA
from tri_count import tri_cands
FIELDS['phis'] = (SCA, 2, 'scalar')
alpha = Fr(sys.argv[1]); pi = int(sys.argv[2]) if len(sys.argv) > 2 else 0
AJ.setprime(AJ.PRIMES[pi]); P = AJ.P; random.seed(4242 + pi)
S = Setup(alpha, 'CR'); T0 = time.time(); DM = 7
def rq(): return [random.randrange(1, 1000), random.randrange(1, 1000)]
def neg(q): return [(-x) % P for x in q]
def add(a, b): return [(x + y) % P for x, y in zip(a, b)]
def raw(c, cfgs, q1, q2):
    j1, j2, j3, r, k1, k2, pr = c
    vs = []
    for cfg, j in zip(cfgs, (j1, j2, j3)):
        v = cfg.get(j[0], {}).get((j[1], j[2]))
        if v is None: return 0
        vs.append(v)
    tot = 0
    for vals in itertools.product(range(2), repeat=len(pr)):
        lab = {}
        for (x, y), v in zip(pr, vals): lab[x] = v; lab[y] = v
        ia = 0
        for i in range(r[0]): ia = ia * 2 + lab[('A', i)]
        ib = 0
        for i in range(r[1]): ib = ib * 2 + lab[('B', i)]
        ic = 0
        for i in range(r[2]): ic = ic * 2 + lab[('C', i)]
        t = vs[0][ia] * vs[1][ib] % P * vs[2][ic] % P
        for i in range(k1): t = t * q1[lab[('p1', i)]] % P
        for i in range(k2): t = t * q2[lab[('p2', i)]] % P
        tot += t
    return tot % P
def ev(c, cfgs, q1, q2):   # reflection-symmetrised raw evaluation; legs momenta q1, q2, q3=-q1-q2
    return (raw(c, cfgs, q1, q2) + raw(c, [reflect(x) for x in cfgs], q1, q2)) % P
I2 = pow(2, P - 2, P); I6 = pow(6, P - 2, P)
def pol(sec, c, cfgs, qs):
    """polarised evaluation in the sector convention; cfgs/qs = 3 legs (q3 = -q1-q2 implied by qs[2])"""
    a, b, d = cfgs; qa, qb, qd = qs
    if sec in ('HHH',):
        tot = 0
        for p in itertools.permutations(range(3)):
            cc = [cfgs[i] for i in p]; qq = [qs[i] for i in p]
            tot += ev(c, cc, qq[0], qq[1])
        return tot % P * I6 % P
    if sec in ('PPH', 'HHC', 'PPC'):
        return (ev(c, [a, b, d], qa, qb) + ev(c, [b, a, d], qb, qa)) % P * I2 % P
    if sec in ('KCC', 'SCC'):
        return (ev(c, [a, b, d], qa, qb) - ev(c, [a, d, b], qa, qd)) % P
    return ev(c, [a, b, d], qa, qb)   # KCH, FPC
SECT = {'HHH': ('h', 'h', 'h', 5), 'PPH': ('phi', 'phi', 'h', 5), 'KCH': ('K', 'c', 'h', 5), 'SCC': ('cs', 'c', 'c', 5), 'FPC': ('phis', 'phi', 'c', 5),
        'HHC': ('h', 'h', 'c', 6), 'PPC': ('phi', 'phi', 'c', 6), 'KCC': ('K', 'c', 'c', 6)}
def sample(sec):
    F1, F2, F3, _ = SECT[sec]; q1 = rq(); q2 = rq(); q3 = neg(add(q1, q2))
    return [rand_cfg(S, F1, DM), rand_cfg(S, F2, DM), rand_cfg(S, F3, DM)], [q1, q2, q3]
basis = {}; res = {'alpha': str(alpha), 'prime': P}
for sec, (F1, F2, F3, T) in SECT.items():
    cl = tri_cands(S, F1, F2, F3, T)
    sm = [sample(sec) for _ in range(len(cl) + 12)]
    rows = [[pol(sec, c, cf, qs) for (cf, qs) in sm] for c in cl]
    rk, piv = rank_and_basis(rows); basis[sec] = [cl[i] for i in piv]
    res.setdefault('raw', {})[sec] = len(cl); res.setdefault('dims', {})[sec] = rk
    print(sec, len(cl), rk, round(time.time() - T0, 1), flush=True)
G1 = ['HHC', 'PPC', 'KCC']; G0 = ['HHH', 'PPH', 'KCH', 'SCC', 'FPC']
gorder = [(s, i) for s in G1 for i in range(len(basis[s]))]
# ---- closure rows on gh2 samples (h@qh, c1@q1, c2@q2)
cl_rows = []
for _ in range(len(gorder) + 15):
    qh = rq(); q1 = rq(); q2 = neg(add(qh, q1))
    h = rand_cfg(S, 'h', DM); c1 = rand_cfg(S, 'c', DM); c2 = rand_cfg(S, 'c', DM)
    K2c1 = Ops(S, q1).K2(c1); K2c2 = Ops(S, q2).K2(c2); Eh = Ops(S, qh).E(h)
    row = []
    for (s, i) in gorder:
        c = basis[s][i]
        if s == 'HHC':
            v = 2 * (pol('HHC', c, [K2c1, h, c2], [q1, qh, q2]) - pol('HHC', c, [K2c2, h, c1], [q2, qh, q1]))
        elif s == 'KCC':
            v = pol('KCC', c, [Eh, c1, c2], [qh, q1, q2])
        else: v = 0
        row.append(v % P)
    cl_rows.append(row)
Zg1 = nullspace(cl_rows, len(gorder)); res['gh1_closed_dim'] = len(Zg1)
print('closed', len(Zg1), 'of', len(gorder), round(time.time() - T0, 1), flush=True)
# ---- exact: images of gh0 basis on gh1 samples
gs = []
for _ in range(len(gorder) + 20):
    for s in G1: gs.append((s,) + tuple(sample(s)))
def image(s0, c, smp):
    s1, cfgs, qs = smp; a, b, d = cfgs; qa, qb, qd = qs
    if s0 == 'HHH' and s1 == 'HHC':
        return 3 * pol('HHH', c, [Ops(S, qd).K2(d), a, b], [qd, qa, qb]) % P
    if s0 == 'PPH' and s1 == 'PPC':
        return pol('PPH', c, [a, b, Ops(S, qd).K2(d)], [qa, qb, qd])
    if s0 == 'KCH' and s1 == 'HHC':
        return (ev(c, [Ops(S, qa).E(a), d, b], qa, qd) + ev(c, [Ops(S, qb).E(b), d, a], qb, qd)) % P * I2 % P
    if s0 == 'KCH' and s1 == 'KCC':
        return (ev(c, [a, b, Ops(S, qd).K2(d)], qa, qb) - ev(c, [a, d, Ops(S, qb).K2(b)], qa, qd)) % P
    if s0 == 'SCC' and s1 == 'KCC':
        return pol('SCC', c, [Ops(S, qa).K2T(a), b, d], [qa, qb, qd])
    if s0 == 'FPC' and s1 == 'PPC':
        bx = lambda f, q: {'S': Ops(S, q).box(f, {'S': 0})['S']}
        return (ev(c, [bx(a, qa), b, d], qa, qb) + ev(c, [bx(b, qb), a, d], qb, qa)) % P * I2 % P
    return 0
order0 = [(s, i) for s in G0 for i in range(len(basis[s]))]
Gimg = [[image(s, basis[s][i], smp) for smp in gs] for (s, i) in order0]
Gbas = [[(pol(s, basis[s][i], smp[1], smp[2]) if smp[0] == s else 0) for smp in gs] for (s, i) in gorder]
rG, _ = rank_and_basis(Gimg); rGb, _ = rank_and_basis(Gbas); rGB, _ = rank_and_basis(Gbas + Gimg)
res['gh1_exact_dim'] = rG; res['images_in_span'] = (rGB == rGb); res['gh1_basis_rank_on_samples'] = rGb
closed = None
if rGB == rGb:
    closed = True
    for vec in Gimg:
        aug = [[Gbas[r][k] for r in range(len(gorder))] + [(-vec[k]) % P] for k in range(len(gs))]
        ns = nullspace(aug, len(gorder) + 1); sol = next((v for v in ns if v[-1]), None)
        if sol is None: closed = False; break
        inv = pow(sol[-1], P - 2, P); y = [x * inv % P for x in sol[:-1]]
        if any(sum(rw[k] * y[k] for k in range(len(gorder))) % P for rw in cl_rows): closed = False; break
res['images_closed_sigma0sq'] = closed
res['H1_trilinear'] = len(Zg1) - rG if closed else None
# sector-resolved: H1 in the PPC block alone and HHC+KCC block
print(json.dumps(res), round(time.time() - T0, 1), flush=True)
json.dump(res, open('/workspace/XVI-O1-CONE/logs/v2_tri_%s_p%d.json' % (str(alpha).replace('/', '_'), pi), 'w'), indent=1)
