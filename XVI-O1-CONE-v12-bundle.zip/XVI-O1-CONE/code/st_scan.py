"""v4: convention scan for the hh ST row. Control branch UNIT (all C_S=1: k_perp=0 reduction of the flat integrand,
pointwise Ward identities => must close). Pick conventions that close UNIT, then apply unchanged to CR and F."""
import json, sys, random, itertools, sympy as sp
sys.argv = [sys.argv[0], 'UNIT']
exec(open('/workspace/XVI-O1-CONE/code/st_test_const.py').read().split('random.seed(1)')[0])
p = [q0, 0, 0, q3]; lam = sp.Symbol("lam")
def run(brn, w, sE, cup, tw, sdh, lamfix=None):
    global Bhh, GKc
    Bhh = {}
    for g in ['D01','D02','D03','D11','D12']:
        for k, v in {eval(k): sp.sympify(v) for k, v in json.load(open(f'logs/v4/spec_{g}_{brn}.json'))['Gamma_pole_coeff_of_1/(4-d)'].items()}.items():
            if k[0] in LAT and k[1] in LAT: Bhh[k] = Bhh.get(k, 0) + v
    GKc = {eval(k): sp.sympify(v) for k, v in json.load(open(f'logs/v4/spec_D13_{brn}.json'))['Gamma_pole_coeff_of_1/(4-d)'].items() if eval(k)[0] in LAT and eval(k)[1] in (0,3)}
    random.seed(7); eqs = []
    for s in range(8):
        hc = {i: random.randint(-5,5) for i in (0,3,9)}; f0 = random.randint(-5,5); hc[4]=f0; hc[7]=f0
        c = {0: random.randint(-5,5), 3: random.randint(-5,5)}
        cc = c if cup else {0: c[0], 3: -c[3]}
        sub = {q0: random.randint(1,9), q3: random.randint(1,9)}
        pp = [sdh*x for x in p]
        dh = comps(K2(cc, pp), 1)
        Ep = [sE*x for x in p]
        Em = E(hc, Ep); Eh = comps(Em, w); Eh[4] *= tw; Eh[7] *= tw
        eqs.append(sp.expand((2*B(dh, hc) + lam*G(Eh, c)).subs(sub)))
    if lamfix is not None:
        return lamfix, [sp.factor(e.subs(lam, lamfix)) for e in eqs]
    sol = None
    for e in eqs:
        cl = e.coeff(lam)
        if sp.simplify(cl) != 0: sol = sp.factor(-(e - cl*lam)/cl); break
    if sol is None: return None, [sp.factor(e) for e in eqs]
    return sol, [sp.factor(e.subs(lam, sol)) for e in eqs]
good = []
for w, sE, cup, tw, sdh in itertools.product([1,2,sp.Rational(1,2)], [1,-1], [True, False], [1,2,sp.Rational(1,2)], [1,-1]):
    sol, res = run('UNIT', w, sE, cup, tw, sdh)
    ok = all(r == 0 for r in res)
    if ok: good.append((w, sE, cup, tw, sdh, sol)); print('UNIT closes:', w, sE, cup, tw, sdh, 'lam=', sol, flush=True)
if not good: print('UNIT: no convention closes; sample', sol, res[:3])
out = {'UNIT_closing_conventions': [[str(x) for x in g] for g in good]}
for brn in ['CR', 'F']:
    out[brn] = []
    for (w, sE, cup, tw, sdh, sol) in good:
        lf, res = run(brn, w, sE, cup, tw, sdh)
        l2, res2 = run(brn, w, sE, cup, tw, sdh, lamfix=sol)
        out[brn].append({'conv': [str(w), sE, cup, str(tw), sdh], 'lam_fit': str(lf), 'res_fit': [str(r) for r in res], 'res_with_UNIT_lam': [str(r) for r in res2]})
        print(brn, (w, sE, cup, tw, sdh), 'lam_fit', lf, '| res(fit)', res[:4], '| res(UNIT lam)', res2[:4], flush=True)
json.dump(out, open('logs/v4/st_scan.json', 'w'), indent=1)
