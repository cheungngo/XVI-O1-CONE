import sys, random
from fractions import Fraction as Fr
sys.path.insert(0,'.')
import apex_jets as AJ
from apex_jets import *
S=Setup(Fr(7071,10000),'CR'); random.seed(7); P=AJ.P
def rq(): return [random.randrange(1, 1000), random.randrange(1, 1000)]
bc=candidates(S,'b','c',5); cb=candidates(S,'cb','c',4); kc=candidates(S,'K','c',4)
sm=[(rand_cfg(S,'b',6),rand_cfg(S,'c',6),rq()) for _ in range(60)]
Gb=[[eval_sym(c,a,b,q,False) for (a,b,q) in sm] for c in bc]
r0,_=rank_and_basis(Gb); print('bc rank',r0,len(bc))
for nm,cl,op in [('CB',cb,None),('CK',kc,'C2T')]:
    bad=0
    for c in cl:
        img=[eval_sym(c,(a if op is None else Ops(S,negq(q)).C2T(a)),b,q,False) for (a,b,q) in sm]
        r1,_=rank_and_basis(Gb+[img])
        if r1>r0:
            bad+=1
            if bad<3: print(nm,'not in span',c[0],c[1],c[4])
    print(nm,'bad',bad,len(cl))
