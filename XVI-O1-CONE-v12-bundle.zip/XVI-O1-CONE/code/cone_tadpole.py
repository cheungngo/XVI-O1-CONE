"""(C,D) Apex poles of the one-loop TADPOLE graphs on the cone, from the frozen XVI-P vertex tensors (read-only copy
in /tmp/o1cone_ro/XVI-P, imported, never modified) and the exact Synge data of the subtracted cone kernels (coinc.py).
Graph value convention (XVI-P/XVI-Q): i Gamma_1 = prefactor * int d^dl/(2pi)^d N/(l^2+i0);  position space:
int d^dl/(2pi)^d e^{il(x-x')}/(l^2+i0) = -i G_E(x,x')|_continued, leg momentum k_leg -> -i d at that leg's point.
Cone: <h_c(x) h_d(x')> numerator Pi_cd -> sum_S (Pi_S)_cd R_{b(S)}(x,x'), Pi_S = helicity-S projected de Donder tensor;
flat part scaleless (=0 in DR).  Apex pole: integrand ~ r^{-2} (theta-independent) => Gamma_pole = (1/(4-d)) int_W 2 pi alpha r^2 f."""
import sys, pickle, json, itertools
from fractions import Fraction as Fr
import sympy as sp
sys.path.insert(0, '/tmp/o1cone_ro/XVI-P/code/p5_entry')
import amplitude_rules as AR
F = AR.F
D = pickle.load(open('/workspace/XVI-O1-CONE/logs/v2_coinc_L.pkl', 'rb'))
t, X, Y, z = D['coords']; bS, alS = sp.symbols('b alpha', positive=True)
CO = (t, X, Y, z)
AS = sp.Symbol('alpha', positive=True)
HC = list(F.HC)
ETA = (1, -1, -1, -1)
sq = 1 / sp.sqrt(2)
U = {'t': ((1, 0, 0, 0), 0), 'p': ((0, sq, sp.I * sq, 0), 1), 'm': ((0, sq, -sp.I * sq, 0), -1), 'z': ((0, 0, 0, 1), 0)}
def Nfull(m, n, r, s):
    e = lambda a, b: ETA[a] if a == b else 0
    return sp.Rational(1, 2) * (e(m, r) * e(n, s) + e(m, s) * e(n, r)) - sp.Rational(1, 2) * e(m, n) * e(r, s)
def label(S, branch):
    if branch == 'CR': return S * AS if S >= 0 else 1 + S * AS
    if branch == 'F':   # Friedrichs labels for 1/2 < alpha < 1
        return {0: 0, 1: AS, 2: 2 * AS - 1, -1: 1 - AS, -2: 2 - 2 * AS}[S]
    raise ValueError
# ---- Synge coincidence derivatives (symbolic in X, Y, b, alpha)
A = D['A']; B = D['B']; C = D['C']
def coinc(nx, nxp):
    """nx, nxp: tuples of coordinate indices of derivatives on x and on x' (total <= 2)"""
    d = lambda e, i: sp.diff(e, CO[i])
    if len(nx) + len(nxp) > 2: raise ValueError
    if not nx and not nxp: return A
    if not nx and len(nxp) == 1: return B[nxp[0]]
    if len(nx) == 1 and not nxp: return d(A, nx[0]) - B[nx[0]]
    if not nx and len(nxp) == 2: return 2 * C[nxp[0]][nxp[1]]
    if len(nx) == 1 and len(nxp) == 1: return d(B[nxp[0]], nx[0]) - 2 * C[nx[0]][nxp[0]]
    i, j = nx
    return d(d(A, i), j) - d(B[j], i) - d(B[i], j) + 2 * C[i][j]
_cc = {}
def coinc_b(nx, nxp, bval):
    key = (nx, nxp)
    if key not in _cc: _cc[key] = sp.expand(coinc(nx, nxp))
    return _cc[key].subs(bS, bval)
# ---- projected propagator numerators
def tensor_sectors():
    out = {}
    for (Aa, (ua, sa)), (Bb, (ub, sb)) in itertools.product(U.items(), repeat=2):
        S = sa + sb
        for ci, (m, n) in enumerate(HC):
            for di, (r, s) in enumerate(HC):
                v = 0
                for m2 in range(4):
                    for n2 in range(4):
                        c2 = sp.conjugate(ua[m2] * ub[n2])
                        if c2 == 0: continue
                        v += ua[m] * ub[n] * c2 * Nfull(m2, n2, r, s)
                v = sp.nsimplify(sp.expand(v))
                if v != 0: out.setdefault(S, {}).setdefault((ci, di), 0); out[S][(ci, di)] += v
    for S in out: out[S] = {k: sp.simplify(v) for k, v in out[S].items() if sp.simplify(v) != 0}
    return out
def vector_sectors(G):
    out = {}
    for Aa, (ua, sa) in U.items():
        for mu in range(4):
            for rho in range(4):
                v = sum(ua[mu] * sp.conjugate(ua[n2]) * G.get((n2, rho), 0) for n2 in range(4))
                v = sp.nsimplify(sp.expand(v))
                if v != 0: out.setdefault(sa, {}).setdefault((mu, rho), 0); out[sa][(mu, rho)] += v
    return out
def mono_derivs(mono, legmap):
    """mono: tuple of var ids (4*leg + r) -> dict leg -> tuple of coordinate indices"""
    out = {}
    for v in mono:
        leg, r = divmod(v, 4); out.setdefault(legmap[leg], []).append(r)
    return {k: tuple(sorted(v)) for k, v in out.items()}
def ext_deriv(hexpr, idx):
    e = hexpr
    for i in idx: e = sp.diff(e, CO[i])
    return e
r2 = X ** 2 + Y ** 2
TESTS = {'T1_htt_r2': {0: r2}, 'T2_hzz_r2': {9: r2}, 'T3_PM_delta_r2': {4: r2, 7: r2},
         'T4_PP_xixj': {4: X ** 2 - r2 / 2, 7: Y ** 2 - r2 / 2, 5: X * Y}}
def onepoint(graph, branch='CR'):
    rules = AR.base_rules(); ints = AR.build_integrands(rules); pref = ints[graph]['prefactor']
    V = F.vertices(); Pi = AR.pinv_sparse(); Gh = AR.ghost_num()
    terms = []   # (ext comp a, loop sector label b, numerator weight, derivative dict)
    if graph == 'D14a':
        vt = V['V3_grav']; TS = tensor_sectors()
        chk = {k: 0 for k in Pi}
        for S, dct in TS.items():
            for k, v in dct.items(): chk[k] = chk.get(k, 0) + v
        assert all(sp.simplify(chk.get(k, 0) - Pi.get(k, 0)) == 0 for k in set(chk) | set(Pi)), 'projector sum != Pi'
        legmap = {0: 'ext', 1: 'x', 2: 'xp'}
        for (a, c, d), poly in vt.T.items():
            for S, dct in TS.items():
                wgt = dct.get((c, d))
                if wgt is None: continue
                for mono, cf in poly.d.items(): terms.append((a, label(S, branch), wgt * sp.Rational(cf.numerator, cf.denominator), mono_derivs(mono, legmap)))
    elif graph == 'D14b':
        vt = V['V_cb_c_h']; VS = vector_sectors(Gh)   # legs (cb_rho, c^mu, h_a); c at x (first arg), cb at x' (second)
        legmap = {0: 'xp', 1: 'x', 2: 'ext'}
        for (rho, mu, a), poly in vt.T.items():
            for s, dct in VS.items():
                wgt = dct.get((mu, rho))
                if wgt is None: continue
                for mono, cf in poly.d.items(): terms.append((a, label(s, branch), wgt * sp.Rational(cf.numerator, cf.denominator), mono_derivs(mono, legmap)))
    elif graph == 'D14c':
        vt = V['V_h_phi_phi']; legmap = {0: 'ext', 1: 'x', 2: 'xp'}
        num = F.propagators()['scalar']['numerator']
        for (a, _, _), poly in vt.T.items():
            for mono, cf in poly.d.items(): terms.append((a, 0, num * sp.Rational(cf.numerator, cf.denominator), mono_derivs(mono, legmap)))
    # flat (p=0) reproduction of the exported integrand: sum over sectors at b=0 must equal ints N (legs -> l, -l)
    res = {'graph': graph, 'prefactor': str(pref), 'n_terms': len(terms)}
    for tn, hd in TESTS.items():
        f = 0
        for (a, bval, wgt, dv) in terms:
            if a not in hd: continue
            e = ext_deriv(hd[a], dv.get('ext', ()))
            if e == 0: continue
            nder = len(dv.get('ext', ())) + len(dv.get('x', ())) + len(dv.get('xp', ()))
            f += wgt * (-sp.I) ** nder * e * coinc_b(dv.get('x', ()), dv.get('xp', ()), bval)
        f = sp.expand(-pref * (-sp.I) * f / sp.I)   # Gamma = (1/i) * pref * (-i) * [..] ; kappa kept symbolic in pref
        v0 = sp.simplify((r2 * f).subs({X: 1, Y: 0})); v1 = sp.simplify((r2 * f).subs({X: sp.Rational(3, 5), Y: sp.Rational(4, 5)}))
        res[tn] = {'r2f_theta0': str(v0), 'theta_independent': sp.simplify(v0 - v1) == 0,
                   'pole_coeff_per_unit_area': str(sp.simplify(2 * sp.pi * AS * v0))}
        print(graph, tn, res[tn], flush=True)
    return res
if __name__ == '__main__':
    g = sys.argv[1]; br = sys.argv[2] if len(sys.argv) > 2 else 'CR'
    out = onepoint(g, br)
    json.dump(out, open('/workspace/XVI-O1-CONE/logs/v2_tadpole_%s%s.json' % (g, '' if br == 'CR' else '_' + br), 'w'), indent=1)
