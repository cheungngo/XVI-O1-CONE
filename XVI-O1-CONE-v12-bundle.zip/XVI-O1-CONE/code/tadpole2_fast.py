"""v3 item (3): apex poles of the two-point TADPOLE graphs D02 (V4_grav, graviton loop), D12 (V_hh_phi_phi, scalar
loop) and D05a (V_hh_phi_phi, graviton loop, external phi phi) on the cone, CR branch (or F), same coincidence route as
D14 (cone_tadpole.py), with the corrected overall sign Gamma = -prefactor*[...] (varsigma=-1, XVI-P rule).
External fields: general rotation-equivariant, reflection-even n=0 jets up to m=2 (symbolic coefficients),
times exp(+-i(p0 t + p3 z)).  Output: the apex pole bilinear (coefficient of 1/(4-d), per unit area of W).
usage: tadpole2.py <D02|D12|D05a> [CR|F]"""
import sys, json, itertools, time
sys.path.insert(0, '/workspace/XVI-O1-CONE/code')
import sympy as sp
import cone_tadpole as CT
AR = CT.AR; F = CT.F; X, Y = CT.X, CT.Y; AS = CT.AS; HC = CT.HC
g = sys.argv[1]; br = sys.argv[2] if len(sys.argv) > 2 else 'CR'
T0 = time.time()
kap = F.KAPPA
p0, p3, lam = sp.symbols('p0 p3 lam')
def hfield(tag):
    c = sp.symbols(' '.join(f'{n}{tag}' for n in ['a0', 'a1', 'b0', 'b1', 'c0', 'c1', 'd', 'e', 'f0', 'f1', 'g']))
    a0, a1, b0, b1, c0, c1, d, e, f0, f1, gg = c; r2 = X**2 + Y**2; xs = (None, X, Y)
    H = {}
    for ci, (m, n) in enumerate(HC):
        if (m, n) == (0, 0): v = a0 + a1 * r2
        elif (m, n) == (0, 3): v = b0 + b1 * r2
        elif (m, n) == (3, 3): v = c0 + c1 * r2
        elif m == 0 and n in (1, 2): v = d * xs[n]
        elif m in (1, 2) and n == 3: v = e * xs[m]
        elif m in (1, 2) and n in (1, 2): v = (f0 + f1 * r2 if m == n else 0) + gg * (xs[m] * xs[n] - (r2 / 2 if m == n else 0))
        else: raise ValueError
        H[ci] = v
    return H, c
def sfield(tag):
    s0, s1 = sp.symbols(f's0{tag} s1{tag}'); return {0: s0 + s1 * (X**2 + Y**2)}, (s0, s1)
CO = (sp.Symbol('t'), X, Y, sp.Symbol('z'))
def extd(expr, idx, sgn):
    e = expr
    for i in idx:
        if i == 0: e = sp.I * sgn * p0 * e
        elif i == 3: e = sp.I * sgn * p3 * e
        else: e = sp.diff(e, CO[i])
    return e
rules = AR.base_rules(); ints = AR.build_integrands(rules); V = F.vertices()
if g == 'D02':
    vt = V['V4_grav']; pref = ints['D02']['prefactor']; loop = 'grav'; legs_ext = (0, 1); legmap = {0: 'e1', 1: 'e2', 2: 'x', 3: 'xp'}; ext = 'h'
elif g == 'D12':
    vt = V['V_hh_phi_phi']; pref = ints['D12']['prefactor']; loop = 'scal'; legmap = {0: 'e1', 1: 'e2', 2: 'x', 3: 'xp'}; ext = 'h'
elif g == 'D05a':   # not in XVI-P amplitude_rules: prefactor by analogy with D02/D12: S_f*loop_sign*(i k^2)*phase*i
    vt = V['V_hh_phi_phi']; pref = sp.nsimplify(sp.Rational(1, 2) * (sp.I * kap**2) * (sp.I ** vt.phase) * sp.I)
    loop = 'grav'; legmap = {0: 'x', 1: 'xp', 2: 'e1', 3: 'e2'}; ext = 'phi'
if ext == 'h': E1, c1 = hfield('_1'); E2, c2 = hfield('_2')
else: E1, c1 = sfield('_1'); E2, c2 = sfield('_2')
TS = CT.tensor_sectors() if loop == 'grav' else None
PTS = [(sp.Integer(1), sp.Integer(0)), (sp.Rational(3, 5), sp.Rational(4, 5))]
cache = {}
def lpoly(expr):
    """Laurent dict {power of lam: coeff} for expr = num/den with monomial den in lam"""
    expr = sp.cancel(sp.together(expr)); num, den = sp.fraction(expr)
    dp = sp.Poly(sp.expand(den), lam); assert len(dp.terms()) == 1, 'nonmonomial denominator'
    (dd,), dc = dp.terms()[0]
    out = {}
    for (k,), cf in sp.Poly(sp.expand(num), lam).terms(): out[k - dd] = out.get(k - dd, 0) + cf / dc
    return out
def coinc_at(nx, nxp, bval, pt):
    key = (nx, nxp, bval, pt)
    if key not in cache:
        v = CT.coinc_b(nx, nxp, bval)
        cache[key] = lpoly(v.subs({X: lam * pt[0], Y: lam * pt[1]}))
    return cache[key]
acc = [0, 0]; nterm = 0
for key, poly in vt.T.items():
    if g in ('D02', 'D12'):
        a, b = key[0], key[1]
        if g == 'D02':
            c, d = key[2], key[3]; secs = [(S, w.get((c, d))) for S, w in TS.items() if w.get((c, d)) is not None]
        else: secs = [(0, sp.Integer(1))]
    else:
        c, d = key[0], key[1]; a, b = 0, 0
        secs = [(S, w.get((c, d))) for S, w in TS.items() if w.get((c, d)) is not None]
    if a not in E1 or b not in E2 or not secs: continue
    for mono, cf in poly.d.items():
        dv = CT.mono_derivs(mono, legmap)
        e1 = extd(E1[a], dv.get('e1', ()), +1); e2 = extd(E2[b], dv.get('e2', ()), -1)
        if e1 == 0 or e2 == 0: continue
        nder = sum(len(dv.get(k, ())) for k in ('e1', 'e2', 'x', 'xp'))
        base = sp.Rational(cf.numerator, cf.denominator) * (-sp.I) ** nder * e1 * e2
        for ip, pt in enumerate(PTS):
            bp = sp.Poly(sp.expand(base.subs({X: lam * pt[0], Y: lam * pt[1]})), lam)
            bd = {k: c_ for (k,), c_ in bp.terms()}
            for S, w in secs:
                bval = CT.label(S, br) if loop == 'grav' else 0
                cd = coinc_at(dv.get('x', ()), dv.get('xp', ()), bval, pt)
                # need total lam power -2 (so that lam^2 * (...) is lam^0)
                tot = 0
                for k, c_ in bd.items():
                    if (-2 - k) in cd: tot += c_ * cd[-2 - k]
                if tot != 0: acc[ip] += w * tot
        nterm += 1
    if nterm % 2000 == 0: print('terms', nterm, round(time.time() - T0), flush=True)
print('collected', nterm, round(time.time() - T0), flush=True)
out = {'graph': g, 'branch': br, 'prefactor': str(pref), 'sign_rule': 'Gamma=-prefactor*[..]', 'n_terms': nterm}
res = []
for ip in range(2):
    c0 = sp.expand(-pref * acc[ip] * (PTS[ip][0]**2 + PTS[ip][1]**2))
    res.append(sp.expand(2 * sp.pi * AS * c0))
out['theta_independent'] = sp.simplify(res[0] - res[1]) == 0
P = sp.Poly(sp.expand(res[0]), *(list(c1) + list(c2) + [p0, p3]))
out['pole_bilinear'] = {str(m): str(sp.factor(cf)) for m, cf in zip(P.monoms(), P.coeffs())}
out['vars'] = [str(v) for v in list(c1) + list(c2) + [p0, p3]]
print(json.dumps(out)[:3000], flush=True)
json.dump(out, open('/workspace/XVI-O1-CONE/logs/v3/tad2fast_%s_%s.json' % (g, br), 'w'), indent=1)
print('done', round(time.time() - T0), flush=True)
