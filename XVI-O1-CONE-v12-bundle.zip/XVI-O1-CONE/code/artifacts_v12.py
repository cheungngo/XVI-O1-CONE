#!/usr/bin/env python3
"""v12 artifact appendix: SHA-256 of v11 programs/logs, frozen-tree digests before/after, v1-v11 digests before/after.
Fix of the v10 staleness: CHECKPOINT_v11.md receives its last append BEFORE this script runs (no append afterwards), and the
current CHECKPOINT_v10.md hash is recorded next to the stale value in the v10 manifest."""
import hashlib, glob, os, subprocess, json, sys, platform
R = '/workspace/XVI-O1-CONE/'
def sha(p): return hashlib.sha256(open(p, 'rb').read()).hexdigest()
def tree(t):
    cmd = f"cd /workspace/XVI-{t} && find . -type f -not -path './.pytest_cache/*' -not -name '*.pyc' | sort | xargs sha256sum | sha256sum"
    return subprocess.run(cmd, shell=True, capture_output=True, text=True, env={**os.environ, 'LC_ALL': 'C.UTF-8'}).stdout.split()[0]
os.makedirs(R + 'logs/v12', exist_ok=True)
before = dict(l.split()[:2] for l in open(R + 'logs/frozen_v12_before.sha') if l.strip())
after = {t: tree(t) for t in 'PQR'}
th = {'before': {'XVI-' + t: before['XVI' + t] for t in 'PQR'}, 'after': {'XVI-' + t: after[t] for t in 'PQR'},
      'identical_before_after': {('XVI-' + t): before['XVI' + t] == after[t] for t in 'PQR'}}
json.dump(th, open(R + 'logs/v12/tree_hashes_v12.json', 'w'), indent=1)
v10b = dict((l.split()[1], l.split()[0]) for l in open(R + 'logs/v11_hashes_before_v12.sha') if l.strip())
v10same = all(sha(R + f) == h for f, h in v10b.items())
earlier = {f: sha(R + f) for f in sorted(glob.glob('XVI-O1-CONE-v[1-9].tex', root_dir=R) + glob.glob('XVI-O1-CONE-v[1-9].pdf', root_dir=R))}
prev = json.load(open(R + 'logs/v11/earlier_versions_sha.json'))
v18same = all(earlier.get(f) == h for f, h in prev.items() if f in earlier) and len([f for f in prev if f in earlier]) >= 10
earlier.update({f: sha(R + f) for f in ('XVI-O1-CONE-v10.tex', 'XVI-O1-CONE-v10.pdf', 'XVI-O1-CONE-v11.tex', 'XVI-O1-CONE-v11.pdf')})
json.dump(earlier, open(R + 'logs/v12/earlier_versions_sha.json', 'w'), indent=1)
import sympy, mpmath
env = {'python': sys.version.split()[0], 'sympy': sympy.__version__, 'mpmath': mpmath.__version__, 'platform': platform.platform()}
json.dump(env, open(R + 'logs/v12/env.json', 'w'), indent=1)
G = lambda pat: sorted(glob.glob(pat, root_dir=R))
groups = [
 ('Base source (read-only)', ['XVI-O1-CONE-v11.tex']),
 ('v12 programs', G('code/v12/*.py') + G('code/v12/*.sh') + ['code/build_v12.py', 'code/artifacts_v12.py']),
 ('v12 source fragments', [f for f in G('v12src/*.tex') if 'artifacts' not in f]),
 ('Closed form and M10', ['logs/v12/F_closed.json', 'logs/v12/structure_test.json', 'logs/v12/m10_exact_dps40.json', 'logs/v12/counterterm.json', 'logs/v12/m10_pslq.json']),
 ('Wall certificates', [f for f in G('logs/v12/walls/*.json')] + G('logs/v12/walls/*.log')),
 ('Registry', ['logs/v12/registry_oct19b.sha']),
 ('Integrity, environment', ['logs/frozen_v12_before.sha', 'logs/v12/tree_hashes_v12.json', 'logs/v11_hashes_before_v12.sha',
                             'logs/v12/earlier_versions_sha.json', 'logs/v12/env.json', 'CHECKPOINT_v12.md']),
]
rows, man = [], []
for title, files in groups:
    files = [f for f in files if os.path.exists(R + f)]
    rows.append(r'\multicolumn{2}{@{}l}{\textit{%s} (%d files)}\\' % (title, len(files)))
    for f in files:
        h = sha(R + f); man.append(f'{h}  {f}')
        rows.append(r'{\scriptsize\loc{%s}} & \texttt{\tiny %s}\\' % (f, h))
open(R + 'logs/v12/artifact_manifest_v12.sha256', 'w').write('\n'.join(man) + '\n')
cmds = r'''cd /workspace/XVI-O1-CONE
python3 code/v12/phi_asym_fit.py; python3 code/v12/structure_test.py
python3 code/v12/F_closed.py
python3 code/v12/m10_exact.py 40; python3 code/v12/counterterm.py
python3 code/v12/m10_pslq.py
setsid nohup bash code/v12/walls_driver.sh > /dev/null 2>&1 &
python3 code/v12/make_tables.py
python3 code/artifacts_v12.py && python3 code/build_v12.py
pdflatex -halt-on-error XVI-O1-CONE-v12.tex   # until stable'''
yn = lambda b: 'yes' if b else 'NO'
app = r'''
%======================================================================
\section{v12 artifacts, hashes and rerun commands}
\label{app:v12artifacts}
%======================================================================

Paths are relative to \loc{/workspace/XVI-O1-CONE/}. Long jobs ran
detached with \loc{setsid} and were logged. Environment: Python~''' + env['python'] + r''', SymPy~''' + env['sympy'] + r''', mpmath~''' + env['mpmath'] + r'''.
Frozen trees before \(=\) after: ''' + ', '.join(f"XVI-{t}: {yn(th['identical_before_after']['XVI-'+t])}" for t in 'PQR') + r'''.
Digests: ''' + ', '.join(f"XVI-{t} \\texttt{{{after[t][:16]}\\ldots}}" for t in 'PQR') + r'''.
The v9, v10 and v11 sources and PDFs are unchanged: ''' + yn(v10same) + r'''. The v1--v8 sources are unchanged: ''' + yn(v18same) + r'''.
The full manifest is \loc{logs/v12/artifact_manifest_v12.sha256}; the \TeX{} source and PDF are hashed in \loc{SHA256SUMS_v12}.
The last append to \loc{CHECKPOINT_v12.md} precedes this hashing.

\paragraph{Rerun commands.}
\begin{verbatim}
''' + cmds + r'''
\end{verbatim}

{\small
\begin{longtable}{@{}p{.50\linewidth}p{.46\linewidth}@{}}
\caption{SHA-256 of v12 artifacts.}\\
\toprule
File & SHA-256\\
\midrule
\endfirsthead
\toprule
File & SHA-256\\
\midrule
\endhead
\bottomrule
\endfoot
''' + '\n'.join(rows) + r'''
\end{longtable}}
'''
os.makedirs(R + 'v12src', exist_ok=True)
open(R + 'v12src/artifacts.tex', 'w').write(app)
print('frozen identical', th['identical_before_after'], 'v9/v10 same', v10same, 'v1-8 same', v18same, 'files', len(man))
