"""v6: closed-form checks of the r^2-weighted apex coefficient D_b (logs/v6/weighted_apex.json)."""
import json, sympy as sp
a, b = sp.symbols('alpha b', positive=True)
B2 = b**2-b+sp.Rational(1,6); B4 = b**4-2*b**3+b**2-sp.Rational(1,30)
D = -11*a/180 + B2/(3*a) - B4/(6*a**3)
logD = sp.sympify(json.load(open('logs/v6/weighted_apex.json'))['D_b'], locals={'alpha': a, 'b': b})
out = {'D_matches_log': sp.simplify(D-logD) == 0}
out['D0'] = str(sp.factor(D.subs(b, 0)))
out['D_F_S1'] = str(sp.factor(D.subs(b, a)))
out['D_F_S2'] = str(sp.factor(D.subs(b, 2*a-1)))
out['D_CR_S2'] = str(sp.factor(D.subs(b, 2*a)))
nu = 2-1/a
out['CR_minus_F_S2_equals_flip'] = sp.simplify(D.subs(b, 2*a)-D.subs(b, 2*a-1)-2*nu*(1-nu**2)/3) == 0
out['D_CR_S2_at_1'] = str(sp.limit(D.subs(b, 2*a), a, 1))
out['D_F_S2_at_1'] = str(sp.limit(D.subs(b, 2*a-1), a, 1))
# orbifold identity  D_0(1/N) = (1/(4N)) sum_{k=1}^{N-1} csc^4(pi k/N)
chk = {}
for N in range(2, 9):
    s = sum(1/sp.sin(sp.pi*k/N)**4 for k in range(1, N))
    chk[N] = [str(sp.nsimplify(sp.N(s/(4*N), 40), rational=True)), str(D.subs({b: 0, a: sp.Rational(1, N)}))]
out['orbifold_csc4'] = chk
out['csc4_sum_closed_form'] = '(N^2-1)(N^2+11)/45'
print(json.dumps(out, indent=1)); json.dump(out, open('logs/v6/weighted_checks.json', 'w'), indent=1)
