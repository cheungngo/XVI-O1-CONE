#!/usr/bin/env python3
"""v11 artifact appendix: SHA-256 of v11 programs/logs, frozen-tree digests before/after, v1-v10 digests before/after.
Fix of the v10 staleness: CHECKPOINT_v11.md receives its last append BEFORE this script runs (no append afterwards), and the
current CHECKPOINT_v10.md hash is recorded next to the stale value in the v10 manifest."""
import hashlib, glob, os, subprocess, json, sys, platform
R = '/workspace/XVI-O1-CONE/'
def sha(p): return hashlib.sha256(open(p, 'rb').read()).hexdigest()
def tree(t):
    cmd = f"cd /workspace/XVI-{t} && find . -type f -not -path './.pytest_cache/*' -not -name '*.pyc' | sort | xargs sha256sum | sha256sum"
    return subprocess.run(cmd, shell=True, capture_output=True, text=True, env={**os.environ, 'LC_ALL': 'C.UTF-8'}).stdout.split()[0]
os.makedirs(R + 'logs/v11', exist_ok=True)
before = dict(l.split()[:2] for l in open(R + 'logs/frozen_v11_before.sha') if l.strip())
after = {t: tree(t) for t in 'PQR'}
th = {'before': {'XVI-' + t: before['XVI' + t] for t in 'PQR'}, 'after': {'XVI-' + t: after[t] for t in 'PQR'},
      'identical_before_after': {('XVI-' + t): before['XVI' + t] == after[t] for t in 'PQR'}}
json.dump(th, open(R + 'logs/v11/tree_hashes_v11.json', 'w'), indent=1)
v10b = dict((l.split()[1], l.split()[0]) for l in open(R + 'logs/v10_hashes_before_v11.sha') if l.strip())
v10same = all(sha(R + f) == h for f, h in v10b.items())
earlier = {f: sha(R + f) for f in sorted(glob.glob('XVI-O1-CONE-v[1-9].tex', root_dir=R) + glob.glob('XVI-O1-CONE-v[1-9].pdf', root_dir=R))}
prev = json.load(open(R + 'logs/v10/earlier_versions_sha.json'))
v18same = all(earlier.get(f) == h for f, h in prev.items())
earlier.update({f: sha(R + f) for f in ('XVI-O1-CONE-v10.tex', 'XVI-O1-CONE-v10.pdf')})
json.dump(earlier, open(R + 'logs/v11/earlier_versions_sha.json', 'w'), indent=1)
man10 = dict((l.split()[1], l.split()[0]) for l in open(R + 'logs/v10/artifact_manifest_v10.sha256') if l.strip())
ck = {'CHECKPOINT_v10.md in v10 manifest (stale, pre-final-append)': man10.get('CHECKPOINT_v10.md'),
      'CHECKPOINT_v10.md now': sha(R + 'CHECKPOINT_v10.md')}
json.dump(ck, open(R + 'logs/v11/checkpoint_v10_fix.json', 'w'), indent=1)
import sympy, mpmath
env = {'python': sys.version.split()[0], 'sympy': sympy.__version__, 'mpmath': mpmath.__version__, 'platform': platform.platform()}
json.dump(env, open(R + 'logs/v11/env.json', 'w'), indent=1)
G = lambda pat: sorted(glob.glob(pat, root_dir=R))
cache = G('logs/v11/M10/cache/*.json')
open(R + 'logs/v11/M10/cache_SHA256SUMS', 'w').write(''.join(f'{sha(R + f)}  {os.path.basename(f)}\n' for f in cache))
groups = [
 ('Base source (read-only)', ['XVI-O1-CONE-v10.tex']),
 ('v11 programs', G('code/v11/*.py') + G('code/v11/*.sh') + ['code/build_v11.py', 'code/artifacts_v11.py']),
 ('v11 source fragments', [f for f in G('v11src/*.tex') if 'artifacts' not in f]),
 ('F mode derivation', ['logs/v11/fmode_reduce.json', 'logs/v11/fmode_derive.json']),
 ('Degree bound (D)', ['logs/v11/degree_check.json', 'logs/v11/degree_crosscheck.json']),
 ('Mode sum M10', ['logs/v11/M10/jobs.txt', 'logs/v11/M10/m10.json', 'logs/v11/M10/cache_SHA256SUMS', 'logs/v11/M10/phi_corrected.json', 'logs/v11/M10/m10_text.tex', 'logs/v11/M10/jobs_dedup.txt'] + G('logs/v11/M10/m10_*.json')),
 ('Registry', ['logs/v11/registry_oct19.sha']),
 ('Integrity, environment', ['logs/frozen_v11_before.sha', 'logs/v11/tree_hashes_v11.json', 'logs/v10_hashes_before_v11.sha',
                             'logs/v11/earlier_versions_sha.json', 'logs/v11/checkpoint_v10_fix.json', 'logs/v11/env.json', 'CHECKPOINT_v11.md']),
]
rows, man = [], []
for title, files in groups:
    files = [f for f in files if os.path.exists(R + f)]
    rows.append(r'\multicolumn{2}{@{}l}{\textit{%s} (%d files)}\\' % (title, len(files)))
    for f in files:
        h = sha(R + f); man.append(f'{h}  {f}')
        rows.append(r'{\scriptsize\loc{%s}} & \texttt{\tiny %s}\\' % (f, h))
open(R + 'logs/v11/artifact_manifest_v11.sha256', 'w').write('\n'.join(man) + '\n')
cmds = r'''cd /workspace/XVI-O1-CONE
python3 code/v11/degree_check.py; python3 code/v11/degree_crosscheck.py
python3 code/v11/fmode_reduce.py; python3 code/v11/fmode_derive.py
python3 code/v11/m10_jobs.py > logs/v11/M10/jobs.txt
setsid nohup bash code/v11/m10_driver.sh > /dev/null 2>&1 &
python3 code/v11/m10_sum.py
python3 code/artifacts_v11.py && python3 code/build_v11.py
pdflatex -halt-on-error XVI-O1-CONE-v11.tex   # until stable'''
yn = lambda b: 'yes' if b else 'NO'
app = r'''
%======================================================================
\section{v11 artifacts, hashes and rerun commands}
\label{app:v11artifacts}
%======================================================================

Paths are relative to \loc{/workspace/XVI-O1-CONE/}. Long jobs ran
detached with \loc{setsid}, were logged, and were resumable through
per-item JSON caches. Environment: Python~''' + env['python'] + r''', SymPy~''' + env['sympy'] + r''', mpmath~''' + env['mpmath'] + r'''.
Frozen trees before \(=\) after: ''' + ', '.join(f"XVI-{t}: {yn(th['identical_before_after']['XVI-'+t])}" for t in 'PQR') + r'''.
Digests: ''' + ', '.join(f"XVI-{t} \\texttt{{{after[t][:16]}\\ldots}}" for t in 'PQR') + r'''.
The v9 and v10 sources and PDFs are unchanged: ''' + yn(v10same) + r'''. The v1--v8 sources are unchanged: ''' + yn(v18same) + r'''.
The cached \(F(\mu,\nu)\) values (''' + str(len(cache)) + r''' files) are hashed in \loc{logs/v11/M10/cache_SHA256SUMS}; the
superseded first run (Section~\ref{sec:v11bug}) is kept in \loc{logs/v11/M10/cache_superseded/} and feeds no printed value.
The full manifest is \loc{logs/v11/artifact_manifest_v11.sha256}; the \TeX{} source and PDF are hashed in \loc{SHA256SUMS_v11}.

\emph{Manifest fix.} The v10 manifest hashed \loc{CHECKPOINT_v10.md} one append before its final state
(\texttt{''' + str(ck['CHECKPOINT_v10.md in v10 manifest (stale, pre-final-append)'])[:16] + r'''\ldots}); its current hash is
\texttt{''' + ck['CHECKPOINT_v10.md now'][:16] + r'''\ldots} (\loc{logs/v11/checkpoint_v10_fix.json}). In v11 the last
append to \loc{CHECKPOINT_v11.md} precedes this hashing, and nothing is appended afterwards.

\paragraph{Rerun commands.}
\begin{verbatim}
''' + cmds + r'''
\end{verbatim}

{\small
\begin{longtable}{@{}p{.50\linewidth}p{.46\linewidth}@{}}
\caption{SHA-256 of v11 artifacts.}\\
\toprule
File & SHA-256\\
\midrule
\endfirsthead
\toprule
File & SHA-256\\
\midrule
\endhead
\bottomrule
\endfoot
''' + '\n'.join(rows) + r'''
\end{longtable}}
'''
os.makedirs(R + 'v11src', exist_ok=True)
open(R + 'v11src/artifacts.tex', 'w').write(app)
print('frozen identical', th['identical_before_after'], 'v9/v10 same', v10same, 'v1-8 same', v18same, 'files', len(man))
