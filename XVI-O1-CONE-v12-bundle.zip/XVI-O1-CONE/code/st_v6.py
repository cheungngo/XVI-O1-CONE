"""v6 item (a): hh Slavnov-Taylor row on constant-profile apex poles, with the conventions DERIVED from the XVI-P
closed forms (P14 amplitude_rules check 'K_c_equals_a_dc_plus_dc': K'_(mn) a (d_m c_n + d_n c_m), sum over independent (mn)):
   sum_a dh_a(c) B_ab h_b  +  lam * sum_(mn) Gamma_{K'_(mn) c^nu} c^nu * dS/dh_(mn) = 0,
   dh_(mn) = p_m c_n + p_n c_m (independent coordinates, c_n = eta_nn c^n),
   dS/dh_(mn) = (2 - delta_mn) E^{mn}(h)   (E = linearised Einstein operator, indices raised with eta=diag(1,-1,-1,-1)).
Exact symbolic test (no random sampling): residual is a polynomial in h00,h03,h33,f0,c0,c3,q0,q3 with alpha-dependent
coefficients; lam must be one alpha-independent constant.  usage: st_v6.py <path pattern with {g}> <label>"""
import json, sys, sympy as sp
tag, br = sys.argv[1], sys.argv[2]
q0, q3, al, ka = sp.symbols('q0 q3 alpha kappa'); al = sp.Symbol('alpha', positive=True)
ETA = [1, -1, -1, -1]; HC = [(0,0),(0,1),(0,2),(0,3),(1,1),(1,2),(1,3),(2,2),(2,3),(3,3)]
LAT = {0, 3, 9, 4, 7}
def load(g):
    try: D = json.load(open(tag.format(g=g)))['Gamma_pole_coeff_of_1/(4-d)']
    except FileNotFoundError: return None
    return {eval(k): sp.sympify(v, locals={'alpha': al}) for k, v in D.items()}
h00, h03, h33, f0, c0, c3, lam = sp.symbols('h00 h03 h33 f0 c0 c3 lam')
hx = {0: h00, 3: h03, 9: h33, 4: f0, 7: f0}
cu = {0: c0, 3: c3}
p = [q0, 0, 0, q3]
def B_of(graphs):
    Bm = {}
    for g in graphs:
        G = load(g)
        if G is None: print('MISSING', g); return None
        for (a, b), v in G.items():
            if a in LAT and b in LAT: Bm[(a, b)] = Bm.get((a, b), 0) + v
    return Bm
def dh():
    cl = [ETA[i] * cu.get(i, 0) for i in range(4)]
    return {i: p[m] * cl[n] + p[n] * cl[m] for i, (m, n) in enumerate(HC) if i in LAT}
def Eup():
    h = [[0]*4 for _ in range(4)]
    for i, (m, n) in enumerate(HC):
        if i in hx: h[m][n] = h[n][m] = hx[i]
    pu = [ETA[i]*p[i] for i in range(4)]
    tr = sum(ETA[i]*h[i][i] for i in range(4)); p2 = sum(ETA[i]*p[i]**2 for i in range(4))
    ph = [sum(pu[r]*h[r][n] for r in range(4)) for n in range(4)]; pph = sum(pu[n]*ph[n] for n in range(4))
    El = [[p2*h[m][n] - p[m]*ph[n] - p[n]*ph[m] + p[m]*p[n]*tr + (ETA[m] if m == n else 0)*(pph - p2*tr) for n in range(4)] for m in range(4)]
    # transversality check of E (lower): p^m E_mn = 0
    assert all(sp.expand(sum(pu[m]*El[m][n] for m in range(4))) == 0 for n in range(4))
    return {i: (2 - (m == n)) * ETA[m] * ETA[n] * El[m][n] for i, (m, n) in enumerate(HC)}
def row(hhgraphs, kc='D13'):
    Bm = B_of(hhgraphs); Gk = load(kc)
    if Bm is None or Gk is None: return None
    x = dh()
    t1 = sp.expand(sum(v * x.get(a, 0) * hx.get(b, 0) for (a, b), v in Bm.items()))
    Eu = Eup()
    t2 = sp.expand(sum(v * Eu.get(a, 0) * cu.get(n, 0) for (a, n), v in Gk.items()))
    return t1, t2
def coeffs(e):
    e = sp.expand(e)
    if e == 0: return {}
    P = sp.Poly(e, h00, h03, h33, f0, c0, c3, q0, q3)
    return {m: sp.factor(c) for m, c in zip(P.monoms(), P.coeffs())}
out = {'branch': br, 'conventions': 'derived (w=-2 on K_(03); c upper in vertex; E invariant)'}
r = row(['D01', 'D02', 'D03', 'D11', 'D12'])
t1, t2 = r
C1, C2 = coeffs(t1), coeffs(t2)
mons = sorted(set(C1) | set(C2))
out['n_equations'] = len(mons)
out['B_dh_h_terms'] = {str(m): str(c) for m, c in C1.items()}
out['G_Eh_c_terms'] = {str(m): str(c) for m, c in C2.items()}
sol = None
for m in mons:
    if C2.get(m, 0) != 0:
        sol = sp.simplify(-C1.get(m, 0) / C2[m]); break
res = {str(m): str(sp.factor(sp.simplify(C1.get(m, 0) + (sol if sol is not None else 0) * C2.get(m, 0)))) for m in mons}
out['lam'] = str(sol); out['residuals'] = res; out['all_zero'] = all(v == '0' for v in res.values())
out['lam_alpha_independent'] = (sol is not None) and (sp.diff(sol, al) == 0)
# matter subsector (scalar loop): D11 + D12 must be transverse by itself (no Kc scalar graph at one loop)
rm = row(['D11', 'D12']) if load('D12') is not None else row(['D11'])
out['matter_B_dh_h'] = str(sp.factor(rm[0]))
print(json.dumps(out, indent=1))
json.dump(out, open(f'/workspace/XVI-O1-CONE/logs/v6/st_v6_{br}.json', 'w'), indent=1)
