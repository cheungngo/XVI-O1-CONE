"""Generate the artifact appendix (full SHA-256 + rerun commands) and write the final v6 tex."""
import hashlib, glob, os, subprocess
R = '/workspace/XVI-O1-CONE/'
def sha(p): return hashlib.sha256(open(p, 'rb').read()).hexdigest()
def tree(t):
    cmd = f"cd /workspace/XVI-{t} && find . -type f -not -path './.pytest_cache/*' -not -name '*.pyc' | sort | xargs sha256sum | sha256sum"
    return subprocess.run(cmd, shell=True, capture_output=True, text=True).stdout.split()[0]
groups = [
 ('Base source (read-only copy)', ['XVI-O1-CONE-v5.tex']),
 ('Programs', ['code/' + f for f in ['spectral_apex.py', 'st_test_const.py', 'st_scan.py', 'catalogue_check.py', 'st_v6.py', 'st_norm.py',
               'st_v6_stats.py', 'flat_pole.py', 'flat_vs_p18.py', 'weighted_apex.py', 'weighted_checks.py', 'hi_d01.py',
               'hi_d01_exact.py', 'hh_structures.py', 'build_v6.py', 'artifacts_v6.py']]),
 ('Spectral logs (v4 session, audited in v6)', sorted(glob.glob('logs/v4/*.json', root_dir=R))),
 ('v6 logs', sorted(glob.glob('logs/v6/*.json', root_dir=R))),
 ('Read-only frozen inputs', ['/tmp/o1cone_ro/XVI-P/code/p5_entry/amplitude_rules.py', '/tmp/o1cone_ro/XVI-P/code/p5_entry/feynman.py',
   '/tmp/o1cone_ro/XVI-P/code/p5_entry/dred.py', '/tmp/o1cone_ro/XVI-Q/provenance/XVI-P/certificates/P18_D11.json',
   'xviq_regen/Q02_bulk_graphs.json']),
]
def tt(path): return path.replace('_', '\\_')
rows = []; manifest = []
for title, files in groups:
    rows.append('\\multicolumn{2}{@{}l}{\\textit{%s}}\\\\' % title)
    for f in files:
        p = f if f.startswith('/') else R + f
        h = sha(p); manifest.append(f'{h}  {f}')
        rows.append('\\texttt{\\footnotesize %s} & \\texttt{\\scriptsize %s\\\\ %s}\\\\' % (tt(f.replace('/tmp/o1cone_ro/', 'RO:')), h[:32], h[32:]) if False else
                    '{\\footnotesize\\loc{%s}} & \\texttt{\\scriptsize %s}\\newline\\texttt{\\scriptsize %s}\\\\' % (f.replace('/tmp/o1cone_ro/', 'RO:'), h[:32], h[32:]))
trees = {t: tree(t) for t in ['P', 'Q', 'R']}
before = dict(l.split()[::-1] if False else (l.split()[0], l.split()[1]) for l in open(R + 'logs/frozen_v6_before.sha').read().split('\n') if l.strip())
trow = []
for t in ['P', 'Q', 'R']:
    b = before.get('XVI' + t, before.get('XVI-' + t, '?'))
    trow.append('XVI-%s & \\texttt{\\scriptsize %s}\\newline\\texttt{\\scriptsize %s} & %s\\\\' % (t, trees[t][:32], trees[t][32:], 'identical' if b == trees[t] else 'DIFFERS'))
app = r"""%======================================================================
\section{Artifact manifest and rerun commands (new in v6)}
\label{app:artifacts}
%======================================================================

Paths are relative to \loc{/workspace/XVI-O1-CONE/}.
\texttt{RO:} denotes the read-only copies under
\loc{/tmp/o1cone_ro/}; their digests equal those of the originals in
the frozen trees.
The frozen-tree digest is
\begin{center}\footnotesize
\verb!cd /workspace/XVI-$t && find . -type f -not -path './.pytest_cache/*'!\\
\verb!  -not -name '*.pyc' | sort | xargs sha256sum | sha256sum!
\end{center}

\begingroup\small
\begin{longtable}{@{}L{.10\linewidth}L{.52\linewidth}L{.25\linewidth}@{}}
\toprule
Tree & SHA-256 (before and after v6) & before vs.\ after\\
\midrule
\endfirsthead
\bottomrule
\endfoot
""" + '\n'.join(trow) + r"""
\end{longtable}
\endgroup

\begingroup\small
\begin{longtable}{@{}L{.50\linewidth}L{.44\linewidth}@{}}
\toprule
File & SHA-256\\
\midrule
\endfirsthead
\toprule
File & SHA-256\\
\midrule
\endhead
\bottomrule
\endfoot
""" + '\n'.join(rows) + r"""
\end{longtable}
\endgroup

\paragraph{Rerun commands.}
All commands run from \loc{/workspace/XVI-O1-CONE}.
The spectral runs were launched as detached jobs with logs because
the machine has about 7\,GB of memory.
\begin{center}\footnotesize
\begin{tabular}{@{}l@{}}
\verb!for g in D01 D02 D03 D04 D05a D06 D11 D12 D13; do for b in CR F; do!\\
\verb!  setsid python3 code/spectral_apex.py $g $b > logs/v4/spec_${g}_${b}.log 2>&1; done; done!\\
\verb!for g in D01 D02 D03 D06 D11 D12 D13; do setsid python3 code/spectral_apex.py $g UNIT \!\\
\verb!  > logs/v4/spec_${g}_UNIT.log 2>&1; done!\\
\verb!python3 code/catalogue_check.py          # -> logs/v6/catalogue_check.json!\\
\verb!python3 code/st_norm.py                  # -> logs/v6/st_norm.json!\\
\verb!for b in CR F UNIT; do python3 code/st_v6.py "logs/v4/spec_{g}_$b.json" $b; done!\\
\verb!for g in D01 D02 D03 D06 D11 D12 D13; do python3 code/flat_pole.py $g; done!\\
\verb!python3 code/st_v6.py "logs/v6/flat_{g}.json" FLAT!\\
\verb!python3 code/st_v6_stats.py; python3 code/flat_vs_p18.py!\\
\verb!python3 code/weighted_apex.py; python3 code/weighted_checks.py!\\
\verb!python3 code/hi_d01.py; python3 code/hi_d01_exact.py!\\
\verb!python3 code/hh_structures.py!\\
\verb!python3 code/build_v6.py && python3 code/artifacts_v6.py!\\
\verb!cd v6build && pdflatex XVI-O1-CONE-v6.tex && pdflatex XVI-O1-CONE-v6.tex!
\end{tabular}
\end{center}
The spectral runs (first four lines) were executed during the v4 session
and were not repeated for v6; every other command was run for v6.
"""
s = open(R + 'v6build/XVI-O1-CONE-v6.pre.tex').read()
assert '%%ARTIFACT_APPENDIX%%' in s
s = s.replace('%%ARTIFACT_APPENDIX%%', app)
open(R + 'v6build/XVI-O1-CONE-v6.tex', 'w').write(s)
open(R + 'logs/v6/artifact_manifest.sha256', 'w').write('\n'.join(manifest) + '\n')
open(R + 'logs/frozen_v6_after.sha', 'w').write('\n'.join(f'XVI{t} {trees[t]}' for t in trees) + '\n')
print(trees, before)
