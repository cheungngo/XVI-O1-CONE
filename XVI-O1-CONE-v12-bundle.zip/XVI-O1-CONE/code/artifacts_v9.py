#!/usr/bin/env python3
"""v9 artifact appendix: SHA-256 of every v9 program/log, frozen-tree digests (before/after), v8 file digests
(before/after), environment; writes v9src/artifacts.tex, logs/v9/tree_hashes_v9.json, logs/v9/env.json,
logs/v9/scan/SHA256SUMS, logs/v9/artifact_manifest_v9.sha256, logs/v9/v8_hashes_after.sha."""
import hashlib, glob, os, subprocess, json, sys, platform
R = '/workspace/XVI-O1-CONE/'
def sha(p): return hashlib.sha256(open(p, 'rb').read()).hexdigest()
def tree(t):
    cmd = f"cd /workspace/XVI-{t} && find . -type f -not -path './.pytest_cache/*' -not -name '*.pyc' | sort | xargs sha256sum | sha256sum"
    return subprocess.run(cmd, shell=True, capture_output=True, text=True, env={**os.environ, 'LC_ALL': 'C.UTF-8'}).stdout.split()[0]
before = dict(l.split()[:2] for l in open(R + 'logs/frozen_v9_before.sha') if l.strip())
after = {t: tree(t) for t in 'PQR'}
th = {'before': {'XVI-' + t: before['XVI' + t] for t in 'PQR'}, 'after': {'XVI-' + t: after[t] for t in 'PQR'},
      'identical_before_after': {('XVI-' + t): before['XVI' + t] == after[t] for t in 'PQR'}, 'locale': 'C.UTF-8'}
json.dump(th, open(R + 'logs/v9/tree_hashes_v9.json', 'w'), indent=1)
v8b = dict((l.split()[1], l.split()[0]) for l in open(R + 'logs/v9/v8_hashes_before.sha') if l.strip())
v8a = {f: sha(R + f) for f in v8b}
open(R + 'logs/v9/v8_hashes_after.sha', 'w').write(''.join(f'{h}  {f}\n' for f, h in v8a.items()))
v8same = all(v8a[f] == v8b[f] for f in v8b)
earlier = {f: sha(R + f) for f in sorted(glob.glob('XVI-O1-CONE-v[1-8]*.tex', root_dir=R))}
json.dump(earlier, open(R + 'logs/v9/earlier_versions_sha.json', 'w'), indent=1)
import sympy, mpmath
env = {'python': sys.version.split()[0], 'sympy': sympy.__version__, 'mpmath': mpmath.__version__, 'platform': platform.platform()}
try: env['pdftex'] = subprocess.run(['pdflatex', '--version'], capture_output=True, text=True).stdout.splitlines()[0]
except Exception: env['pdftex'] = 'unavailable'
json.dump(env, open(R + 'logs/v9/env.json', 'w'), indent=1)
scan = sorted(glob.glob('logs/v9/scan/apex_*.json', root_dir=R))
open(R + 'logs/v9/scan/SHA256SUMS', 'w').write(''.join(f'{sha(R + f)}  {os.path.basename(f)}\n' for f in scan))
G = lambda pat: sorted(glob.glob(pat, root_dir=R))
groups = [
 ('Base source (read-only)', ['XVI-O1-CONE-v8.tex']),
 ('v9 programs', G('code/v9/*.py') + G('code/v9/*.sh') + ['code/build_v9.py', 'code/artifacts_v9.py']),
 ('v9 source fragments', [f for f in G('v9src/*.tex') if 'artifacts' not in f]),
 ('Mixed trace and hidden pairs', ['logs/v9/g_formula_check.json', 'logs/v9/asym02.json'] + G('logs/v9/hidden/*.json')),
 ('Ghost dictionary and exact values', G('logs/v9/cbck_map_*.json') + G('logs/v9/ck_free_*.json') + ['logs/v9/e_solve.json']),
 ('Chambers and modular scan', ['logs/v9/chamber_cache2.json', 'logs/v9/scan/SHA256SUMS', 'logs/v9/scan/alphas.txt']),
 ('Obstruction checks', ['logs/v9/evan_match.json', 'logs/v9/vector_logs.json']),
 ('Registry', ['logs/v9/sheets_extract.txt', 'logs/v9/sheet_ICEx2_extract.txt', '../XVI-R-companion-intake/new_oct18g/SHA256SUMS']),
 ('Integrity, environment', ['logs/frozen_v9_before.sha', 'logs/v9/tree_hashes_v9.json', 'logs/v9/v8_hashes_before.sha',
                             'logs/v9/v8_hashes_after.sha', 'logs/v9/earlier_versions_sha.json', 'logs/v9/env.json', 'CHECKPOINT_v9.md']),
]
rows, man = [], []
for title, files in groups:
    rows.append(r'\multicolumn{2}{@{}l}{\textit{%s} (%d files)}\\' % (title, len(files)))
    for f in files:
        h = sha(R + f); man.append(f'{h}  {f}')
        rows.append(r'{\scriptsize\loc{%s}} & \texttt{\tiny %s}\\' % (f.replace('../XVI-R-companion-intake/', 'intake/'), h))
open(R + 'logs/v9/artifact_manifest_v9.sha256', 'w').write('\n'.join(man) + '\n')
cmds = r'''cd /workspace/XVI-O1-CONE
python3 code/v9/g_formula_check.py
python3 code/v9/mixed02.py   # -> logs/v9/asym02.json (~250 s)
setsid nohup python3 code/v9/hidden02_run.py \
   > logs/v9/hidden/run.log 2>&1 &
python3 code/v9/cbck_map.py 3/10 CR   # and 3/10 F, 7071/10000 CR|F
python3 code/v9/ck_free.py 3/10 CR    # and the other three points
python3 code/v9/e_solve.py
python3 code/v9/chamber_scan.py       # resumable cache
setsid nohup bash code/v9/scan_driver.sh \
   > logs/v9/scan/driver.log 2>&1 &
setsid nohup bash code/v9/scan_driver_rev.sh \
   > logs/v9/scan/driver_rev.log 2>&1 &
python3 code/v9/evan_match.py
python3 code/v9/vector_logs.py
python3 code/artifacts_v9.py && python3 code/build_v9.py
pdflatex -halt-on-error XVI-O1-CONE-v9.tex   # twice'''
app = r'''
%======================================================================
\section{v9 artifacts, hashes and rerun commands}
\label{app:v9artifacts}
%======================================================================

Paths are relative to the project directory \loc{XVI-O1-CONE/} under \loc{/workspace}; \loc{intake/} abbreviates the companion intake directory \loc{XVI-R-companion-intake/}. Long jobs
were run detached with \loc{setsid}, logged, and made resumable
with per-item JSON caches, because the box runs out of memory at
about 7~GB and is restored from time to time. Environment:
Python~''' + env['python'] + r''', SymPy~''' + env['sympy'] + r''', mpmath~''' + env['mpmath'] + r''', \loc{LC_ALL=C.UTF-8}.
Frozen trees before = after: ''' + ', '.join(f"XVI-{t}: {'yes' if th['identical_before_after']['XVI-'+t] else 'NO'}" for t in 'PQR') + r'''.
The v8 source and PDF are unchanged: ''' + ('yes' if v8same else 'NO') + r'''.
The modular scan comprises ''' + str(len(scan)) + r''' result files, which are hashed individually in
\loc{logs/v9/scan/SHA256SUMS}. The full manifest is
\loc{logs/v9/artifact_manifest_v9.sha256}, and the \TeX{} source and
PDF are hashed in \loc{SHA256SUMS_v9}.
\loc{code/v9/mixed02.py} is kept only because it produced the
asymptotic coefficients. Its \({}_3F_2\) shortcut is unreliable at
large parameter and is not used for any printed value.

\paragraph{Rerun commands.}
\begin{verbatim}
''' + cmds + r'''
\end{verbatim}

{\small
\begin{longtable}{@{}p{.50\linewidth}p{.46\linewidth}@{}}
\caption{SHA-256 of v9 artifacts.}\\
\toprule
File & SHA-256\\
\midrule
\endfirsthead
\toprule
File & SHA-256\\
\midrule
\endhead
\bottomrule
\endfoot
''' + '\n'.join(rows) + r'''
\end{longtable}}
'''
open(R + 'v9src/artifacts.tex', 'w').write(app)
print(th, 'v8 same', v8same, len(man), len(scan), env)
