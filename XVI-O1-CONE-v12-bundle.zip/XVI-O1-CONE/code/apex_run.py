"""Driver: apex counterterm inventory, ST constraints (sigma_0-closure), exact directions, gh1 cohomology,
kappa^1 one-point apex sector, and the flat-bulk sanity check (reproduces the XVI-P p14r 5/2/3/1 counts).
usage: python3 apex_run.py <alpha as fraction p/q> <branch CR|F> [prime_index]"""
import sys, json, random, time
from fractions import Fraction as Fr
sys.path.insert(0, '/workspace/XVI-O1-CONE/code')
import apex_jets as AJ
from apex_jets import Setup, Ops, rand_cfg, candidates, eval_sym, eval_cand, rank_and_basis, nullspace, foreign, negq, reflect
alpha = Fr(sys.argv[1]); branch = sys.argv[2]; pi = int(sys.argv[3]) if len(sys.argv) > 3 else 0
AJ.setprime(AJ.PRIMES[pi]); P = AJ.P
random.seed(12345 + pi)
S = Setup(alpha, branch)
T0 = time.time()
def rq(): return [random.randrange(1, 1000), random.randrange(1, 1000)]
NS = 60
DM = 6
SECT = {'HH': ('h', 'h', True), 'CB': ('cb', 'c', False), 'CK': ('K', 'c', False), 'PP': ('phi', 'phi', False)}
SECT['PP'] = ('phi', 'phi', True)
res = {'alpha': str(alpha), 'branch': branch, 'prime': P}
# ---------- candidate bases per gh0 sector
basis = {}; dims = {}; jetpairs = {}
for name, (F1, F2, bose) in SECT.items():
    cands = candidates(S, F1, F2, 4)
    samples = []
    for _ in range(max(NS, len(cands) + 10)):
        samples.append((rand_cfg(S, F1, DM), rand_cfg(S, F2, DM), rq()))
    rows = [[eval_sym(c, a, b, q, bose) for (a, b, q) in samples] for c in cands]
    r, piv = rank_and_basis(rows)
    basis[name] = [cands[i] for i in piv]; dims[name] = r
    jetpairs[name] = sorted(set((str(c[0]), str(c[1]), c[4]) for c in basis[name]))
res['gh0_candidate_dims'] = dims; res['gh0_jet_pairs'] = jetpairs
print('dims', dims, round(time.time() - T0, 1), flush=True)
# ---------- ST rows (sigma_0 closure)
order = [(name, i) for name in SECT for i in range(len(basis[name]))]
def C(name, i, a, b, q):
    F1, F2, bose = SECT[name]; return eval_sym(basis[name][i], a, b, q, bose)
rows = []; foreign_hits = []
nrow = len(order) + 20
for _ in range(nrow):   # row [h c]: 2 C_hh(h, K2 c) + C_ck(E h, c)
    q = rq(); h = rand_cfg(S, 'h', DM); c = rand_cfg(S, 'c', DM)
    K2c = Ops(S, q).K2(c); Eh = Ops(S, negq(q)).E(h)
    fh = foreign(S, 'h', K2c)
    if fh: foreign_hits.append(('K2c', fh[:4]))
    row = []
    for (name, i) in order:
        if name == 'HH': row.append(2 * C(name, i, h, K2c, q) % P)
        elif name == 'CK': row.append(C(name, i, Eh, c, q))
        else: row.append(0)
    rows.append(row)
for _ in range(nrow):   # row [b c]: C_cb(b, c) + C_ck(C2^T b, c)
    q = rq(); b = rand_cfg(S, 'b', DM); c = rand_cfg(S, 'c', DM)
    C2Tb = Ops(S, negq(q)).C2T(b)
    row = []
    for (name, i) in order:
        if name == 'CB': row.append(C(name, i, b, c, q))
        elif name == 'CK': row.append(C(name, i, C2Tb, c, q))
        else: row.append(0)
    rows.append(row)
Z = nullspace(rows, len(order))
res['N_total'] = len(order); res['Z_dim'] = len(Z)
# sector-resolved: which sectors are entirely free / constrained
res['Z_by_sector_support'] = {}
for name in SECT:
    idx = [k for k, (nm, i) in enumerate(order) if nm == name]
    sub = [[z[k] for k in idx] for z in Z]
    res['Z_by_sector_support'][name] = rank_and_basis(sub)[0] if sub else 0
res['foreign_atoms_in_K2c'] = foreign_hits[:3]; res['n_foreign_samples'] = len(foreign_hits)
print('Z', len(Z), 'of', len(order), 'foreign', len(foreign_hits), round(time.time() - T0, 1), flush=True)
# ---------- exact directions (gh -1): X1=(h,cb), X2=(h,K), X3=(cs,c)
XS = {'X1': ('h', 'cb', 3), 'X2': ('h', 'K', 3), 'X3': ('cs', 'c', 3)}
xb = {}
for nm, (F1, F2, T) in XS.items():
    cands = candidates(S, F1, F2, T)
    samples = [(rand_cfg(S, F1, DM), rand_cfg(S, F2, DM), rq()) for _ in range(len(cands) + 10)]
    rws = [[eval_sym(c, a, b, q, False) for (a, b, q) in samples] for c in cands]
    r, piv = rank_and_basis(rws); xb[nm] = [cands[i] for i in piv]
res['gh-1_dims'] = {k: len(v) for k, v in xb.items()}
xorder = [(nm, i) for nm in XS for i in range(len(xb[nm]))]
def X(nm, i, a, b, q): return eval_sym(xb[nm][i], a, b, q, False)
# sigma_0 images evaluated on gh0 sample pairs of sectors HH, CB, CK and the non-permitted (h,b)
def img_samples(n):
    out = []
    for _ in range(n):
        q = rq()
        out.append(('HH', rand_cfg(S, 'h', DM), rand_cfg(S, 'h', DM), q))
        out.append(('CB', rand_cfg(S, 'cb', DM), rand_cfg(S, 'c', DM), q))
        out.append(('CK', rand_cfg(S, 'K', 3), rand_cfg(S, 'c', DM), q))
        out.append(('HB', rand_cfg(S, 'h', DM), rand_cfg(S, 'b', DM), q))
    return out
smp = img_samples(len(order) + len(xorder) + 10)
def sigma_X(nm, i, sec, a, b, q):
    """value of sigma_0 X on a gh0 sample (sec; slot A cfg a at -q, slot B cfg b at q)"""
    if nm == 'X1':   # X1(h,cb): s -> X1(K2 c, cb) + X1(h, b)
        if sec == 'CB':   # (cb slot A, c slot B): -X1(K2 c [momentum q, plays slot A], cb [slot B, momentum -q]) (odd swap)
            return (-X(nm, i, Ops(S, q).K2(b), a, negq(q))) % P
        if sec == 'HB': return X(nm, i, a, b, q)
        return 0
    if nm == 'X2':   # X2(h,K): s -> X2(K2 c, K) + X2(h, E h' + C2^T b)
        if sec == 'CK': return (-X(nm, i, Ops(S, q).K2(b), a, negq(q))) % P   # odd swap
        if sec == 'HH':
            v = X(nm, i, a, Ops(S, q).E(b), q) + X(nm, i, b, Ops(S, negq(q)).E(a), negq(q))
            return v * pow(2, P - 2, P) % P   # polarization convention: F(h)=C_sym(h,h)
        if sec == 'HB': return X(nm, i, a, Ops(S, q).C2T(b), q)
        return 0
    if nm == 'X3':   # X3(cs,c): s -> X3(K2^T K - (C2K2)^T cb, c)
        if sec == 'CK': return X(nm, i, Ops(S, negq(q)).K2T(a), b, q)
        if sec == 'CB': return (-X(nm, i, Ops(S, negq(q)).ghost(a), b, q)) % P
        return 0
Mimg = [[sigma_X(nm, i, sec, a, b, q) for (sec, a, b, q) in smp] for (nm, i) in xorder]
Mbas = [[(C(name, i, a, b, q) if sec == name else 0) for (sec, a, b, q) in smp] for (name, i) in order]
# constraint: zero HB component
hbcols = [k for k, s in enumerate(smp) if s[0] == 'HB']
A_hb = [[Mimg[r][k] for r in range(len(xorder))] for k in hbcols]
Xok = nullspace(A_hb, len(xorder))
imgs = []
for xv in Xok:
    vec = [sum(xv[r] * Mimg[r][k] for r in range(len(xorder))) % P for k in range(len(smp))]
    imgs.append(vec)
rB, _ = rank_and_basis(imgs) if imgs else (0, [])
rBas, _ = rank_and_basis(Mbas)
rBoth, _ = rank_and_basis(Mbas + imgs)
res['exact_dim_B'] = rB; res['B_in_candidate_span'] = (rBoth == rBas)
# B subset of Z? express images in basis and test rows
if imgs and rBoth == rBas:
    # solve coefficients: for each image vec find y with y.Mbas = vec  (use nullspace of [Mbas; -vec]^T)
    inZ = True; Zrows = rows
    for vec in imgs:
        aug = [[Mbas[r][k] for r in range(len(order))] + [(-vec[k]) % P] for k in range(len(smp))]
        ns = nullspace(aug, len(order) + 1)
        sol = next((v for v in ns if v[-1]), None)
        if sol is None: inZ = False; break
        inv = pow(sol[-1], P - 2, P); y = [x * inv % P for x in sol[:-1]]
        if any(sum(rw[k] * y[k] for k in range(len(order))) % P for rw in Zrows): inZ = False; break
    res['B_subset_Z'] = inZ
res['H0_dim'] = len(Z) - rB if res.get('B_subset_Z') else None
print('B', rB, res.get('B_subset_Z'), round(time.time() - T0, 1), flush=True)
# ---------- gh1 cohomology (anomaly candidates): sectors HC=(h,c), BC=(b,c)
G1 = {'HC': ('h', 'c'), 'BC': ('b', 'c')}
gb = {}
for nm, (F1, F2) in G1.items():
    cands = candidates(S, F1, F2, 5)
    samples = [(rand_cfg(S, F1, DM), rand_cfg(S, F2, DM), rq()) for _ in range(len(cands) + 10)]
    rws = [[eval_sym(c, a, b, q, False) for (a, b, q) in samples] for c in cands]
    r, piv = rank_and_basis(rws); gb[nm] = [cands[i] for i in piv]
res['gh1_dims'] = {k: len(v) for k, v in gb.items()}
gorder = [(nm, i) for nm in G1 for i in range(len(gb[nm]))]
# WZ consistency: Delta_hc(K2 c1, c2) - Delta_hc(K2 c2, c1) = 0 ; BC part unconstrained
wz = []
for _ in range(len(gorder) + 15):
    q = rq(); c1 = rand_cfg(S, 'c', DM); c2 = rand_cfg(S, 'c', DM)
    row = []
    for (nm, i) in gorder:
        if nm == 'HC':
            v = eval_sym(gb[nm][i], Ops(S, negq(q)).K2(c1), c2, q, False) - eval_sym(gb[nm][i], Ops(S, q).K2(c2), c1, negq(q), False)
            row.append(v % P)
        else: row.append(0)
    wz.append(row)
Zg1 = nullspace(wz, len(gorder))
# exact gh1 = sigma_0 (gh0 candidates) : evaluate the row maps on gh1 samples and fit into gh1 basis
gsm = []
for _ in range(len(gorder) + len(order) + 10):
    q = rq(); gsm.append(('HC', rand_cfg(S, 'h', DM), rand_cfg(S, 'c', DM), q)); gsm.append(('BC', rand_cfg(S, 'b', DM), rand_cfg(S, 'c', DM), q))
def sig0(name, i, sec, a, b, q):
    if sec == 'HC':
        if name == 'HH': return 2 * C(name, i, a, Ops(S, q).K2(b), q) % P
        if name == 'CK': return C(name, i, Ops(S, negq(q)).E(a), b, q)
        return 0
    if sec == 'BC':
        if name == 'CB': return C(name, i, a, b, q)
        if name == 'CK': return C(name, i, Ops(S, negq(q)).C2T(a), b, q)
        return 0
Gimg = [[sig0(name, i, sec, a, b, q) for (sec, a, b, q) in gsm] for (name, i) in order]
Gbas = [[(eval_sym(gb[nm][i], a, b, q, False) if sec == nm else 0) for (sec, a, b, q) in gsm] for (nm, i) in gorder]
rG, _ = rank_and_basis(Gimg); rGb, _ = rank_and_basis(Gbas); rGB, _ = rank_and_basis(Gbas + Gimg)
res['gh1_Z_dim'] = len(Zg1); res['gh1_exact_dim'] = rG; res['gh1_image_in_span'] = (rGB == rGb)
# images in gh1 coordinates -> WZ rows must annihilate them (sigma_0^2 = 0 check)
closed = None
if rGB == rGb:
    closed = True
    for vec in Gimg:
        aug = [[Gbas[r][k] for r in range(len(gorder))] + [(-vec[k]) % P] for k in range(len(gsm))]
        ns = nullspace(aug, len(gorder) + 1); sol = next((v for v in ns if v[-1]), None)
        if sol is None: closed = False; break
        inv = pow(sol[-1], P - 2, P); y = [x * inv % P for x in sol[:-1]]
        if any(sum(rw[k] * y[k] for k in range(len(gorder))) % P for rw in wz): closed = False; break
res['gh1_images_WZ_closed'] = closed
res['H1_dim'] = len(Zg1) - rG if (rGB == rGb and closed) else None
print('gh1', len(gorder), len(Zg1), rG, rGB == rGb, round(time.time() - T0, 1), flush=True)
# ---------- kappa^1 one-point apex sector (single h, n=0, [h]+m=3, k=0)
one = []
for (Cc, n, m) in S.jets('h', 3):
    if n != 0 or 1 + m != 3: continue
    rk = AJ.TEN[Cc][1]
    if rk == 2: one.append((Cc, m, 'trace'))
    elif rk == 0: one.append((Cc, m, 'value'))
def ev1(c, cfg):
    Cc, m, kind = c; tot = 0
    for cf in (cfg, reflect(cfg)):
        v = cf.get(Cc, {}).get((0, m))
        if v is None: continue
        tot += (v[0] + v[3]) if kind == 'trace' else v[0]
    return tot % P
samp1 = [rand_cfg(S, 'h', DM) for _ in range(20)]
r1, piv1 = rank_and_basis([[ev1(c, h) for h in samp1] for c in one]); one = [one[i] for i in piv1]
q0 = [0, 0]
st1 = []
for _ in range(20):
    k2c = Ops(S, q0).K2(rand_cfg(S, 'c', DM)); st1.append([ev1(c, k2c) for c in one])
Z1 = nullspace(st1, len(one))
# linearized curvature invariants at W: R, R_ii (=Ric_PM), R_ijij (2D transverse curvature)
def jet0(X, comp='S'): return X.get(comp, {}).get((0, 0), [0])[0]
def curv(h):
    o = Ops(S, q0)
    R = o.tadd(o.divv(o.divt(h)), o.box(o.tr(h), {'S': 0}), facs=[1, P - 1])
    Ric = o.Ric(h)
    # transverse 2D curvature: div_perp div_perp h_perp - Lap_perp tr_perp h
    dP = o.addd(o.Dwb(h.get('PM', {}), 0), o.Dw(h.get('PP', {}), 2)); dM = o.addd(o.Dwb(h.get('MM', {}), -2), o.Dw(h.get('PM', {}), 0))
    ddp = o.addd(o.Dwb(dM, -1), o.Dw(dP, 1)); lap = o.sc(o.Dw(o.Dwb(h.get('PM', {}), 0), 1), 4)
    R2 = o.addd(ddp, lap, facs=[1, P - 1])
    return [jet0(R), jet0(Ric, 'PM'), R2.get((0, 0), [0])[0]]
cv = [curv(h) for h in samp1]
M1 = [[ev1(c, h) for h in samp1] for c in one] + [[cv[s][j] for s in range(len(samp1))] for j in range(3)]
rc, _ = rank_and_basis([[cv[s][j] for s in range(len(samp1))] for j in range(3)])
rall, _ = rank_and_basis(M1)
res['kappa1_onepoint'] = {'candidates': [list(map(str, c)) for c in one], 'N': len(one), 'ST_closed_dim': len(Z1),
                          'curvature_invariants_rank': rc, 'curvatures_in_candidate_span': (rall == len(one))}
print('1pt', res['kappa1_onepoint'], flush=True)
res['seconds'] = round(time.time() - T0, 1)
json.dump(res, open('/workspace/XVI-O1-CONE/logs/v2apex/apex_%s_%s_p%d.json' % (str(alpha).replace('/', '_'), branch, pi), 'w'), indent=1)
print(json.dumps({k: v for k, v in res.items() if k != 'gh0_jet_pairs'}, indent=1))
