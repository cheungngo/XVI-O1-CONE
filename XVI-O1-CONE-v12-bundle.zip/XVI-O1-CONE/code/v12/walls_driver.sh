#!/bin/bash
cd /workspace/XVI-O1-CONE
for a in 1/3 1/2 2/3; do for b in CR F; do
  t=$(echo $a | tr / _)_$b
  [ -s logs/v12/walls/apex_cert_${t}.json ] && continue
  python3 code/v12/wall_certificate.py $a $b > logs/v12/walls/run_${t}.log 2>&1 &
done; done
wait; echo ALLDONE >> logs/v12/walls/driver.log
