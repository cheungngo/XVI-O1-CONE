"""v12 item (1): large-h expansion of G_d(h) = F(h+d/2, h-d/2) from the v11 cache (P0: d=1; P1: d=1-1/alpha).
Fit sum_j a_j h^{3-j} on h >= HMIN using all cached points with the given d; report a_j and rational guesses."""
import json, glob, sys
from fractions import Fraction as Fr
import mpmath as mp
mp.mp.dps = 40
D = '/workspace/XVI-O1-CONE/logs/v11/M10/cache'
pts = {}
for f in glob.glob(D + '/*.json'):
    d = json.load(open(f)); m, n = Fr(d['mu']), Fr(d['nu'])
    dd = abs(m - n); h = (m + n)/2
    pts.setdefault(dd, []).append((h, mp.mpf(d['F'])))
def fit(dd, hmin, nj):
    P = sorted([p for p in pts[dd] if p[0] >= hmin])
    if len(P) < nj + 2: return None
    hh = P[len(P)//2][0]; S = mp.mpf(hh.numerator)/hh.denominator
    A = mp.matrix([[ (mp.mpf(h.numerator)/h.denominator/S)**(3-j) for j in range(nj)] for h, _ in P]); b = mp.matrix([v for _, v in P])
    c, res = mp.qr_solve(A, b)
    return [c[j]/S**(3-j) for j in range(nj)], len(P), res
if __name__ == '__main__':
    for dd in sorted(pts, key=lambda x: -len(pts[x]))[:6]:
        print('d =', dd, 'npts', len(pts[dd]), 'hmax', float(max(p[0] for p in pts[dd])))
        for nj in (12, 14, 16):
            r = fit(dd, 15, nj)
            if r: print('  nj', nj, 'n', r[1], [mp.nstr(x, 14) for x in r[0][:8]])
