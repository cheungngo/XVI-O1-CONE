"""v12 item (1): M10 to high precision from the closed form of F (code/v12/F_closed.py).
Families: P0 (derived pairing) pos h_k = k/alpha + 1/2 (k>=0), neg h_j = j/alpha - 1/2 (j>=1), d = 1;  (P1 kept for comparison: d = 1/alpha - 1).
Regulators: weight w_k^{-eps} with w = alpha*h (R_h), k (R_k), alpha*mu (R_mu), alpha*nu (R_nu); zero-weight terms (k=0 with R_k) unregulated.
Head: exact closed-form terms k < K.  Tail: asymptotic series of F in the regulator variable u (exact Bernoulli coefficients, J terms),
summed by Hurwitz zeta; u^{-1} term -> pole c/eps (reported) and finite part -c psi(u_K) (+ c log-scale for scaled weights).
Precision check: K = 400 vs K = 800, J = 30 vs 40."""
import sys, json
sys.path.insert(0, '/workspace/XVI-O1-CONE/code/v12')
from fractions import Fraction as Fr
import sympy as sp, mpmath as mp
DPS = int(sys.argv[1]) if len(sys.argv) > 1 else 50
mp.mp.dps = DPS + 10
h, u = sp.symbols('h u', positive=True)
def F_asym_coeffs(d, J):
    """coefficients a_j of F ~ sum_j a_j h^{3-j}, j < J (exact rationals in d)."""
    Q = -h**2*(h**2-1)/48; P = h**3/48 + h**2/96 - 5*h/288 - sp.Rational(1, 96)
    ser = 1/h + 1/(2*h**2) + sum(sp.bernoulli(2*n)/h**(2*n+1) for n in range(1, J//2 + 3))
    e = sp.expand(h**3/3 + (d**2/6 - sp.Rational(1, 3))*h + d**2*(d**2-4)*(P + Q*ser))
    return [e.coeff(h, 3-j) for j in range(J)]
def Fval(hh, d):
    Q = -hh**2*(hh**2-1)/48; P = hh**3/48 + hh**2/96 - 5*hh/288 - mp.mpf(1)/96
    if hh == 0: return d**2*(d**2-4)*(P + mp.mpf(1)/48)   # limit h^2 psi1(h) -> 1
    return hh**3/3 + (d**2/6 - mp.mpf(1)/3)*hh + d**2*(d**2-4)*(P + Q*mp.psi(1, hh))
def family(al, P, side):
    """returns (h(k), d, kmin, list of (regname, scale s, shift t) with w = s*(k + t))"""
    a = mp.mpf(al.numerator)/al.denominator
    if P == 'P0':
        d = mp.mpf(1); sg = 1 if side == 'pos' else -1
        hk = lambda k: k/a + sg*mp.mpf(1)/2; kmin = 0 if side == 'pos' else 1
        # h = (k + sg*a/2)/a ; mu = h + d/2 ; nu = h - d/2
        regs = {'Rh': (1/a, sg*a/2), 'Rk': (mp.mpf(1), mp.mpf(0)), 'Rmu': (1/a, sg*a/2 + a/2), 'Rnu': (1/a, sg*a/2 - a/2)}
    else:
        d = abs(1 - 1/a); 
        if side == 'pos': hk = lambda k: (2*k + 1 + a)/(2*a); kmin = 0; t = (1 + a)/2
        else: hk = lambda k: (2*k - 1 - a)/(2*a); kmin = 1; t = -(1 + a)/2
        regs = {'Rh': (1/a, t), 'Rk': (mp.mpf(1), mp.mpf(0))}
    return hk, d, kmin, regs
def famsum(al, P, side, reg, K, J):
    a = mp.mpf(al.numerator)/al.denominator
    hk, d, kmin, regs = family(al, P, side); s, t = regs[reg]
    head = mp.fsum(Fval(hk(k), d) for k in range(kmin, K))
    # F as series in v = k + t: h = (v - t)/a + h(0)... use h = s_h (v) + c with v = k + t
    # h(k) = k/a + h0 ; k = v - t  => h = v/a + (h0 - t/a)
    h0 = hk(0); c = h0 - t/a
    dd = sp.nsimplify(d) if P == 'P0' else sp.Rational(str(mp.nstr(d, 40)))  # exact enough for P1 via 40-digit rational
    acoef = F_asym_coeffs(sp.Rational(1) if P == 'P0' else dd, J)
    # expand sum_j a_j (v/a + c)^{3-j} in powers of v: coefficient of v^{3-i}
    cv = [mp.mpf(0)]*J
    for j, aj in enumerate(acoef):
        ajm = mp.mpf(sp.Rational(aj).p)/sp.Rational(aj).q if aj != 0 else 0
        if ajm == 0: continue
        p = 3 - j
        for m in range(0, J):
            i = j + m
            if i >= J: break
            cv[i] += ajm*mp.binomial(p, m)*c**m*(1/a)**(p - m)
    v0 = K + t; tail = mp.mpf(0); pole = mp.mpf(0)
    for i in range(J):
        if i == 4:
            pole = cv[i]; tail += cv[i]*(-mp.digamma(v0) - mp.log(s))
        else:
            tail += cv[i]*mp.zeta(i - 3, v0)
    return head + tail, pole
if __name__ == '__main__':
    AL = [Fr(3, 10), Fr(7071, 10000), Fr(1, 2), Fr(1)]
    out = {}
    for al in AL:
        for P, regs in (('P0', ('Rh', 'Rk', 'Rmu', 'Rnu')), ('P1', ('Rh', 'Rk'))):
            for reg in regs:
                r = {}
                for K, J in ((300, 36), (600, 48)):
                    S = [famsum(al, P, sd, reg, K, J) for sd in ('pos', 'neg')]
                    r[(K, J)] = (S[0][0] + S[1][0], S[0][1] + S[1][1])
                (v1, p1), (v2, p2) = r[(300, 36)], r[(600, 48)]
                tag = f'{al}|{P}|{reg}'
                out[tag] = {'M10_FP': mp.nstr(v2, DPS), 'diff_K300J36_vs_K600J48': mp.nstr(abs(v1 - v2), 3), 'pole': mp.nstr(p2, 30)}
                print(tag, out[tag], flush=True)
    json.dump(out, open(f'/workspace/XVI-O1-CONE/logs/v12/m10_exact_dps{DPS}.json', 'w'), indent=1)
