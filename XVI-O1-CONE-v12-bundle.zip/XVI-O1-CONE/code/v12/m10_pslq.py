"""v12 item (1): PSLQ on the 40-digit M10 values (P0, all regulators) at alpha = 1, 1/2, 3/10, 7071/10000."""
import json, mpmath as mp
mp.mp.dps = 40
M = json.load(open('/workspace/XVI-O1-CONE/logs/v12/m10_exact_dps40.json'))
z3 = mp.zeta(3); pi = mp.pi; L2 = mp.log(2); g = mp.euler; zp1 = mp.zeta(-1, derivative=1); zp3 = mp.zeta(-3, derivative=1)
bases = {'A': (['1', 'zeta3/pi^2', 'zeta3', 'pi^2', 'log2'], [1, z3/pi**2, z3, pi**2, L2]),
         'B': (['1', 'zeta3/pi^2', 'log2', "zeta'(-1)", "zeta'(-3)", 'gamma'], [1, z3/pi**2, L2, zp1, zp3, g]),
         'C': (['1', 'zeta3/pi^2', 'pi^2', 'log2', 'log(alpha)'], None)}
out = {}
for tag, v in M.items():
    if '|P0|' not in tag: continue
    x = mp.mpf(v['M10_FP']); al = mp.mpf(eval(tag.split('|')[0]))
    res = {}
    for bn, (names, vals) in bases.items():
        if vals is None:
            if al == 1: continue
            vals = [1, z3/pi**2, pi**2, L2, mp.log(al)]
        rel = mp.pslq([x] + vals, tol=mp.mpf(10)**-34, maxcoeff=10**6, maxsteps=10**6)
        res[bn] = {'basis': names, 'relation': rel}
    out[tag] = res; print(tag, {b: r['relation'] for b, r in res.items()}, flush=True)
json.dump(out, open('/workspace/XVI-O1-CONE/logs/v12/m10_pslq.json', 'w'), indent=1)
