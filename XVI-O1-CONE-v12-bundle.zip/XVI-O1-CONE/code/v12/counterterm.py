"""v12 item (1): the regulators differ by a computable local counterterm.
For weights w_k = s (k + t):  FP[sum f(k) k^{-eps}] - FP[sum f(k) w_k^{-eps}] = Res_{eps=0} sum f(k) k^{-eps}[log s + log(1+t/k)]
  = c_4 log s + sum_{m=1}^{4} (-1)^{m+1} t^m/m * c_{4-m},     f(k) ~ sum_i c_i k^{3-i}  (exact: only simple poles occur).
Check against the 40-digit values of m10_exact.py."""
import sys, json
sys.path.insert(0, '/workspace/XVI-O1-CONE/code/v12')
from fractions import Fraction as Fr
import mpmath as mp, sympy as sp
import m10_exact as X
mp.mp.dps = 50
def ck(al, P, side, J=12):
    a = mp.mpf(al.numerator)/al.denominator
    hk, d, kmin, regs = X.family(al, P, side); c = hk(0)
    acoef = X.F_asym_coeffs(sp.Integer(1) if P == 'P0' else sp.Rational(str(mp.nstr(d, 40))), J)
    cv = [mp.mpf(0)]*J
    for j, aj in enumerate(acoef):
        if aj == 0: continue
        ajm = mp.mpf(sp.Rational(aj).p)/sp.Rational(aj).q; p = 3 - j
        for m in range(J - j): cv[j+m] += ajm*mp.binomial(p, m)*c**m*(1/a)**(p-m)
    return cv, regs
M = json.load(open('/workspace/XVI-O1-CONE/logs/v12/m10_exact_dps40.json'))
out = {}
for al in [Fr(3, 10), Fr(7071, 10000), Fr(1, 2), Fr(1)]:
    for P, regs in (('P0', ('Rh', 'Rmu', 'Rnu')), ('P1', ('Rh',))):
        for reg in regs:
            D = mp.mpf(0)
            for side in ('pos', 'neg'):
                c, R = ck(al, P, side); s, t = R[reg]
                D += c[4]*mp.log(s) + sum((-1)**(m+1)*t**m/m*c[4-m] for m in range(1, 5))
            num = mp.mpf(M[f'{al}|{P}|Rk']['M10_FP']) - mp.mpf(M[f'{al}|{P}|{reg}']['M10_FP'])
            out[f'{al}|{P}|Rk-{reg}'] = {'formula': mp.nstr(D, 30), 'numeric': mp.nstr(num, 30), 'diff': mp.nstr(abs(D-num), 3)}
            print(al, P, reg, out[f'{al}|{P}|Rk-{reg}'], flush=True)
json.dump(out, open('/workspace/XVI-O1-CONE/logs/v12/counterterm.json', 'w'), indent=1)
