"""v12 item (1): closed form of the scheme-Z mixed r^2 mode functional F(mu,nu) = int_0^1 T_1(x;mu,nu) dx, IDENTIFIED (not derived):
  F = h^3/3 + (d^2/6 - 1/3) h + d^2 (d^2-4) Psi(h),   h=(mu+nu)/2, d=mu-nu,
  Psi(h) = P(h) - h^2(h^2-1) psi_1(h)/48,  P = minus the polynomial part of the large-h expansion of -h^2(h^2-1)psi_1(h)/48.
Steps that led to it: (a) the v11 cache fits give G_d(h) ~ sum a_{2i}(d) h^{3-2i}, odd powers absent; (b) structure_test.py shows
R_d(h)/(d^2(d^2-4)) d-independent to 20 digits at h=3/2,7/2,5 (and R=0 at d=2); (c) PSLQ gives Psi in Q+Q pi^2 at those h;
(d) matching the asymptotic coefficients 1/240,-1/840 fixes Q=-h^2(h^2-1)/48 and predicts 1/840,-1/440 (both confirmed).
This script verifies the closed form against every cached quadrature value (logs/v11/M10/cache, 404 values) and the structure test."""
import json, glob
from fractions import Fraction as Fr
import sympy as sp, mpmath as mp
h = sp.symbols('h', positive=True); x = sp.symbols('x')
Q = -h**2*(h**2-1)/48
# asymptotic psi1(h) ~ 1/h + 1/(2h^2) + sum_{n>=1} B_{2n}/h^{2n+1}
ser = 1/h + 1/(2*h**2) + sum(sp.bernoulli(2*n)/h**(2*n+1) for n in range(1, 4))
P = -sp.Poly(sp.expand(Q*ser*h**10), h).as_expr()
Pp = sum(c*h**(m-10) for (m,), c in sp.Poly(sp.expand(Q*ser*h**10), h).terms() if m >= 10)
P = sp.expand(-Pp)
print('P(h) =', P)
mp.mp.dps = 40
fP = sp.lambdify(h, P, 'mpmath'); fQ = sp.lambdify(h, Q, 'mpmath')
def Psi(hh): return fP(hh) + fQ(hh)*mp.psi(1, hh)
def F(mu, nu):
    mu = mp.mpf(mu); nu = mp.mpf(nu); hh = (mu+nu)/2; d = mu-nu
    return hh**3/3 + (d**2/6 - mp.mpf(1)/3)*hh + d**2*(d**2-4)*Psi(hh)
if __name__ == '__main__':
    worst = 0; worst_rel = 0; n = 0; rows = []
    for f in glob.glob('/workspace/XVI-O1-CONE/logs/v11/M10/cache/*.json'):
        dd = json.load(open(f)); m, nn = Fr(dd['mu']), Fr(dd['nu'])
        a = F(mp.mpf(m.numerator)/m.denominator, mp.mpf(nn.numerator)/nn.denominator); b = mp.mpf(dd['F'])
        e = abs(a-b); worst = max(worst, e); worst_rel = max(worst_rel, e/max(1, abs(b))); n += 1
    st = json.load(open('/workspace/XVI-O1-CONE/logs/v12/structure_test.json'))
    ws = 0
    for k, v in st.items():
        hh, d = map(Fr, k.split('|')); a = F(mp.mpf((hh+d/2).numerator)/(hh+d/2).denominator, mp.mpf((hh-d/2).numerator)/(hh-d/2).denominator)
        ws = max(ws, abs(a - mp.mpf(v['F'])))
    out = {'P': str(P), 'Q': str(Q), 'form': 'F = h^3/3 + (d^2/6-1/3)h + d^2(d^2-4)[P(h) + Q(h) psi1(h)]', 'n_cache': n,
           'max_abs_diff_cache': mp.nstr(worst, 3), 'max_rel_diff_cache': mp.nstr(worst_rel, 3), 'max_abs_diff_structure_test': mp.nstr(ws, 3),
           'asymptotic_check': str(sp.series(P + Q*ser, h, sp.oo, 8))}
    print(out)
    json.dump(out, open('/workspace/XVI-O1-CONE/logs/v12/F_closed.json', 'w'), indent=1)
