"""v12 item (1): test whether R_d(h) = F(h+d/2,h-d/2) - h^3/3 - (d^2/6-1/3) h equals d^2(d^2-4) Psi(h) exactly (d-independent Psi)."""
import sys, json
sys.path.insert(0, '/workspace/XVI-O1-CONE/code/v11')
from fractions import Fraction as Fr
import mpmath as mp
import m10_eval as E
mp.mp.dps = 30
out = {}
for h in [Fr(5), Fr(7, 2), Fr(3, 2)]:
    for d in [Fr(1), Fr(2), Fr(3), Fr(1, 2)]:
        mu, nu = h + d/2, h - d/2
        if nu < 0: continue
        F = E.F(mu, nu); hh = mp.mpf(h.numerator)/h.denominator; dd = mp.mpf(d.numerator)/d.denominator
        R = F - hh**3/3 - (dd**2/6 - mp.mpf(1)/3)*hh
        P = R/(dd**2*(dd**2-4)) if d != 2 else None
        out[f'{h}|{d}'] = {'F': mp.nstr(F, 25), 'R': mp.nstr(R, 20), 'Psi': mp.nstr(P, 20) if P is not None else 'd=2'}
        print(h, d, out[f'{h}|{d}'], flush=True)
json.dump(out, open('/workspace/XVI-O1-CONE/logs/v12/structure_test.json', 'w'), indent=1)
