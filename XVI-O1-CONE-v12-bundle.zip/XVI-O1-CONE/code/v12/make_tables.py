"""v12: LaTeX tables from logs (M10 40-digit values, counterterms, wall certificates)."""
import json, glob, os
from fractions import Fraction as Fr
R = '/workspace/XVI-O1-CONE/'
M = json.load(open(R + 'logs/v12/m10_exact_dps40.json'))
rows = []
for tag in sorted(M, key=lambda t: (Fr(t.split('|')[0]), t.split('|')[1], t.split('|')[2])):
    al, P, reg = tag.split('|'); v = M[tag]
    regt = {'Rh': 'R_h', 'Rk': 'R_k', 'Rmu': r'R_\mu', 'Rnu': r'R_\nu'}[reg]
    val = v['M10_FP']; val = val[:34] if not val.startswith('-') else val[:35]
    pole = v['pole']; pole = pole if len(pole) < 14 else pole[:14] + r'\ldots'
    rows.append(r'\(%s\) & %s & \(%s\) & \(%s\) & \(%s\)\\' % (al, P, regt, val, pole))
open(R + 'v12src/m10_table.tex', 'w').write('\n'.join(rows) + '\n')
W = []
for f in sorted(glob.glob(R + 'logs/v12/walls/apex_cert_*_[CF]*.json')):
    if 'vectors' in f: continue
    d = json.load(open(f))
    W.append(r'\(%s\) & %s & %d & %d & %d & %d & %d & %.0f\\' % (d['alpha'], d['branch'], d['N_total'], d['Ward_constrained_count'],
             d['N_total'] - d['Ward_constrained_count'], d.get('basis_rank_on_image_columns', -1), d.get('H0_dim', -1), d['seconds']))
open(R + 'v12src/walls_table.tex', 'w').write('\n'.join(W) + '\n')
print(len(rows), len(W))
