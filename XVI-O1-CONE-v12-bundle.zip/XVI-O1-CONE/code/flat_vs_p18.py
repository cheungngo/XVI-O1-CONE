"""v6: validation of the flat 4D pole route (flat_pole.py) against the frozen XVI-P certificate P18_D11 (read-only):
the full lattice array must be proportional (one overall constant) to the 4D (non-evanescent) covariant P18 tensor."""
import json, itertools, sympy as sp
q0, q3, ka = sp.symbols('q0 q3 kappa')
d = json.load(open('/tmp/o1cone_ro/XVI-Q/provenance/XVI-P/certificates/P18_D11.json'))['result']
c = {k: sp.sympify(v['UV_pole']) for k, v in d.items() if not v['evanescent']}
ETA = [1, -1, -1, -1]; HC = [(0,0),(0,1),(0,2),(0,3),(1,1),(1,2),(1,3),(2,2),(2,3),(3,3)]
pl = [q0, 0, 0, q3]
def T(m, n, r, s, sym, up):
    g = lambda a, b: (ETA[a] if a == b else 0)
    p = (lambda a: ETA[a]*pl[a]) if up else (lambda a: pl[a])
    pp = q0**2 - q3**2
    def S2(f): return (f(m, n, r, s) + f(n, m, r, s)) / 2 if sym else f(m, n, r, s)
    v = c['g4_mn g4_rs (p.p)^2'] * g(m, n) * g(r, s) * pp**2
    v += c['g4_mr g4_ns (p.p)^2'] * S2(lambda m, n, r, s: g(m, r) * g(n, s)) * pp**2 * (2 if sym else 1)
    v += c['g4_mn p_r p_s (p.p)^1'] * g(m, n) * p(r) * p(s) * pp + c['g4_rs p_m p_n (p.p)^1'] * g(r, s) * p(m) * p(n) * pp
    v += c['g4_mr p_n p_s (p.p)^1'] * S2(lambda m, n, r, s: (g(m, r) * p(n) * p(s) + g(n, s) * p(m) * p(r)) / 2) * pp * (2 if sym else 1)
    v += c['p_m p_n p_r p_s'] * p(m) * p(n) * p(r) * p(s)
    return sp.expand(v)
mine = {eval(k): sp.sympify(v) for k, v in json.load(open('/workspace/XVI-O1-CONE/logs/v6/flat_D11.json'))['Gamma_pole_coeff_of_1/(4-d)'].items()}
LAT = [0, 3, 9, 4, 7]
best = None
for sym, up, w in itertools.product([True, False], [True, False], [1, 2]):
    K = None; ok = True
    for a in LAT:
        for b in LAT:
            m, n = HC[a]; r, s = HC[b]
            wt = (w if m != n else 1) * (w if r != s else 1)
            t = T(m, n, r, s, sym, up) * wt; v = mine.get((a, b), 0)
            if t == 0 and v == 0: continue
            if t == 0 or v == 0: ok = False; break
            ratio = sp.simplify(v / t)
            if K is None: K = ratio
            elif sp.simplify(ratio - K) != 0: ok = False; break
        if not ok: break
    print('sym', sym, 'up', up, 'offdiag w', w, '->', 'PROPORTIONAL, K =' if ok else 'no', K if ok else '')
    if ok: best = (sym, up, w, str(K))
json.dump({'match': best}, open('/workspace/XVI-O1-CONE/logs/v6/flat_vs_p18.json', 'w'), indent=1)
# general fully-symmetrised ansatz fit (normalisation-free ratio comparison)
A = sp.symbols('A1:6')
def Tg(m, n, r, s, up, A):
    g = lambda a, b: (ETA[a] if a == b else 0)
    p = (lambda a: ETA[a]*pl[a]) if up else (lambda a: pl[a]); pp = q0**2 - q3**2
    return (A[0]*g(m,n)*g(r,s)*pp**2 + A[1]*(g(m,r)*g(n,s)+g(m,s)*g(n,r))*pp**2 + A[2]*(g(m,n)*p(r)*p(s)+g(r,s)*p(m)*p(n))*pp
            + A[3]*(g(m,r)*p(n)*p(s)+g(m,s)*p(n)*p(r)+g(n,r)*p(m)*p(s)+g(n,s)*p(m)*p(r))*pp + A[4]*p(m)*p(n)*p(r)*p(s))
res = {}
for up, w in itertools.product([True, False], [1, 2, sp.Rational(1, 2)]):
    eqs = []
    for a in LAT:
        for b in LAT:
            m, n = HC[a]; r, s = HC[b]
            wt = (w if m != n else 1) * (w if r != s else 1)
            eqs += sp.Poly(sp.expand(Tg(m, n, r, s, up, A) * wt - mine.get((a, b), 0)), q0, q3).coeffs()
    sol = sp.solve(eqs, A, dict=True)
    if sol:
        s0 = sol[0]; norm = s0[A[1]]
        rat = [sp.nsimplify(s0[x] / norm) for x in A]
        print('up', up, 'w', w, 'fit ratios A/A2 =', rat, ' (P18 ratios a/a2 = [6, 1, -6, -1, 8])')
        res[f'up={up},w={w}'] = [str(x) for x in rat]
json.dump({'match': best, 'ansatz_fits': res, 'P18_ratios_over_a2': [6, 1, -6, -1, 8]}, open('/workspace/XVI-O1-CONE/logs/v6/flat_vs_p18.json', 'w'), indent=1)
