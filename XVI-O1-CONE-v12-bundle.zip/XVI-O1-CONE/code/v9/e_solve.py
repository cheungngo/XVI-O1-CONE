"""v9 item (3): solve sum_i e_i pi_K(B_i) = y_K on ALL constant-profile K coordinates (HH from v8 hh_map, CB/CK from
cbck_map/ck_free), with ghost-sector normalisations lambda_CB, lambda_CK fitted ONCE (alpha-independent) and then checked.
Output: residual Ward values, the solution set for e (kernel direction), closed-form comparisons."""
import json, sys
import sympy as sp
from fractions import Fraction as Fr
out = {}
lCB, lCK = -4*sp.I, sp.Integer(-8)
def cx(p): return sp.Rational(p[0]) + sp.I*sp.Rational(p[1])
for t, a_s, br in [('3_10_CR', '3/10', 'CR'), ('3_10_F', '3/10', 'F'), ('7071_10000_CR', '7071/10000', 'CR'), ('7071_10000_F', '7071/10000', 'F')]:
    a = sp.Rational(a_s)
    v = json.load(open(f'logs/v8/cert/apex_cert_{t}_vectors.json')); c = json.load(open(f'logs/v8/cert/apex_cert_{t}.json'))
    K = v['K']; lab = c['basis_labels']
    hh = json.load(open(f'logs/v8/cert/hh_map_{t}.json'))['hh_sum']['engine_HH_K_coords']
    cb = json.load(open(f'logs/v9/cbck_map_{t}.json')); cby = [r['y'] for r in cb['CB']['results'] if r['exact']][0]
    ck = json.load(open(f'logs/v9/ck_free_{t}.json')); cks = [o['solutions'][0] for o in ck['out'] if o['solutions']][0]
    y = {}
    hhK = [k for k in K if lab[k][0] == 'HH']
    for k, val in zip(hhK, hh): y[k] = sp.Rational(val)
    for k, val in zip(cb['CB']['K'], cby): y[k] = lCB*sp.sympify(val)*sp.pi
    for j, k in enumerate(ck['K']): y[k] = lCK*sp.sympify(cks[f'y{j}'])
    pp = [k for k in K if lab[k][0] == 'PP']
    e = sp.symbols('e1:%d' % (len(v['B_coords']) + 1)); ph = sp.Symbol('phiK')
    eqs = []
    for k in K:
        rhs = y.get(k, None)
        lhs = sum(e[i]*cx(b[k]) for i, b in enumerate(v['B_coords']))
        if k in pp: continue   # PP coordinate: B has no PP component (checked)
        eqs.append(sp.expand(lhs - rhs))
    assert all(cx(b[k]) == 0 for b in v['B_coords'] for k in pp)
    sol = sp.solve(eqs, e, dict=True)
    W = [sum(cx(w[i])*y[k] for i, k in enumerate(K) if k in y) for w in v['AnnK_basis']]
    z0 = (1-a*a)/(12*a); z1 = (5*a*a-6*a+1)/(12*a); R = 3*z0+4*z1
    s = sol[0] if sol else {}
    out[t] = {'consistent': bool(sol), 'Ward_residuals_with_fitted_lambdas': [str(sp.simplify(w)) for w in W],
              'solution': {str(k): str(sp.simplify(val)) for k, val in s.items()},
              'free': [str(x) for x in e if x not in s],
              'check_e1': sp.simplify(s.get(e[0], e[0]) - (1-a)/4) == 0 if s else None,
              'check_e6_minus_e2': (sp.simplify(s.get(e[5], e[5]) - s.get(e[1], e[1]) + R/2) == 0) if s else None}
    print(t, out[t])
json.dump({'lambda_CB': str(lCB), 'lambda_CK': str(lCK), 'points': out}, open('logs/v9/e_solve.json', 'w'), indent=1, default=str)
