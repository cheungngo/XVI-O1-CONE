"""v9 item (3): CB and CK constant-profile dictionaries, the six K-supported Ward combinations on the full
constant-profile catalogue, and the exact values e_1..e_6 from all twelve K coordinates.
Dictionary search (declared): Euclidean longitudinal (tau,z) <-> Lorentzian (0,3), x^0=-i tau, q0=si*i*q_tau, q3=q_z.
 vector field F in {cb,c}: comp0 = sF*i*L_tau, comp3 = L_z              (sF = +-1 tried)
 K (antifield of h):       00 = tK*(-LL_tt), 03 = si*i*LL_tz, 33 = LL_zz, f = PM/2  (tK = +-1 tried)
Catalogue: D06 = <cb c> (keys (a,b), a: cb index, b: c index), D13 = <K c> (a: HH index, b: c index).
Engine symmetrisation: eval_sym with reflection only (bose=False) => Gamma_sym = 2*Gamma for CB, CK.
A dictionary is accepted iff the catalogue bilinear lies EXACTLY in the span of the K-candidate evaluations on all
complete m=0 columns.  usage: cbck_map.py alpha branch"""
import sys, json, itertools
from fractions import Fraction as Fr
sys.path.insert(0, '/workspace/XVI-O1-CONE/code/v8')
import sympy as sp
import apex_exact as AJ
from gq import GQ
from cone_v7 import catalogue, physical_cs, alpha as AL, kappa, q0, q3
a_s, br = sys.argv[1], sys.argv[2]
alpha = Fr(a_s); S = AJ.Setup(alpha, br); tag = f"{a_s.replace('/', '_')}_{br}"
cert = json.load(open(f'logs/v8/cert/apex_cert_{tag}.json')); vec = json.load(open(f'logs/v8/cert/apex_cert_{tag}_vectors.json'))
lab = cert['basis_labels']; K = vec['K']
def g2s(v):
    v = GQ.c(v); return sp.Rational(v.re.numerator, v.re.denominator) + sp.I*sp.Rational(v.im.numerator, v.im.denominator)
def cfg(C, v): return {C: {(0, Fr(0)): [GQ(t) for t in v]}}
VAT = [('L', [1, 0]), ('L', [0, 1])]
TAT = [('LL', [1, 0, 0, 0]), ('LL', [0, 1, 1, 0]), ('LL', [0, 0, 0, 1]), ('PM', [1])]
QG = [(a, b) for a in range(1, 7) for b in range(1, 7)]
cs = tuple(sp.simplify(c.subs(AL, sp.Rational(alpha.numerator, alpha.denominator))) for c in physical_cs(br))
cat = catalogue(cs)
def vlor(at, s, si):   # vector Lorentzian components {0: , 3: }
    v = at[1]; return {0: s*sp.I*v[0], 3: v[1], 1: 0, 2: 0}
def tlor(at, t, si):
    C, v = at
    if C == 'PM': return {0: 0, 3: 0, 9: 0, 4: sp.Rational(1, 2)*v[0], 7: sp.Rational(1, 2)*v[0]}
    return {0: -t*v[0], 3: si*sp.I*v[1], 9: v[3], 4: 0, 7: 0}
def solve_sector(name, F1, F2, A1, A2, catd, lor1, lor2, signs):
    piv = cert['gh0'][name]['pivot_candidates']; cands = AJ.candidates(S, F1, F2, 4); basis = [cands[i] for i in piv]
    Ks = [k for k in K if lab[k][0] == name]; ib = [lab[k][1] for k in Ks]
    results = []
    for sg in signs:
        si = sg[0]
        E = []; rhs = []
        for A in A1:
            for B in A2:
                for (qa, qb) in QG:
                    q = [GQ(qa), GQ(qb)]
                    E.append([g2s(AJ.eval_sym(basis[i], cfg(*A), cfg(*B), q, False)) for i in ib])
                    l1, l2 = lor1(A, sg), lor2(B, sg)
                    val = sum(v*l1.get(a, 0)*l2.get(b, 0) for (a, b), v in catd.items())
                    rhs.append(sp.expand(2*val.subs({q0: si*sp.I*qa, q3: qb})/kappa**2))
        Em = sp.Matrix(E); r = sp.Matrix(rhs)
        try:
            sol = Em.solve_least_squares(r) if Em.rank() == Em.cols else None
        except Exception:
            sol = None
        ok = sol is not None and all(sp.simplify(e) == 0 for e in (Em*sol - r))
        results.append({'signs': sg, 'exact': bool(ok), 'y': [str(sp.nsimplify(sp.simplify(t))) for t in sol] if ok else None})
    return Ks, results
out = {'alpha': a_s, 'branch': br, 'units': 'kappa^2; engine K coordinates, Gamma_sym=2*Gamma (CB,CK)'}
KCB, rcb = solve_sector('CB', 'cb', 'c', VAT, VAT, cat['D06'], lambda A, sg: vlor(A, sg[1], sg[0]), lambda A, sg: vlor(A, sg[2], sg[0]),
                        list(itertools.product((1, -1), repeat=3)))
KCK, rck = solve_sector('CK', 'K', 'c', TAT, VAT, cat['D13'], lambda A, sg: tlor(A, sg[1], sg[0]), lambda A, sg: vlor(A, sg[2], sg[0]),
                        list(itertools.product((1, -1), repeat=3)))
out['CB'] = {'K': KCB, 'results': rcb}; out['CK'] = {'K': KCK, 'results': rck}
print(json.dumps(out, indent=1)[:3000])
json.dump(out, open(f'logs/v9/cbck_map_{tag}.json', 'w'), indent=1)
