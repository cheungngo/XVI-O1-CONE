"""Check the closed form for the per-mode r^{-2}-sandwiched mixed heat trace
g(x;mu,nu)=Tr[e^{-(1-x)A_mu} r^{-2} e^{-x A_nu}]
 = G(h)G(h+1)/(4G(mu+1)G(nu+1)) 2F1(d/2+1,d/2;mu+1;x) 2F1(1-d/2,-d/2;nu+1;1-x),  d=mu-nu, h=(mu+nu)/2
against direct quadrature, and int_0^1 g = 1/(2(mu+nu))."""
import mpmath as mp, json, sys
from scipy import integrate, special
import numpy as np
def g_closed(x, mu, nu, dps=30):
    mp.mp.dps = dps
    d = mu - nu; h = (mu + nu) / 2
    return mp.gamma(h)*mp.gamma(h+1)/(4*mp.gamma(mu+1)*mp.gamma(nu+1))*mp.hyp2f1(d/2+1, d/2, mu+1, x)*mp.hyp2f1(1-d/2, -d/2, nu+1, 1-x)
def g_quad(x, mu, nu):
    a, b = 1-x, x
    def K(t, r, rp, o):
        z = r*rp/(2*t)
        return np.exp(-(r-rp)**2/(4*t))*special.ive(o, z)/(2*t)
    f = lambda rp, r: (1/r)*rp*K(a, r, rp, mu)*K(b, rp, r, nu)
    val, err = integrate.dblquad(f, 1e-9, 60, lambda r: 0, lambda r: 60, epsabs=1e-11, epsrel=1e-9)
    return val, err
out = []
for (mu, nu, x) in [(1.3, 0.6, 0.3), (0.7, 2.2, 0.55), (2.5, 0.5, 0.8), (1.0, 1.0, 0.4), (3.2, 1.2, 0.5), (-0.4, 1.4, 0.35)]:
    q, e = g_quad(x, mu, nu); c = g_closed(x, mu, nu)
    I = mp.quad(lambda t: g_closed(t, mu, nu), [0, 0.5, 1])
    out.append(dict(mu=mu, nu=nu, x=x, quad=q, quad_err=e, closed=float(c), int_closed=float(I), int_pred=1/(2*(mu+nu))))
    print(out[-1], flush=True)
json.dump(out, open('logs/v9/g_formula_check.json', 'w'), indent=1)
