"""v9 item (8): chamber structure of the apex inventory.  For each rational alpha in a grid, record the candidate
signature (counts and jet labels of every gh0 sector at T=4 and gh-1 sector at T=3).  alpha where the signature differs
from its neighbours are walls; between walls the entries of all ST rows are rational functions of alpha (same jets,
same pairings), so a nonzero minor at one exact point certifies generic rank over Q(alpha) in that chamber.
Resumable (per-alpha cache)."""
import sys, os, json, hashlib
from fractions import Fraction as Fr
sys.path.insert(0, '/workspace/XVI-O1-CONE/code/v8')
import apex_exact as AJ
SECT = {'HH': ('h', 'h', 4), 'CB': ('cb', 'c', 4), 'CK': ('K', 'c', 4), 'PP': ('phi', 'phi', 4),
        'X1': ('h', 'cb', 3), 'X2': ('h', 'K', 3), 'X3': ('cs', 'c', 3)}
cache = 'logs/v9/chamber_cache2.json'
C = json.load(open(cache)) if os.path.exists(cache) else {}
def jk(S, F, jet):   # alpha-free structural key of a jet: (C, n, eps, j, sign(n/alpha+s))
    C, n, m = jet; comps, dim, kind = AJ.FIELDS[F]; sw = comps[C][0]
    a = S.a(sw, n); e = S.eps(kind, sw, n); j = (m - e*abs(a))/2
    return (C, n, e, str(j), (a > 0) - (a < 0))
def sig(a, br):
    S = AJ.Setup(a, br); out = {}
    for nm, (F1, F2, T) in SECT.items():
        try:
            cs = AJ.candidates(S, F1, F2, T)
        except KeyError:
            out[nm] = None; continue
        out[nm] = sorted(set((jk(S, F1, c[0]), jk(S, F2, c[1]), c[4]) for c in cs))
    return out
grid = sorted({Fr(p, q) for q in range(2, 41) for p in range(1, q) if Fr(1, 4) < Fr(p, q) < 1} | {Fr(7071, 10000), Fr(8501, 10000), Fr(309, 500), Fr(41, 100), Fr(3, 10)})
for i, a in enumerate(grid):
    for br in ('CR', 'F'):
        k = f'{a}|{br}'
        if k in C: continue
        s = sig(a, br); C[k] = {'n': {nm: (len(v) if v is not None else None) for nm, v in s.items()}, 'h': hashlib.sha256(json.dumps(s, sort_keys=True).encode()).hexdigest()[:16]}
    if i % 20 == 0:
        json.dump(C, open(cache + '.tmp', 'w')); os.replace(cache + '.tmp', cache); print(i, len(grid), flush=True)
json.dump(C, open(cache + '.tmp', 'w')); os.replace(cache + '.tmp', cache); print('done', flush=True)
