"""v9 item (6): compare the v8 evanescent pole coefficients with the frozen engine's admitted pattern (XVI-P
code/p5_entry/dred.py eta_trace_Gt, read-only copy): only c*sum_r eta^{rr} Gt_rr (full 4D trace, -> c(4-d)) is admitted.
Test per key: (a) nonlinear Gt monomials present?  (b) linear part of longitudinal-partial-trace form c*(Gt00 - Gt33)?"""
import json, sympy as sp
d = json.load(open('logs/v8/slice/evanescent_combined.json'))
G = sp.symbols('Gt00 Gt03 Gt33'); out = {}
for gname, blk in d.items():
    if not isinstance(blk, dict) or 'evanescent_pole_coefficients' not in blk: continue
    for key, ex in blk['evanescent_pole_coefficients'].items():
        e = sp.expand(sp.sympify(ex))
        P = sp.Poly(e, *G); nonlin = any(sum(m) >= 2 for m in P.monoms()); 
        lin = {str(g): sp.factor(P.coeff_monomial(g)) for g in G}
        partial = sp.simplify(lin['Gt00'] + lin['Gt33']) == 0 and lin['Gt03'] == 0
        out[f'{gname}{key}'] = {'nonlinear_Gt_monomials': nonlin, 'max_Gt_degree': max(sum(m) for m in P.monoms()),
                                'linear_part': {k: str(v) for k, v in lin.items()}, 'linear_is_partial_trace_form': bool(partial)}
summary = {'n_keys': len(out), 'keys_with_nonlinear_Gt': sum(v['nonlinear_Gt_monomials'] for v in out.values()),
           'keys_linear_partial_trace': sum(v['linear_is_partial_trace_form'] for v in out.values())}
json.dump({'summary': summary, 'keys': out}, open('logs/v9/evan_match.json', 'w'), indent=1); print(summary)
for k, v in list(out.items())[:6]: print(k, v['max_Gt_degree'], v['linear_is_partial_trace_form'], v['linear_part'])
