"""v9 item (7): IR-log coefficient of every hidden mixed key (D01, D03 slice data, logs/v8/slice/hidden_mixed.json).
Per pair (s,t), the same-k mode sum of C_{s,t}(x) carries (alpha (s-t)^2/2) x(x-1) log Lambda (v9 asymptotics, a1+b1=1/15
for (0,2)).  L_key = sum_pairs (s-t)^2 int_0^1 rho_(s,t)(x) x(x-1) dx; the key is IR-log free iff L_key = 0 (summed over graphs)."""
import json, sympy as sp
x, q0, q3 = sp.symbols('x q0 q3'); I = sp.I; pi = sp.pi
d = json.load(open('logs/v8/slice/hidden_mixed.json'))
out = {}; tot = {}
for g, keys in d.items():
    for key, pairs in keys.items():
        L = 0
        for st, rho in pairs:
            s, t = eval(st); r = sp.sympify(rho, locals={'x': x, 'q0': q0, 'q3': q3, 'I': I, 'pi': pi})
            L += (s-t)**2*sp.integrate(r*x*(x-1), (x, 0, 1))
        L = sp.factor(sp.simplify(L)); out[f'{g}{key}'] = str(L); tot[key] = sp.simplify(tot.get(key, 0) + L)
res = {'per_graph_key': out, 'summed_over_graphs': {k: str(sp.factor(v)) for k, v in tot.items()}}
res['log_free_keys'] = [k for k, v in tot.items() if v == 0]; res['log_carrying_keys'] = [k for k, v in tot.items() if v != 0]
json.dump(res, open('logs/v9/vector_logs.json', 'w'), indent=1); print(json.dumps(res, indent=1))
