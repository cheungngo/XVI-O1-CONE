"""v9 item (1): finite, regularisation-independent CR-F branch difference of the hidden TT pair functional
DeltaJ(alpha) = J_CR - J_F = I(1/a, 1/a-2) - I(1/a, 2-1/a)   (only the S=2, k=-1 mode differs).
Resumable: one JSON per alpha in logs/v9/hidden/.  Cross-check: I_minus (series) vs I_gen (closed-form quadrature)."""
import sys, os, json
sys.path.insert(0, os.path.dirname(__file__))
import mpmath as mp
from modefun import I_minus, I_gen
mp.mp.dps = 30
AL = ['7/20', '2/5', '9/20', '1/2', '11/20', '3/5', '2/3', '7071/10000', '3/4', '4/5', '17/20', '9/10', '19/20', '99/100']
for a_s in AL:
    fn = f"logs/v9/hidden/dJ_{a_s.replace('/', '_')}.json"
    if os.path.exists(fn): continue
    p, q = map(int, a_s.split('/')); a = mp.mpf(p)/q; mu = 1/a
    cr_series = I_minus(mu); cr_quad = I_gen(mu, mu-2); f = I_gen(mu, 2-mu)
    r = {'alpha': a_s, 'nu0': mp.nstr(2-mu, 20), 'J_CR_mode_series': mp.nstr(cr_series, 25), 'J_CR_mode_quad': mp.nstr(cr_quad, 25),
         'J_F_mode_quad': mp.nstr(f, 25), 'DeltaJ': mp.nstr(cr_series-f, 25), 'series_vs_quad': mp.nstr(abs(cr_series-cr_quad), 5),
         'catalogue_TT_coefficient_difference': f'-kappa^2 P^2 DeltaJ/(8 pi) on the TT bilinear [(h11-h22)(h11-h22)+4h12h12]'}
    json.dump(r, open(fn + '.tmp', 'w'), indent=1); os.replace(fn + '.tmp', fn); print(r, flush=True)
