#!/bin/bash
# v9 item (8): modular (p0, randomized) ST rank scan over all rationals p/q in (1/4,1), q<=20, both branches. Resumable.
cd /workspace/XVI-O1-CONE
for a in $(tac logs/v9/scan/alphas.txt); do for br in CR F; do
  f=logs/v9/scan/apex_${a/\//_}_${br}_p0.json
  [ -s "$f" ] && continue
  timeout 600 python3 code/v9/apex_scan.py $a $br 0 > logs/v9/scan/run_${a/\//_}_${br}.log 2>&1 || echo "FAIL $a $br" >> logs/v9/scan/fail.txt
done; done
echo ALLDONE_REV >> logs/v9/scan/driver.log
