#!/bin/bash
# v9 item (8): modular (p0, randomized) ST rank scan over all rationals p/q in (1/4,1), q<=20, both branches. Resumable.
cd /workspace/XVI-O1-CONE
python3 - <<'PY' > logs/v9/scan/alphas.txt
from fractions import Fraction as Fr
print("\n".join(str(a) for a in sorted({Fr(p,q) for q in range(2,21) for p in range(1,q) if Fr(1,4)<Fr(p,q)<1})))
PY
for a in $(cat logs/v9/scan/alphas.txt); do for br in CR F; do
  f=logs/v9/scan/apex_${a/\//_}_${br}_p0.json
  [ -s "$f" ] && continue
  timeout 600 python3 code/v9/apex_scan.py $a $br 0 > logs/v9/scan/run_${a/\//_}_${br}.log 2>&1 || echo "FAIL $a $br" >> logs/v9/scan/fail.txt
done; done
echo ALLDONE >> logs/v9/scan/driver.log
