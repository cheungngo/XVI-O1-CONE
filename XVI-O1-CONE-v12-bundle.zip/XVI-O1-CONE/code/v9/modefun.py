"""Fast exact-series evaluation of the per-mode hidden-pair functional for delta=mu-nu=+-2 (Euler-Maclaurin nsum),
plus the general-order quadrature of the closed form."""
import mpmath as mp
def Jfun(n):  # int_0^1 R(x)(1-x)^n dx, R=2x^3-5x^2+3x
    return 12*mp.gamma(n+1)/mp.gamma(n+5) - 10*mp.gamma(n+1)/mp.gamma(n+4) + 3*mp.gamma(n+1)/mp.gamma(n+3)
def Kfun(n):  # int_0^1 R(x) x^n dx
    return 2/(n+4) - 5/(n+3) + 3/(n+2)
def S(c, L):
    lgc = mp.loggamma(c)
    return mp.nsum(lambda n: mp.exp(mp.loggamma(n+2)+lgc-mp.loggamma(c+n))*L(n), [0, mp.inf], method='euler-maclaurin')
def I_plus(mu): return (mu+1)/(mu+2)*S(mu+3, Jfun)     # nu = mu+2
def I_minus(mu): return -(mu-1)/mu*S(mu+1, Kfun)       # nu = mu-2
def g(t, mu, nu):
    d = mu-nu; h = (mu+nu)/2
    return mp.gamma(h)*mp.gamma(h+1)/(4*mp.gamma(mu+1)*mp.gamma(nu+1))*mp.hyp2f1(d/2+1, d/2, mu+1, t)*mp.hyp2f1(1-d/2, -d/2, nu+1, 1-t)
def I_gen(mu, nu):
    return -(mu**2-nu**2)*mp.quad(lambda t: (2*t**3-5*t**2+3*t)*g(t, mu, nu), [0, mp.mpf(1)/4, mp.mpf(1)/2, mp.mpf(3)/4, 1])
# I_F (incomplete-beta 'reduction') REMOVED in v9: algebra error x^{1-mu} vs x^{mu-1}; use I_gen.
