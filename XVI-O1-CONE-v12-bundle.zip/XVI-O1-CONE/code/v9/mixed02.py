"""v9 item (1): hidden mixed-channel (0,2) pairs of D01.
Per angular mode: f(x;mu,nu)=Tr[e^{-(1-x)A_mu} e^{-x A_nu}] (apex constant irrelevant since int rho=0),
I(mu,nu)=int_0^1 rho(x) f dx = -(mu^2-nu^2) int_0^1 R(x) g(x) dx, rho=6x^2-10x+3, R=2x^3-5x^2+3x,
g = closed form (Appell F4 -> product of 2F1; verified in g_formula_check.py).
Modes of C_{0,2}: S=0 orders |k|/alpha; S=+2 orders |k/alpha+2|, except k=-1: sigma*nu0, nu0=2-1/alpha,
sigma=-1 (CR), +1 (F)  [engine labels lab(S) in spectral_apex.py: CR beta=2alpha, F beta=2alpha-1].
Mode sum zeta-regularised in k (Hurwitz); the 1/k pole residue is reported."""
import mpmath as mp, sympy as sp, json, sys
mp.mp.dps = 40
x = sp.Symbol('x')
Rpoly = 2*x**3 - 5*x**2 + 3*x
def Jn(n): return sp.integrate(sp.expand(Rpoly*(1-x)**n), (x, 0, 1))
def Kn(n): return sp.integrate(sp.expand(Rpoly*x**n), (x, 0, 1))
def Q(r): r = sp.Rational(r); return mp.mpf(r.p)/r.q
NMAX = 3000
def Jf(n): return Q(sp.Rational(12, 1)*0) if False else None
# closed forms of J_n, K_n via Beta integrals (exact rationals), fast
def beta_int(a, n): return mp.factorial(a)*mp.factorial(n)/mp.factorial(a+n+1)
Jl = [2*beta_int(3, n)-5*beta_int(2, n)+3*beta_int(1, n) for n in range(NMAX)]   # int R (1-x)^n
Kl = [2/mp.mpf(n+4)-5/mp.mpf(n+3)+3/mp.mpf(n+2) for n in range(NMAX)]           # int R x^n
def ser(c, L):
    s = mp.mpf(0); t = mp.mpf(1)
    for n in range(NMAX):
        s += t*L[n]
        t *= mp.mpf(n+2)/(c+n)
        if n > 30 and abs(t*L[n]) < mp.mpf(10)**(-42): break
    else:
        raise RuntimeError('series not converged c=%s' % c)
    return s
def serJ(c):   # sum_n (n+1)!/(c)_n * J_n, J_n = 2*3!n!/(n+4)! - 5*2!n!/(n+3)! + 3*1!n!/(n+2)!
    return sum(co*mp.factorial(a)/mp.factorial(a)*mp.hyper([2, 1, 1], [c, a+2], 1)/mp.factorial(a+1)*mp.factorial(a) for co, a in ((2, 3), (-5, 2), (3, 1)))
def serK(c):   # sum_n (n+1)!/(c)_n * K_n, K_n = 2/(n+4)-5/(n+3)+3/(n+2)
    return sum(co*mp.hyper([2, a, 1], [c, a+1], 1)/a for co, a in ((2, 4), (-5, 3), (3, 2)))
def I_plus(mu): return (mu+1)/(mu+2)*serJ(mu+3)      # nu = mu+2
def I_minus(mu): return -(mu-1)/mu*serK(mu+1)        # nu = mu-2
def g(t, mu, nu):
    d = mu-nu; h = (mu+nu)/2
    return mp.gamma(h)*mp.gamma(h+1)/(4*mp.gamma(mu+1)*mp.gamma(nu+1))*mp.hyp2f1(d/2+1, d/2, mu+1, t)*mp.hyp2f1(1-d/2, -d/2, nu+1, 1-t)
def I_gen(mu, nu):
    return -(mu**2-nu**2)*mp.quad(lambda t: (2*t**3-5*t**2+3*t)*g(t, mu, nu), [0, mp.mpf(1)/4, mp.mpf(1)/2, mp.mpf(3)/4, 1])
P = 10
def asym(kind):
    e = sp.Symbol('e')
    if kind == 'plus':
        pref = (1+e)/(1+2*e)
        terms = sum(sp.factorial(n+1)*sp.integrate(sp.expand(Rpoly*(1-x)**n), (x, 0, 1))*sp.prod([e/(1+(3+j)*e) for j in range(n)]) for n in range(P+1))
    else:
        pref = -(1-e)
        terms = sum(sp.factorial(n+1)*sp.integrate(sp.expand(Rpoly*x**n), (x, 0, 1))*sp.prod([e/(1+(1+j)*e) for j in range(n)]) for n in range(P+1))
    s = sp.series(pref*terms, e, 0, P+1).removeO()
    return [sp.nsimplify(s.coeff(e, j)) for j in range(P+1)]
AP, AM = asym('plus'), asym('minus')
def regsum(F, coeffs, alpha, k0):
    cf = [Q(c) for c in coeffs]
    def sub(k):
        mu = mp.mpf(k)/alpha
        return F(mu) - sum(cf[j]*mu**(-j) for j in range(len(cf)))
    S = mp.nsum(sub, [k0, mp.inf])
    fin = cf[0]*mp.zeta(0, k0) + cf[1]*alpha*(-mp.digamma(k0))
    for j in range(2, len(cf)): fin += cf[j]*alpha**j*mp.zeta(j, k0)
    return S+fin, cf[1]*alpha
def J_total(alpha, sigma):
    nu0 = 2-1/alpha
    sp_, rp = regsum(I_plus, AP, alpha, 1)
    sm_, rm = regsum(I_minus, AM, alpha, 2)
    k0 = I_plus(mp.mpf(0)); km1 = I_gen(1/alpha, sigma*nu0)
    return dict(sum_plus=sp_, sum_minus=sm_, k0=k0, km1=km1, pole_residue=rp+rm, total=sp_+sm_+k0+km1)
if __name__ == '__main__':
    print('asym plus', AP[:4], 'minus', AM[:4], flush=True)
    out = {'asym_plus': [str(a) for a in AP], 'asym_minus': [str(a) for a in AM], 'points': {}}
    for a in (sys.argv[1:] or ['3/10', '2/5', '1/2', '3/5', '7071/10000', '4/5', '9/10']):
        al = Q(a); rec = {}
        for br, sg in (('CR', -1), ('F', 1)):
            r = J_total(al, sg); rec[br] = {k: mp.nstr(v, 30) for k, v in r.items()}
        rec['DeltaJ_CR_minus_F'] = mp.nstr(mp.mpf(rec['CR']['km1'])-mp.mpf(rec['F']['km1']), 30)
        out['points'][a] = rec
        print(a, rec['CR']['total'], rec['F']['total'], 'pole', rec['F']['pole_residue'], 'dJ', rec['DeltaJ_CR_minus_F'], flush=True)
        json.dump(out, open('logs/v9/mixed02.json', 'w'), indent=1)
