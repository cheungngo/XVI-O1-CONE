"""CK dictionary with free K-component scalars: K^00=d00*LL_tt, K^03=d03*LL_tz, K^33=LL_zz, K^11=K^22=dPM*PM;
c: comp0=sc*i*L_tau, comp3=L_z; q0=si*i*q_tau.  Unknowns (y_26,y_27,y_29,d00,d03,dPM) solved jointly (bilinear ->
we solve for products: rhs is linear in d's, so unknown vector is (y, d) with the equation E y - R(d) = R0)."""
import sys, json, itertools
from fractions import Fraction as Fr
sys.path.insert(0, '/workspace/XVI-O1-CONE/code/v8')
import sympy as sp
import apex_exact as AJ
from gq import GQ
from cone_v7 import catalogue, physical_cs, alpha as AL, kappa, q0, q3
a_s, br = sys.argv[1], sys.argv[2]; alpha = Fr(a_s); S = AJ.Setup(alpha, br); tag = f"{a_s.replace('/', '_')}_{br}"
cert = json.load(open(f'logs/v8/cert/apex_cert_{tag}.json')); vec = json.load(open(f'logs/v8/cert/apex_cert_{tag}_vectors.json'))
lab = cert['basis_labels']; K = vec['K']
def g2s(v):
    v = GQ.c(v); return sp.Rational(v.re.numerator, v.re.denominator) + sp.I*sp.Rational(v.im.numerator, v.im.denominator)
def cfg(C, v): return {C: {(0, Fr(0)): [GQ(t) for t in v]}}
VAT = [[1, 0], [0, 1]]; TAT = [('LL', [1, 0, 0, 0]), ('LL', [0, 1, 1, 0]), ('LL', [0, 0, 0, 1]), ('PM', [1])]
QG = [(a, b) for a in range(1, 7) for b in range(1, 7)]
cs = tuple(sp.simplify(c.subs(AL, sp.Rational(alpha.numerator, alpha.denominator))) for c in physical_cs(br))
cat = catalogue(cs)['D13']
piv = cert['gh0']['CK']['pivot_candidates']; cands = AJ.candidates(S, 'K', 'c', 4); basis = [cands[i] for i in piv]
Ks = [k for k in K if lab[k][0] == 'CK']; ib = [lab[k][1] for k in Ks]
d00, d03, dPM = sp.symbols('d00 d03 dPM'); ys = sp.symbols('y0:%d' % len(ib))
out = []
for si, sc in itertools.product((1, -1), repeat=2):
    eqs = []
    for (C, v) in TAT:
        Kl = {0: d00*v[0], 3: d03*v[1], 9: v[3], 4: 0, 7: 0} if C == 'LL' else {0: 0, 3: 0, 9: 0, 4: dPM*v[0], 7: dPM*v[0]}
        for w in VAT:
            cl = {0: sc*sp.I*w[0], 3: w[1]}
            for (qa, qb) in QG:
                q = [GQ(qa), GQ(qb)]
                e = sum(g2s(AJ.eval_sym(basis[i], cfg(C, v), cfg('L', w), q, False))*ys[j] for j, i in enumerate(ib))
                val = sum(c*Kl.get(a, 0)*cl.get(b, 0) for (a, b), c in cat.items())
                eqs.append(sp.expand(e - 2*val.subs({q0: si*sp.I*qa, q3: qb})*sp.pi/kappa**2))
    sol = sp.solve(eqs, list(ys) + [d00, d03, dPM], dict=True)
    out.append({'si': si, 'sc': sc, 'solutions': [{str(k): str(v) for k, v in s.items()} for s in sol]})
    print(si, sc, sol)
json.dump({'alpha': a_s, 'branch': br, 'units': 'y in kappa^2/pi', 'K': Ks, 'out': out}, open(f'logs/v9/ck_free_{tag}.json', 'w'), indent=1)
