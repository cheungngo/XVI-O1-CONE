"""v6 item (e): decompose the constant-profile apex pole bilinears (lattice keys, independent coordinates
x = (h00, h03, h33, f0)) into the 6 independent SO(1,1)-invariant symmetric structures quadratic in p
(2D Cayley-Hamilton removes p h h' p):
 S1 = P^2 trh trh', S2 = P^2 h.h', S3 = (php) trh' + trh (ph'p), S6 = P^2 (f0 trh' + trh f0'), S7 = (php) f0' + f0 (ph'p), S8 = P^2 f0 f0'.
Exact in alpha; also the gauge-invariant (Ward) combinations."""
import json, sympy as sp
al = sp.Symbol('alpha', positive=True); q0, q3 = sp.symbols('q0 q3')
ETA2 = [1, -1]; P2 = q0**2 - q3**2
x = sp.symbols('x00 x03 x33 xf'); z = sp.symbols('z00 z03 z33 zf')
def mats(v): return [[v[0], v[1]], [v[1], v[2]]], v[3]
p = [q0, q3]   # lower components p_a (a=0,3)
def up(M): return [[ETA2[a]*ETA2[b]*M[a][b] for b in range(2)] for a in range(2)]
def tr(M): return sum(ETA2[a]*M[a][a] for a in range(2))
def php(M):
    pu = [ETA2[a]*p[a] for a in range(2)]
    return sum(pu[a]*M[a][b]*pu[b] for a in range(2) for b in range(2))
def dot(M, N): U = up(M); return sum(U[a][b]*N[a][b] for a in range(2) for b in range(2))
hx, fx = mats(x); hz, fz = mats(z)
S = {'S1': P2*tr(hx)*tr(hz), 'S2': P2*dot(hx, hz), 'S3': php(hx)*tr(hz) + tr(hx)*php(hz),
     'S6': P2*(fx*tr(hz) + tr(hx)*fz), 'S7': php(hx)*fz + fx*php(hz), 'S8': P2*fx*fz}
idx = {0: 0, 3: 1, 9: 2, 4: 3, 7: 3}
def bil(path):
    D = json.load(open(path))['Gamma_pole_coeff_of_1/(4-d)']
    tot = 0
    for k, v in D.items():
        a, b = eval(k)
        if a in idx and b in idx: tot += sp.sympify(v, locals={'alpha': al}) * x[idx[a]] * z[idx[b]]
    return sp.expand(tot)
cs = sp.symbols('b1 b2 b3 b6 b7 b8')
def decompose(B):
    ans = sp.expand(sum(c*S[k] for c, k in zip(cs, S)))
    eqs = sp.Poly(sp.expand(ans - B), *x, *z, q0, q3).coeffs()
    sol = sp.solve(eqs, cs, dict=True)
    if not sol: return None
    return {k: str(sp.factor(sol[0].get(c, c))) for c, k in zip(cs, S)}
out = {}
for br in ['CR', 'F', 'UNIT']:
    out[br] = {}
    tot = 0
    for g in ['D01', 'D02', 'D03', 'D11', 'D12']:
        try: B = bil(f'logs/v4/spec_{g}_{br}.json')
        except FileNotFoundError: out[br][g] = 'MISSING'; continue
        tot += B
        out[br][g] = decompose(B) if B != 0 else 'zero (computed)'
    out[br]['hh_total'] = decompose(sp.expand(tot))
    print(br, json.dumps(out[br], indent=0), flush=True)
json.dump(out, open('logs/v6/hh_structures.json', 'w'), indent=1)
