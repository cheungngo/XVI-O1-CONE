"""v4 item (1): spectral apex reduction for one-loop kappa^2 two-point graphs on the cone, constant-profile
(n=0, m=0) external fields with longitudinal momentum p.
Hypotheses: (H_I) intertwining of transverse derivatives between helicity bundles on CR; then the apex part of
Tr_perp f(-Lap_b) = C_b f(0) with C_b = (1/12)(1/a - a) - b(1-b)/(2a)  (scale-invariant heat-trace constant).
Hence: apex pole = sum_S C_{b(S)} x [UV pole of the (d-2)-dim LONGITUDINAL loop integral of the flat XVI-P integrand
at k_perp = 0], each internal line weighted by the helicity class of its propagator components.
Graph conventions copied (read-only) from XVI-P amplitude_rules.build_integrands and XVI-Q Q02 bulk_graphs (D04, D06),
D05a (Q02 symmetry factor 1/2).  i Gamma = pref * int d^dl/(2pi)^d N/dens  ->  Gamma = -i pref int ...
Wick: l0 = i y0, l3 = y3;  int d^Dl_M/(2pi)^D f  pole  = i/(8 pi^2 eps) int_0^{2pi} g(theta) dtheta,  eps=(4-d)/2,
where g = lim R^2 * [degree -2 part of f].  Output: coefficient of 1/(4-d) of Gamma_{ab}(p), per unit area of W.
usage: spectral_apex.py <graph> [CR|F]"""
import sys, json, time, itertools
sys.path.insert(0, '/tmp/o1cone_ro/XVI-P/code/p5_entry')
import sympy as sp
import amplitude_rules as AR
F = AR.F
I = sp.I
g = sys.argv[1]; br = sys.argv[2] if len(sys.argv) > 2 else 'CR'
T0 = time.time()
LS, PS = sp.symbols('l0:4'), sp.symbols('p0:4')
NAMES = {**{r: LS[r] for r in range(4)}, **{4 + r: PS[r] for r in range(4)}}
kap = F.KAPPA
al = sp.Symbol('alpha', positive=True)
u = sp.symbols('u0:3'); v = sp.symbols('v0:3')
def sym(poly): return sp.expand(poly.to_sympy(NAMES)) if hasattr(poly, 'to_sympy') else sp.expand(poly)
HC = list(F.HC)
def ctype(i):
    m, n = HC[i]; L = (m in (0, 3)) + (n in (0, 3))
    return {2: 'L', 1: 'M', 0: 'T'}[L]
def cls(i, j):
    a, b = ctype(i), ctype(j)
    if a == b == 'M': return 1
    if a == b == 'T': return 2
    return 0
Pi = AR.pinv_sparse(); Gh = AR.ghost_num()
def Piw(i, j, mk): return sp.Rational(Pi[(i, j)].numerator, Pi[(i, j)].denominator) * mk[cls(i, j)]
def Ghw(i, j, mk): return sp.Rational(Gh[(i, j)].numerator, Gh[(i, j)].denominator) * mk[0 if i in (0, 3) else 1]
V = F.vertices()
def route(vt, r): return {k: sym(p) for k, p in F.vt_route(vt, r).items()}
def C_of(b): return sp.Rational(1, 12) * (1 / al - al) - b * (1 - b) / (2 * al)
def lab(S):
    if br == 'CR': return S * al if S >= 0 else 1 + S * al
    return {0: 0, 1: al, 2: 2 * al - 1}[S]       # F, 1/2 < alpha < 1 (|S| only; C symmetric under b -> 1-b)
CS = [sp.Integer(1)]*3 if br == "UNIT" else [C_of(lab(S)) for S in range(3)]
N = {}; dens = None
if g == 'D01':
    V3 = V['V3_grav']; VA = route(V3, [(0, 1), (-1, 0), (1, -1)]); VB = route(V3, [(0, -1), (1, 0), (-1, 1)])
    for (a, c, e), pa in VA.items():
        for (b, d, f), pb in VB.items():
            if (c, d) in Pi and (e, f) in Pi:
                N[(a, b)] = N.get((a, b), 0) + pa * pb * Piw(c, d, u) * Piw(e, f, v)
    pref = AR.base_rules()['graphs']['D01']['S_f'] * (I * kap) ** 2 * I ** (2 * V3.phase) * I ** 2; dens = 'll-p'
elif g == 'D03':
    Vg = V['V_cb_c_h']; VA = route(Vg, [(-1, 0), (1, -1), (0, 1)]); VB = route(Vg, [(-1, 1), (1, 0), (0, -1)])
    for (rho, mu, a), pa in VA.items():
        for (s, nu, b), pb in VB.items():
            if (mu, s) in Gh and (nu, rho) in Gh:
                N[(a, b)] = N.get((a, b), 0) + pa * pb * Ghw(mu, s, u) * Ghw(nu, rho, v)
    pref = -1 * (I * kap) ** 2 * I ** (2 * Vg.phase); dens = 'll-p'
elif g == 'D11':
    Vs = V['V_h_phi_phi']; VA = route(Vs, [(0, 1), (-1, 0), (1, -1)]); VB = route(Vs, [(0, -1), (1, 0), (-1, 1)])
    for (a, _, _), pa in VA.items():
        for (b, _, _), pb in VB.items():
            N[(a, b)] = N.get((a, b), 0) + pa * pb * u[0] * v[0]
    pref = sp.Rational(1, 2) * (I * kap) ** 2 * I ** (2 * Vs.phase) * I ** 2; dens = 'll-p'
elif g == 'D04':   # Q02: VA h_c:-l, phi_ext:p, phi:l-p ; VB h_d:l, phi_ext:-p, phi:p-l ; graviton line l, scalar line l-p
    Vs = V['V_h_phi_phi']; VA = route(Vs, [(-1, 0), (0, 1), (1, -1)]); VB = route(Vs, [(1, 0), (0, -1), (-1, 1)])
    for (c, _, _), pa in VA.items():
        for (d, _, _), pb in VB.items():
            if (c, d) in Pi:
                N[(0, 0)] = N.get((0, 0), 0) + pa * pb * Piw(c, d, u) * v[0]
    pref = 1 * (I * kap) ** 2 * I ** (2 * Vs.phase) * I ** 2; dens = 'll-p'
elif g == 'D06':   # Q02: VA cbar_rho:-p, c^mu:l, h_a:p-l ; VB cbar_sig:-l, c^nu:p, h_b:l-p ; ghost line l, graviton l-p
    Vg = V['V_cb_c_h']; VA = route(Vg, [(0, -1), (1, 0), (-1, 1)]); VB = route(Vg, [(-1, 0), (0, 1), (1, -1)])
    for (rho, mu, a), pa in VA.items():
        for (sg, nu, b), pb in VB.items():
            if (mu, sg) in Gh and (a, b) in Pi:
                N[(rho, nu)] = N.get((rho, nu), 0) + pa * pb * Ghw(mu, sg, u) * Piw(a, b, v)
    pref = 1 * (I * kap) ** 2 * I ** (2 * Vg.phase) * I ** 1; dens = 'll-p'
elif g == 'D13':
    rules = AR.base_rules(); VK = AR.K_vertex(rules); Vg = V['V_cb_c_h']
    VA = route(VK, [(0, -1), (1, 0), (-1, 1)]); VB = route(Vg, [(-1, 0), (0, 1), (1, -1)])
    for (ap, mu, c), pa in VA.items():
        for (rho, nu, d), pb in VB.items():
            if (mu, rho) in Gh and (c, d) in Pi:
                N[(ap, nu)] = N.get((ap, nu), 0) + pa * pb * Ghw(mu, rho, u) * Piw(c, d, v)
    R = rules['graphs']['D13']
    pref = R['ext_sign'] * R['S_f'] * R['loop_sign'] * (I * kap) ** 2 * I ** (VK.phase + Vg.phase) * I; dens = 'll-p'
elif g == 'D02':
    V4 = V['V4_grav']; VA = route(V4, [(0, 1), (0, -1), (1, 0), (-1, 0)])
    for (a, b, c, d), pa in VA.items():
        if (c, d) in Pi: N[(a, b)] = N.get((a, b), 0) + pa * Piw(c, d, u) * v[0]
    pref = sp.Rational(1, 2) * (I * kap ** 2) * I ** V4.phase * I; dens = 'l'
elif g == 'D12':
    V2s = V['V_hh_phi_phi']; VA = route(V2s, [(0, 1), (0, -1), (1, 0), (-1, 0)])
    for (a, b, _, _), pa in VA.items(): N[(a, b)] = N.get((a, b), 0) + pa * u[0] * v[0]
    pref = sp.Rational(1, 2) * (I * kap ** 2) * I ** V2s.phase * I; dens = 'l'
elif g == 'D05a':
    V2s = V['V_hh_phi_phi']; VB = route(V2s, [(1, 0), (-1, 0), (0, 1), (0, -1)])
    for (c, d, _, _), pa in VB.items():
        if (c, d) in Pi: N[(0, 0)] = N.get((0, 0), 0) + pa * Piw(c, d, u) * v[0]
    pref = sp.Rational(1, 2) * (I * kap ** 2) * I ** V2s.phase * I; dens = 'l'
print('built', g, len(N), round(time.time() - T0, 1), flush=True)
# longitudinal kinematics, Wick rotation
y0, y3, R, th, w = sp.symbols('y0 y3 R theta w', real=True)
q0, q3 = sp.symbols('q0 q3')         # external Minkowski longitudinal momentum p = (q0, 0, 0, q3)
sub = {LS[1]: 0, LS[2]: 0, PS[1]: 0, PS[2]: 0, PS[0]: q0, PS[3]: q3}
lM0, lM3 = I * R * sp.cos(th), R * sp.sin(th)
def msq(a0, a3): return a0 ** 2 - a3 ** 2
den = msq(lM0, lM3) if dens == 'l' else msq(lM0, lM3) * msq(lM0 - q0, lM3 - q3)
def pole(expr):
    """coefficient of 1/(4-d) of int d^Dl_M/(2pi)^D expr/den, expr polynomial in l0,l3."""
    e = sp.expand(expr.subs(sub).subs({LS[0]: lM0, LS[3]: lM3}))
    if e == 0: return 0
    f = e / den
    ser = sp.series(f.subs(R, 1 / w), w, 0, 3).removeO()
    g2 = sp.expand(ser.coeff(w, 2))
    g2 = sp.expand(sp.expand_trig(g2.rewrite(sp.exp)))
    integ = sp.integrate(g2, (th, 0, 2 * sp.pi))
    return sp.simplify(I / (4 * sp.pi ** 2) * integ)    # i/(8 pi^2 eps), eps=(4-d)/2
res = {}; mixed_ok = True
for k, e in N.items():
    e = sp.expand(e)
    if e == 0: continue
    P = sp.Poly(e, *u, *v)
    tot = 0
    for mon, cf in zip(P.monoms(), P.coeffs()):
        iu = [i for i in range(3) if mon[i]]; iv = [i for i in range(3) if mon[3 + i]]
        pv = pole(cf)
        if pv == 0: continue
        s1, s2 = iu[0], iv[0]
        if dens == 'l': s2 = s1          # tadpole: v0 is a dummy marker (no second line)
        if s1 != s2:
            mixed_ok = False; print('MIXED nonzero', k, mon, pv, flush=True); continue
        tot += pv * CS[s1]
    val = sp.factor(sp.simplify(-I * pref * tot))
    if val != 0: res[str(k)] = str(val)
out = {'graph': g, 'branch': br, 'pref': str(pref), 'mixed_helicity_cancel': mixed_ok, 'Gamma_pole_coeff_of_1/(4-d)': res,
       'ext_keys': 'HC component indices (graviton) / ghost vector index / 0 for scalar', 'momentum': 'p=(q0,0,0,q3), mostly-minus',
       'seconds': round(time.time() - T0, 1)}
json.dump(out, open('/workspace/XVI-O1-CONE/logs/v4/spec_%s_%s.json' % (g, br), 'w'), indent=1)
print(json.dumps(out)[:3000])
