"""(A3) Exhaustive resonance set.  CR lemma: for alpha<1 (t=1/alpha>1) every jet of every field obeys
m = |n| t + A, A integer >= -2 (Friedrichs channels: sgn(nt+s)=sgn(n) unless |n|=1,|s|=2,t<2; those two channels are
exactly the CR-flipped ones, m=t-2+2j).  A pairing with some n!=0 needs N t in Z with N=sum|n|>=2 and
sum m <= M (sector budget), hence N < K := N t <= M + 2J (J = #jets with n!=0 = 2).  So the CR-resonant alphas are
among N/K.  We enumerate those and confirm with the engine's own jet lists which ones actually admit an n!=0 pair
(candidate with integer k>=0) in any sector (gh-1 T=3, gh0 T=4, gh1 T=5); for F we scan the same rational set plus the
chamber representatives."""
import sys, json
from fractions import Fraction as Fr
sys.path.insert(0, '/workspace/XVI-O1-CONE/code')
from apex_jets import Setup, candidates
SECTORS = [('h','h',4),('cb','c',4),('K','c',4),('phi','phi',4),('h','cb',3),('h','K',3),('cs','c',3),('h','c',5),('b','c',5)]
def nz_pairs(al, br):
    S = Setup(al, br); out = {}
    for F1, F2, T in SECTORS:
        c = [x for x in candidates(S, F1, F2, T) if x[0][1] != 0]
        if c: out['%s.%s(T=%d)' % (F1, F2, T)] = sorted(set((str(x[0]), str(x[1]), x[4]) for x in c))
    return out
cand = set()
for N in range(2, 12, 2):
    for K in range(N + 1, 3 + 4 + 1):
        cand.add(Fr(N, K))
cand = sorted(a for a in cand if 0 < a < 1)
res = {'CR_candidate_set_N_over_K': [str(a) for a in cand], 'CR': {}, 'F': {}}
for a in cand:
    p = nz_pairs(a, 'CR')
    res['CR'][str(a)] = {k: len(v) for k, v in p.items()}
# generic control points (should be empty for CR) and F scan on a fine rational grid
grid = sorted(set(cand) | {Fr(k, 97) for k in range(10, 97)} | {Fr(3, 10), Fr(7071, 10000), Fr(8501, 10000)})
res['CR_nonempty_on_grid'] = [str(a) for a in grid if nz_pairs(a, 'CR')]
res['F_nonempty_on_grid'] = {str(a): {k: len(v) for k, v in nz_pairs(a, 'F').items()} for a in grid if nz_pairs(a, 'F')}
print(json.dumps({'CR': {k: v for k, v in res['CR'].items() if v}, 'CR_grid': res['CR_nonempty_on_grid']}, indent=0))
print('F grid nonempty count', len(res['F_nonempty_on_grid']), 'min', min(map(Fr, res['F_nonempty_on_grid'])) if res['F_nonempty_on_grid'] else None)
json.dump(res, open('/workspace/XVI-O1-CONE/logs/v2_resonances.json', 'w'), indent=1)
