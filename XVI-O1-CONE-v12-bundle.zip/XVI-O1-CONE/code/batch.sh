#!/bin/bash
cd /workspace/XVI-O1-CONE
for a in 3/10 41/100 1/2 6180/10000 2/3 7071/10000 4/5 8501/10000; do for b in CR F; do for p in 0 1; do
 echo "== $a $b $p"; timeout 600 python3 code/apex_run.py $a $b $p 2>&1 | grep -v '^ ' | head -5
done; done; done
echo BATCH_DONE
