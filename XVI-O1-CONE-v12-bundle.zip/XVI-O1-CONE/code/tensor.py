"""Helicity-projected Feynman / de Donder kernels on the cone (Euclidean, developed Cartesian frame (tau,X,Y,z))."""
import mpmath as mp, itertools, sys; sys.path.insert(0,'/workspace/XVI-O1-CONE/code')
from kernel import S, f
def Gb(b,alpha,x,xp,flip=None):
    t,X,Y,z=x; tp,Xp,Yp,zp=xp
    r=mp.sqrt(X*X+Y*Y); rp=mp.sqrt(Xp*Xp+Yp*Yp)
    psi=(mp.atan2(Yp,Xp)-mp.atan2(Y,X))/alpha
    eta=mp.acosh((r*r+rp*rp+(t-tp)**2+(z-zp)**2)/(2*r*rp))
    u=eta/alpha; s=S(b,u,psi)
    if flip is not None:   # flip mode with angular exponent m=n+b (E0 in that channel)
        m=flip; s+= mp.exp(1j*m*psi)*(mp.exp(abs(m)*u)-mp.exp(-abs(m)*u))
    return s/(8*mp.pi**2*alpha*r*rp*mp.sinh(eta))
sq=1/mp.sqrt(2)
U={'t':(mp.mpf(1),0,0,0),'p':(0,sq,1j*sq,0),'m':(0,sq,-1j*sq,0),'z':(0,0,0,mp.mpf(1))}
HEL={'t':0,'p':1,'m':-1,'z':0}
def bgeom(s,alpha): return s*alpha if s>=0 else 1+s*alpha
def bfried(s,alpha):
    b=s*alpha; return b-mp.floor(b)
def vec_kernel(alpha,x,xp,branch=bgeom,flips={}):
    """W[a][b] = sum_A u_A u_A^dagger G_{b(s_A)}"""
    cache={}
    def g(s):
        if s not in cache: cache[s]=Gb(branch(s,alpha),alpha,x,xp,flips.get(s))
        return cache[s]
    W=[[0]*4 for _ in range(4)]
    for A,u in U.items():
        gs=g(HEL[A])
        for a in range(4):
            for b in range(4):
                W[a][b]+=u[a]*mp.conj(u[b])*gs
    return W
def P(a,b,c,d): return (a==c)*(b==d)+(a==d)*(b==c)-(a==b)*(c==d)
def ten_kernel(alpha,x,xp,branch=bgeom,flips={}):
    """W[(a,b)][(c,d)] = sum_{A,B} (u_A x u_B)(u_A x u_B)^dagger P G_{b(s_A+s_B)} ; P commutes with helicity projectors"""
    cache={}
    def g(s):
        if s not in cache: cache[s]=Gb(branch(s,alpha),alpha,x,xp,flips.get(s))
        return cache[s]
    idx=list(itertools.product(range(4),repeat=2))
    # projector-weighted kernel K[(a,b)][(e,f)] = sum_{AB} uA_a uB_b conj(uA_e uB_f) g(sA+sB)
    K={}
    for I in idx:
        for J in idx:
            K[(I,J)]=0
    for A,uA in U.items():
        for B,uB in U.items():
            gs=g(HEL[A]+HEL[B])
            for I in idx:
                vI=uA[I[0]]*uB[I[1]]
                if vI==0: continue
                for J in idx:
                    vJ=mp.conj(uA[J[0]]*uB[J[1]])
                    if vJ!=0: K[(I,J)]+=vI*vJ*gs
    W={}
    for I in idx:
        for J in idx:
            W[(I,J)]=sum(K[(I,L)]*P(L[0],L[1],J[0],J[1]) for L in idx)
    return W
