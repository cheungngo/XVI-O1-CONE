import sys
from fractions import Fraction as Fr
sys.path.insert(0, '/workspace/XVI-O1-CONE/code')
import apex_jets as AJ
from apex_jets import Setup, pairings, FIELDS, SCA
FIELDS['phis'] = (SCA, 2, 'scalar')
def jets0(S, F, dmax):
    return [j for j in S.jets(F, dmax) if j[1] == 0]
def tri_cands(S, F1, F2, F3, T):
    out = []
    d = [FIELDS[F][1] for F in (F1, F2, F3)]
    for j1 in jets0(S, F1, T):
        for j2 in jets0(S, F2, T):
            for j3 in jets0(S, F3, T):
                k = Fr(T) - sum(d) - j1[2] - j2[2] - j3[2]
                if k.denominator != 1 or k < 0: continue
                k = int(k); r = [FIELDS[F][0][j[0]][1] for F, j in ((F1, j1), (F2, j2), (F3, j3))]
                for k1 in range(k + 1):
                    k2 = k - k1
                    slots = [('A', i) for i in range(r[0])] + [('B', i) for i in range(r[1])] + [('C', i) for i in range(r[2])] + [('p1', i) for i in range(k1)] + [('p2', i) for i in range(k2)]
                    if len(slots) % 2: continue
                    seen = set()
                    for pr in pairings(slots):
                        key = tuple(sorted(tuple(sorted((x[0], x[1] if x[0] not in ('p1', 'p2') else 0) for x in pair)) for pair in pr))
                        if key in seen: continue
                        seen.add(key); out.append((j1, j2, j3, r, k1, k2, pr))
    return out
if __name__ == '__main__':
    S = Setup(Fr(7071, 10000), 'CR')
    for sec, (F1, F2, F3, T) in {'HHH': ('h','h','h',5), 'PPH': ('phi','phi','h',5), 'KCH': ('K','c','h',5), 'SCC': ('cs','c','c',5), 'FPC': ('phis','phi','c',5),
                                 'HHC': ('h','h','c',6), 'PPC': ('phi','phi','c',6), 'KCC': ('K','c','c',6), 'HCC': ('h','c','c',7)}.items():
        print(sec, len(tri_cands(S, F1, F2, F3, T)), flush=True)
