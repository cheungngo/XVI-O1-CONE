"""(F) Independent cross-check of the exact Synge data (Bernoulli route, coinc.py) against
 (i) the closed-form kernel (kernel.py S_b) and (ii) a direct angular MODE SUM (with the CR E0 mode flipped explicitly),
evaluated at finite separations; residual must scale like lambda^3."""
import pickle, sys, json
import mpmath as mp, sympy as sp
sys.path.insert(0, '/workspace/XVI-O1-CONE/code')
mp.mp.dps = 30
from kernel import S as S_closed
D = pickle.load(open('/workspace/XVI-O1-CONE/logs/v2_coinc_E.pkl', 'rb'))
t, X, Y, z = D['coords']; bs, als = sp.symbols('b alpha', positive=True)
d = sp.symbols('d0:4')
def S_modes(b, u, psi):
    f = lambda n: mp.exp(1j * (n + b) * psi - abs(n + b) * u)
    s = mp.nsum(f, [-mp.inf, mp.inf])
    # explicit E0 flips: geometric (CR) branch for b>1 flips exponent b-1; for b<0 flips exponent b
    if b > 1: s += mp.exp(1j * (b - 1) * psi) * (mp.exp((b - 1) * u) - mp.exp(-(b - 1) * u))
    if b < 0: s += mp.exp(1j * b * psi) * (mp.exp(-b * u) - mp.exp(b * u))
    return s
def Rnum(b, al, x, xp, how):
    tt, X1, Y1, zz = x; tp, X2, Y2, zp = xp
    r = mp.sqrt(X1 ** 2 + Y1 ** 2); rp = mp.sqrt(X2 ** 2 + Y2 ** 2)
    ep = mp.atan2(Y2, X2) - mp.atan2(Y1, X1); psi = ep / al
    ch = (r * r + rp * rp + (tt - tp) ** 2 + (zz - zp) ** 2) / (2 * r * rp); eta = mp.acosh(ch); u = eta / al
    Sv = S_closed(b, u, psi) if how == 'closed' else S_modes(b, u, psi)
    return Sv / (8 * mp.pi ** 2 * al * r * rp * mp.sinh(eta)) - 1 / (8 * mp.pi ** 2 * r * rp * (ch - mp.cos(ep)))
out = []
al = mp.mpf('0.7071067811865475244')
x0 = (mp.mpf(0), mp.mpf('1.0'), mp.mpf('0.3'), mp.mpf(0)); dv = (mp.mpf('0.3'), mp.mpf('-0.5'), mp.mpf('0.7'), mp.mpf('0.4'))
labels = {'0': 0, 'alpha': al, '1-alpha': 1 - al, '2alpha(CR)': 2 * al, '1-2alpha(CR)': 1 - 2 * al, '2alpha-1(F)': 2 * al - 1}
for name, bv in labels.items():
    sub = {bs: sp.Float(str(bv), 30), als: sp.Float(str(al), 30), t: 0, X: sp.Float('1.0', 30), Y: sp.Float('0.3', 30), z: 0}
    A = complex(sp.N(D['A'].subs(sub), 25)); Bv = [complex(sp.N(Bi.subs(sub), 25)) for Bi in D['B']]
    Cm = [[complex(sp.N(D['C'][i][j].subs(sub), 25)) for j in range(4)] for i in range(4)]
    row = {'label': name}
    for how in ('closed', 'modes'):
        res = []
        for lam in (mp.mpf('0.04'), mp.mpf('0.02'), mp.mpf('0.01')):
            xp = tuple(x0[i] + lam * dv[i] for i in range(4))
            pred = A + lam * sum(Bv[i] * float(dv[i]) for i in range(4)) + lam ** 2 * sum(Cm[i][j] * float(dv[i]) * float(dv[j]) for i in range(4) for j in range(4))
            res.append(float(abs(Rnum(bv, al, x0, xp, how) - pred)))
        row[how] = res; row[how + '_order'] = [mp.nstr(mp.log(res[0] / res[1], 2), 4), mp.nstr(mp.log(res[1] / res[2], 2), 4)]
    out.append(row); print(row, flush=True)
json.dump(out, open('/workspace/XVI-O1-CONE/logs/v2_xcheck_coinc.json', 'w'), indent=1)
