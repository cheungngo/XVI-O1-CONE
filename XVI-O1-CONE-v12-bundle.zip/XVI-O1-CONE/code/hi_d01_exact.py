"""v6 item (c), exact: Mellin-regularised composite trace R(z) for D01 (H_I) in closed form.
At s=1/2 (x=r^2): D(r) = A e^{-x}[ x K - 2x K' + K' + x K'' - 2 nu(-K + K') + nu^2 K/x ],  K = K_nu(x),
r dr = dx/2, r^z = x^{z/2}.  Uses  int_0^inf x^{mu-1} e^{-x} K_m(x) dx = sqrt(pi) G(mu+m) G(mu-m) / (2^mu G(mu+1/2))
(DLMF 10.43.22-type Mellin formula, analytically continued in mu).  Tests R(0) = 0 exactly in nu."""
import sympy as sp, json, mpmath as mp
nu, z = sp.symbols('nu z')
def I(mu, m):
    return sp.sqrt(sp.pi)*sp.gamma(mu+m)*sp.gamma(mu-m)/(2**mu*sp.gamma(mu+sp.Rational(1, 2)))
w = z/2 + 1     # x^{z/2} * x^{k} -> mu = z/2 + 1 + k
# K' = -(K_{nu-1}+K_{nu+1})/2 ; K'' = (K_{nu-2} + 2K_nu + K_{nu+2})/4
def Kint(k, kind):  # int x^{z/2+k} e^{-x} [K-derivative](x) dx  (mu = z/2 + k + 1)
    mu = z/2 + k + 1
    if kind == 0: return I(mu, nu)
    if kind == 1: return -(I(mu, nu-1) + I(mu, nu+1))/2
    if kind == 2: return (I(mu, nu-2) + 2*I(mu, nu) + I(mu, nu+2))/4
bracket = (Kint(1, 0) - 2*Kint(1, 1) + Kint(0, 1) + Kint(1, 2) + 2*nu*Kint(0, 0) - 2*nu*Kint(0, 1) + nu**2*Kint(-1, 0))
R = sp.Rational(1, 2)*bracket          # times A = sin(pi nu)/(pi s), omitted (nonzero constant)
out = {}
for nv in ['1/3', '4/7', '2/3', '3/4', '8/9', '0.37', '0.91']:
    f = sp.lambdify(z, R.subs(nu, sp.nsimplify(nv) if '/' in nv else sp.Float(nv, 50)), 'mpmath')
    mp.mp.dps = 50
    out[nv] = mp.nstr(f(mp.mpf('1e-30')), 12)
print('R(z->0) numeric (times 1/A):', out)
# exact: simplify R at z=0 symbolically via gammasimp
R0 = sp.gammasimp(sp.simplify(R.subs(z, 0)))
print('R(0) symbolic:', R0)
Rs = sp.series(R, z, 0, 2).removeO()
out_sym = {'R0_symbolic': str(sp.simplify(R0)), 'R_first_order_in_z': str(sp.simplify(sp.gammasimp(Rs.coeff(z, 1))))}
print(out_sym)
json.dump({'numeric_R0_over_A': out, **out_sym}, open('logs/v6/hi_d01_exact.json', 'w'), indent=1)
# numerical check of the Mellin-Laplace formula in its convergent strip (a=1 limit of DLMF 10.43.22)
mp.mp.dps = 30
fchk = {}
for mu_, m_ in [(2, 0.3), (3.5, 1.7), (2.5, 0.5)]:
    q = mp.quad(lambda x: x**(mu_-1)*mp.e**(-x)*mp.besselk(m_, x), [0, 1, mp.inf])
    f = mp.sqrt(mp.pi)*mp.gamma(mu_+m_)*mp.gamma(mu_-m_)/(2**mu_*mp.gamma(mu_+0.5))
    fchk[str((mu_, m_))] = mp.nstr(q-f, 5)
print('formula check', fchk)
d = json.load(open('logs/v6/hi_d01_exact.json')); d['formula_check_quad_minus_closed'] = fchk
json.dump(d, open('logs/v6/hi_d01_exact.json', 'w'), indent=1)
