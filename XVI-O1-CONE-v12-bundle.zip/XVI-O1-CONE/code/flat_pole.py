"""v4 item (1): spectral apex reduction for one-loop kappa^2 two-point graphs on the cone, constant-profile
(n=0, m=0) external fields with longitudinal momentum p.
Hypotheses: (H_I) intertwining of transverse derivatives between helicity bundles on CR; then the apex part of
Tr_perp f(-Lap_b) = C_b f(0) with C_b = (1/12)(1/a - a) - b(1-b)/(2a)  (scale-invariant heat-trace constant).
Hence: apex pole = sum_S C_{b(S)} x [UV pole of the (d-2)-dim LONGITUDINAL loop integral of the flat XVI-P integrand
at k_perp = 0], each internal line weighted by the helicity class of its propagator components.
Graph conventions copied (read-only) from XVI-P amplitude_rules.build_integrands and XVI-Q Q02 bulk_graphs (D04, D06),
D05a (Q02 symmetry factor 1/2).  i Gamma = pref * int d^dl/(2pi)^d N/dens  ->  Gamma = -i pref int ...
Wick: l0 = i y0, l3 = y3;  int d^Dl_M/(2pi)^D f  pole  = i/(8 pi^2 eps) int_0^{2pi} g(theta) dtheta,  eps=(4-d)/2,
where g = lim R^2 * [degree -2 part of f].  Output: coefficient of 1/(4-d) of Gamma_{ab}(p), per unit area of W.
usage: flat_pole.py <graph>  (v6: FLAT 4D bulk UV pole, same graph builder; validation of ST conventions)"""
import sys, json, time, itertools
sys.path.insert(0, '/tmp/o1cone_ro/XVI-P/code/p5_entry')
import sympy as sp
import amplitude_rules as AR
F = AR.F
I = sp.I
g = sys.argv[1]; br = 'UNIT'
T0 = time.time()
LS, PS = sp.symbols('l0:4'), sp.symbols('p0:4')
NAMES = {**{r: LS[r] for r in range(4)}, **{4 + r: PS[r] for r in range(4)}}
kap = F.KAPPA
al = sp.Symbol('alpha', positive=True)
u = sp.symbols('u0:3'); v = sp.symbols('v0:3')
def sym(poly): return sp.expand(poly.to_sympy(NAMES)) if hasattr(poly, 'to_sympy') else sp.expand(poly)
HC = list(F.HC)
def ctype(i):
    m, n = HC[i]; L = (m in (0, 3)) + (n in (0, 3))
    return {2: 'L', 1: 'M', 0: 'T'}[L]
def cls(i, j):
    a, b = ctype(i), ctype(j)
    if a == b == 'M': return 1
    if a == b == 'T': return 2
    return 0
Pi = AR.pinv_sparse(); Gh = AR.ghost_num()
def Piw(i, j, mk): return sp.Rational(Pi[(i, j)].numerator, Pi[(i, j)].denominator) * mk[cls(i, j)]
def Ghw(i, j, mk): return sp.Rational(Gh[(i, j)].numerator, Gh[(i, j)].denominator) * mk[0 if i in (0, 3) else 1]
V = F.vertices()
def route(vt, r): return {k: sym(p) for k, p in F.vt_route(vt, r).items()}
def C_of(b): return sp.Rational(1, 12) * (1 / al - al) - b * (1 - b) / (2 * al)
def lab(S):
    if br == 'CR': return S * al if S >= 0 else 1 + S * al
    return {0: 0, 1: al, 2: 2 * al - 1}[S]       # F, 1/2 < alpha < 1 (|S| only; C symmetric under b -> 1-b)
CS = [sp.Integer(1)]*3 if br == "UNIT" else [C_of(lab(S)) for S in range(3)]
N = {}; dens = None
if g == 'D01':
    V3 = V['V3_grav']; VA = route(V3, [(0, 1), (-1, 0), (1, -1)]); VB = route(V3, [(0, -1), (1, 0), (-1, 1)])
    for (a, c, e), pa in VA.items():
        for (b, d, f), pb in VB.items():
            if (c, d) in Pi and (e, f) in Pi:
                N[(a, b)] = N.get((a, b), 0) + pa * pb * Piw(c, d, u) * Piw(e, f, v)
    pref = AR.base_rules()['graphs']['D01']['S_f'] * (I * kap) ** 2 * I ** (2 * V3.phase) * I ** 2; dens = 'll-p'
elif g == 'D03':
    Vg = V['V_cb_c_h']; VA = route(Vg, [(-1, 0), (1, -1), (0, 1)]); VB = route(Vg, [(-1, 1), (1, 0), (0, -1)])
    for (rho, mu, a), pa in VA.items():
        for (s, nu, b), pb in VB.items():
            if (mu, s) in Gh and (nu, rho) in Gh:
                N[(a, b)] = N.get((a, b), 0) + pa * pb * Ghw(mu, s, u) * Ghw(nu, rho, v)
    pref = -1 * (I * kap) ** 2 * I ** (2 * Vg.phase); dens = 'll-p'
elif g == 'D11':
    Vs = V['V_h_phi_phi']; VA = route(Vs, [(0, 1), (-1, 0), (1, -1)]); VB = route(Vs, [(0, -1), (1, 0), (-1, 1)])
    for (a, _, _), pa in VA.items():
        for (b, _, _), pb in VB.items():
            N[(a, b)] = N.get((a, b), 0) + pa * pb * u[0] * v[0]
    pref = sp.Rational(1, 2) * (I * kap) ** 2 * I ** (2 * Vs.phase) * I ** 2; dens = 'll-p'
elif g == 'D04':   # Q02: VA h_c:-l, phi_ext:p, phi:l-p ; VB h_d:l, phi_ext:-p, phi:p-l ; graviton line l, scalar line l-p
    Vs = V['V_h_phi_phi']; VA = route(Vs, [(-1, 0), (0, 1), (1, -1)]); VB = route(Vs, [(1, 0), (0, -1), (-1, 1)])
    for (c, _, _), pa in VA.items():
        for (d, _, _), pb in VB.items():
            if (c, d) in Pi:
                N[(0, 0)] = N.get((0, 0), 0) + pa * pb * Piw(c, d, u) * v[0]
    pref = 1 * (I * kap) ** 2 * I ** (2 * Vs.phase) * I ** 2; dens = 'll-p'
elif g == 'D06':   # Q02: VA cbar_rho:-p, c^mu:l, h_a:p-l ; VB cbar_sig:-l, c^nu:p, h_b:l-p ; ghost line l, graviton l-p
    Vg = V['V_cb_c_h']; VA = route(Vg, [(0, -1), (1, 0), (-1, 1)]); VB = route(Vg, [(-1, 0), (0, 1), (1, -1)])
    for (rho, mu, a), pa in VA.items():
        for (sg, nu, b), pb in VB.items():
            if (mu, sg) in Gh and (a, b) in Pi:
                N[(rho, nu)] = N.get((rho, nu), 0) + pa * pb * Ghw(mu, sg, u) * Piw(a, b, v)
    pref = 1 * (I * kap) ** 2 * I ** (2 * Vg.phase) * I ** 1; dens = 'll-p'
elif g == 'D13':
    rules = AR.base_rules(); VK = AR.K_vertex(rules); Vg = V['V_cb_c_h']
    VA = route(VK, [(0, -1), (1, 0), (-1, 1)]); VB = route(Vg, [(-1, 0), (0, 1), (1, -1)])
    for (ap, mu, c), pa in VA.items():
        for (rho, nu, d), pb in VB.items():
            if (mu, rho) in Gh and (c, d) in Pi:
                N[(ap, nu)] = N.get((ap, nu), 0) + pa * pb * Ghw(mu, rho, u) * Piw(c, d, v)
    R = rules['graphs']['D13']
    pref = R['ext_sign'] * R['S_f'] * R['loop_sign'] * (I * kap) ** 2 * I ** (VK.phase + Vg.phase) * I; dens = 'll-p'
elif g == 'D02':
    V4 = V['V4_grav']; VA = route(V4, [(0, 1), (0, -1), (1, 0), (-1, 0)])
    for (a, b, c, d), pa in VA.items():
        if (c, d) in Pi: N[(a, b)] = N.get((a, b), 0) + pa * Piw(c, d, u) * v[0]
    pref = sp.Rational(1, 2) * (I * kap ** 2) * I ** V4.phase * I; dens = 'l'
elif g == 'D12':
    V2s = V['V_hh_phi_phi']; VA = route(V2s, [(0, 1), (0, -1), (1, 0), (-1, 0)])
    for (a, b, _, _), pa in VA.items(): N[(a, b)] = N.get((a, b), 0) + pa * u[0] * v[0]
    pref = sp.Rational(1, 2) * (I * kap ** 2) * I ** V2s.phase * I; dens = 'l'
elif g == 'D05a':
    V2s = V['V_hh_phi_phi']; VB = route(V2s, [(1, 0), (-1, 0), (0, 1), (0, -1)])
    for (c, d, _, _), pa in VB.items():
        if (c, d) in Pi: N[(0, 0)] = N.get((0, 0), 0) + pa * Piw(c, d, u) * v[0]
    pref = sp.Rational(1, 2) * (I * kap ** 2) * I ** V2s.phase * I; dens = 'l'

print('built', g, len(N), round(time.time() - T0, 1), flush=True)
q0, q3 = sp.symbols('q0 q3')
L = LS
sub = {PS[1]: 0, PS[2]: 0, PS[0]: q0, PS[3]: q3}
ETA = [1, -1, -1, -1]
pv = [q0, 0, 0, q3]
lp = sum(ETA[r] * L[r] * pv[r] for r in range(4)); p2 = q0**2 - q3**2
def dfact(n):
    r = 1
    while n > 1: r *= n; n -= 2
    return r
def avg(mon):   # <prod l_r^{n_r}> / (l^2)^k, d=4 Minkowski
    if any(n % 2 for n in mon): return 0
    k = sum(mon) // 2
    c = sp.Integer(1)
    for r, n in enumerate(mon): c *= dfact(n - 1) * ETA[r] ** (n // 2)
    return c / (2**k * sp.factorial(k + 1))
def pole4(expr):
    """coefficient of 1/(4-d) of int d^dl_M/(2pi)^d expr/den  (den = l^2 or l^2 (l-p)^2), UV only: i/(8 pi^2) x <deg -4 part> (l^2)^2"""
    e = sp.expand(expr.subs(sub))
    if e == 0: return 0
    P = sp.Poly(e, *L)
    tot = 0
    for mon, cf in zip(P.monoms(), P.coeffs()):
        kdeg = sum(mon)
        if dens == 'l':
            # mon/l^2: degree kdeg-2 == -4 impossible for kdeg>=0
            continue
        # 1/(l-p)^2 = sum_n (2 l.p - p^2)^n/(l^2)^{n+1}; need kdeg + j - 2n - 4 = -4, j = #(2l.p) factors
        for n in range(0, kdeg + 1):
            j = 2 * n - kdeg
            if j < 0 or j > n: continue
            term = sp.binomial(n, j) * (2 * lp) ** j * (-p2) ** (n - j)
            Q = sp.Poly(sp.expand(term * sp.Mul(*[L[r] ** mon[r] for r in range(4)])), *L)
            for m2, c2 in zip(Q.monoms(), Q.coeffs()):
                tot += cf * c2 * avg(m2)
    return sp.expand(I / (8 * sp.pi**2) * tot)
res = {}
for k, e in N.items():
    e = sp.expand(e.subs({**{x: 1 for x in u}, **{x: 1 for x in v}}))
    if e == 0: continue
    val = sp.factor(sp.simplify(-I * pref * pole4(e)))
    if val != 0: res[str(k)] = str(val)
out = {'graph': g, 'branch': 'FLAT4D', 'pref': str(pref), 'Gamma_pole_coeff_of_1/(4-d)': res,
       'momentum': 'p=(q0,0,0,q3), mostly-minus', 'seconds': round(time.time() - T0, 1)}
import os; os.makedirs('/workspace/XVI-O1-CONE/logs/v6', exist_ok=True)
json.dump(out, open('/workspace/XVI-O1-CONE/logs/v6/flat_%s.json' % g, 'w'), indent=1)
print(json.dumps(out)[:1500])
