"""Assemble XVI-O1-CONE-v6.tex from read-only v5 + v6src fragments + generated artifact appendix."""
import hashlib, glob, os, subprocess
R = '/workspace/XVI-O1-CONE/'
s = open(R + 'XVI-O1-CONE-v5.tex').read()
F = lambda n: open(R + 'v6src/' + n).read()
def rep(old, new, count=1):
    global s
    assert s.count(old) == count, (s.count(old), old[:80])
    s = s.replace(old, new)
def between(a, b, new, keep_a=False, keep_b=True):
    """replace text from start of a to start of b"""
    global s
    i = s.index(a); j = s.index(b, i)
    s = s[:i] + ((a if keep_a else '') + new) + s[j:]
# ---------- title / pdf metadata
rep("""  pdftitle={Scoped O.1 on the Cone:
  Spectral Apex Reduction, Constant-Profile Pole Records,
  and Ward-Identity Boundaries},""",
"""  pdftitle={Scoped O.1 on the Cone, v6:
  Executed Apex Records, a Closed Constant-Profile Slavnov-Taylor Row,
  and Ward-Identity Boundaries},""")
rep("""\\title{\\textbf{Scoped O.1 on the Cone}\\\\[5pt]
\\Large Spectral Apex Reduction, Constant-Profile Pole Records,
and Ward-Identity Boundaries\\\\[6pt]
\\large A proof-level normalization audit and conditional reconstruction
of the supplied v4 calculation}""",
"""\\title{\\textbf{Scoped O.1 on the Cone}\\\\[5pt]
\\Large Executed Apex Records, a Closed Constant-Profile
Slavnov--Taylor Row, Weighted Apex Coefficients,
and Ward-Identity Boundaries\\\\[6pt]
\\large An artifact-verified revision of the v5 proof-level audit}""")
rep("""\\small Version 5; revision of the supplied
\\loc{XVI-O1-CONE-v4.tex}}""", """\\small Version 6; revision of \\loc{XVI-O1-CONE-v5.tex}}""")
# macros
rep("\\newcommand{\\UNVALIDATED}{\\textsf{UNVALIDATED}}",
    "\\newcommand{\\UNVALIDATED}{\\textsf{UNVALIDATED}}\n\\newtheorem*{evidence}{Evidence}")
# ---------- abstract
between("\\begin{abstract}", "\\tableofcontents", F('abstract.tex') + "\n\n")
# ---------- evidence classes
between("This revision uses three evidence classes.", "\\subsection{Programme non-transfer}", F('evidence.tex') + "\n")
# ---------- weighted section after flip section
rep("""%======================================================================
\\section{Conditional spectral reduction of a two-point graph}""",
    F('weighted.tex') + """
%======================================================================
\\section{Conditional spectral reduction of a two-point graph}""")
# ---------- H_I subsection
rep("""Merely assuming the already excluded unrestricted tower would not
certify D01.
""", """Merely assuming the already excluded unrestricted tower would not
certify D01.

""" + F('hi.tex'))
# ---------- catalogue
rep("""All formulas below are exact algebraic expressions.
Their graph interpretation is subject to
Assumption~\\ref{ass:reduction} and matching to the frozen vertex
data. No new coefficient has been obtained by an executed program.""", F('cat_status.tex').rstrip())
between("The supplied Q02 comparison reports the D05a symmetry factor", "\\subsection{Tensor two-point sector}", F('cat_q02.tex') + "\n")
rep("""D03:
\\((4,7)\\)
&
\\(\\displaystyle -c_0P^2\\)\\\\[5pt]
""", """D03:
\\((4,7)\\)
&
\\(\\displaystyle -c_0P^2\\)\\\\[5pt]

D03:
\\((5,5)\\) \\emph{(new in v6)}
&
\\(\\displaystyle -8c_1P^2\\)\\\\[5pt]
""")
rep("""D01:
\\((0,4)\\)
&
\\(\\displaystyle -Bq_0^2+Aq_3^2\\)\\\\
""", """D01:
\\((0,4)\\)
&
\\(\\displaystyle -Bq_0^2+Aq_3^2\\)\\\\[5pt]

D01:
\\((5,5)\\) \\emph{(new in v6)}
&
\\(\\displaystyle -8c_1P^2\\)\\\\
""")
rep("""\\caption{The complete set of printed v4 \\(hh\\) bubble entries,
in equivalent apex-coefficient form.""", """\\caption{The \\(hh\\) bubble entries of v4, in equivalent
apex-coefficient form, with the \\((5,5)\\) entries added from the
executed record (v6).""")
rep("""The entries related by \\(1\\leftrightarrow2\\) are identified in the
supplied record:""", """The entries related by \\(1\\leftrightarrow2\\) are identified in the
executed record:""")
between("D02 and D12 were not printed as component formulas in v4.", "\\subsection{Ghost and source-ghost sector}", F('cat_d02.tex') + "\n")
# ---------- branch tail
between("Independent-component weights matter here.", "%======================================================================\n\\section{The ghost-equation row", F('branch_tail.tex') + "\n")
# ---------- ghost remark
rep("""It is not a proof that all source components or all 26
Ward-constrained combinations have been tested.
""", """It is not a proof that all source components or all 26
Ward-constrained combinations have been tested.
""" + F('ghost_add.tex'))
# ---------- ST section
rep("\\section{The \\(hh\\) Slavnov--Taylor diagnostic remains unvalidated}",
    "\\section{The \\texorpdfstring{\\(hh\\)}{hh} Slavnov--Taylor row: v4 diagnostic, diagnosis, and constant-profile closure}")
rep("\\subsection{The supplied attempted row}", "\\subsection{The supplied attempted row (v4, historical)}")
rep("""The code, complete arrays, and scan log are not supplied here.
Consequently these are historical diagnostic reports, not new
executions.""", """In v5 the code, arrays, and scan log were unavailable.
v6 archives them (\\loc{code/st_test_const.py}, \\loc{code/st_scan.py},
\\loc{logs/v4/st_*.json}) and diagnoses the failure in
Section~\\ref{sec:STdiag}.""")
rep("\\begin{proposition}[No regularity verdict follows from this test]",
    "\\begin{proposition}[No regularity verdict follows from the v4 test]")
between("The correct ending is \\(\\UNVALIDATED\\), not ``cone anomaly found''", "%======================================================================\n\\section{What constant-profile data cannot determine}",
        F('st.tex') + "\n" + F('structures.tex') + "\n")
# ---------- missing section
between("The single computed scalar combination is the longitudinal", "\\subsection{Joint-apex condition \\(\\Jcond\\)}", F('missing_scalar.tex') + "\n")
between("It is not an unconditional proof of \\(\\Jcond\\) for all graphs", "\\subsection{Regularity at special cone openings}", F('missing_J.tex') + "\n")
between("\\subsection{Evanescent data and finite linear certificates}", "%======================================================================\n\\section{Companion comparisons", F('missing_ev.tex') + "\n")
# ---------- repro
rep("\\subsection{Additional proof-level corrections in this revision}", "\\subsection{Proof-level corrections made in v5 (retained)}")
rep("""\\item The full \\(hh\\) tadpole arrays and higher-profile values are
not reconstructed from ``as v3.''""", """\\item The full \\(hh\\) tadpole arrays and higher-profile values are
not reconstructed from ``as v3'' (v6: now executed and printed).""")
rep("""The registry log distinguishes the oct18c report of zero
new identifiers from the later oct18d report of two.
No new registry search is asserted by this revision.""", """The registry log distinguishes the oct18c report of zero
new identifiers from the later oct18d report of two.
v6 rechecked it: 251 identifiers, unchanged.""")
between("\\subsection{Historical artifact inventory}", "%======================================================================\n\\section{Ledger and release}", F('repro.tex') + "\n" + F('response.tex') + "\n")
# ---------- ledger
between("\\begingroup\n\\small\n\\begin{longtable}{@{}L{.57\\linewidth}L{.36\\linewidth}@{}}", "%======================================================================\n\\appendix", F('ledger.tex') + "\n")
# ---------- declarations
between("\\paragraph{Historical execution records.}", "\\paragraph{Submission obligation.}", F('decl_exec.tex') + "\n")
rep("""Direct retrieval of the consulted companion browse endpoints was
unavailable through the research interface used for this revision.
No inaccessible source is claimed to have been read in full.""",
"""Companion manuscripts were not re-read for v6; their citations
carry the mark \\(\\dagger\\).
No inaccessible source is claimed to have been read in full.""")
rep("""The present conditional theorem must not be relabeled an
independently reproduced complete computation.""", """The present conditional theorem must not be relabeled an
independently reproduced complete computation; \\textsc{[exec]} means
reproducible on archived inputs, not independently reviewed.""")
# ---------- artifact appendix before bibliography
s = s.replace("%======================================================================\n\\begin{thebibliography}{99}",
              "%%ARTIFACT_APPENDIX%%\n%======================================================================\n\\begin{thebibliography}{99}")
# ---------- bibliography
rep("%======================================================================\n\\begin{thebibliography}{99}", "%======================================================================\n" + F('bib_legend.tex') + "\\begin{thebibliography}{99}")
s = s.replace('\\textsc{[exec]}', '\\textsf{[exec]}')
marks = {'CheungConeV4': '*', 'CheungP': '*', 'CheungQ': '*', 'CheungR': '\\dagger',
         'Fursaev1994': '\\ddagger', 'FursaevMiele1997': '\\ddagger', 'Vassilevich': '\\ddagger',
         'DLMF': '\\ddagger', 'DerezinskiRichard': '\\ddagger', 'KayStuder': '\\dagger', 'Stockinger': '\\ddagger',
         'HSR': '\\ddagger', 'NielsenAverage': '\\ddagger', 'ReebWolf': '\\ddagger'}
import re
for key in re.findall(r'\\bibitem\{(\w+)\}', s):
    m = marks.get(key, '\\dagger')
    s = s.replace('\\bibitem{%s}\n' % key, '\\bibitem{%s}\n\\(^{%s}\\)\\ ' % (key, m), 1)
rep("""Immediate source of the retained coefficient catalogue and historical
execution reports. Its unavailable code and logs were not rerun here.""",
"""Read in full. Its code and logs are now archived and audited
(Appendix~\\ref{app:artifacts}).""")
rep("""The Q02 D05a symmetry-factor comparison and Q11 scope are retained
as supplied; complete graph artifacts are not included here.""",
"""v6 reads the regenerated Q02 graph record
\\loc{xviq_regen/Q02_bulk_graphs.json} in full and the
read-only certificate \\loc{provenance/XVI-P/certificates/P18_D11.json};
the Q11 scope is retained as supplied.""")
rep("""The later excerpt is a comparison, not a silent contract update.""",
"""The later excerpt is a comparison, not a silent contract update.
Files read in full for v6 (read-only copies, digests equal to the
originals): \\loc{code/p5_entry/amplitude_rules.py},
\\loc{feynman.py}, \\loc{dred.py}.""")
rep("""Complete source version and full cryptographic manifest were not
supplied for independent authentication.""", """Not read for v6; only its full tree digest is recorded
(unchanged before/after).""")
rep("""Chapter 10, especially Sections 10.29, 10.32, and 10.43.""",
    """Chapter 10, especially Sections 10.29, 10.32, and 10.43
(10.43.22 confirmed online for v6).""")
s = s.replace("\\bibitem{CheungP}", """\\bibitem{CheungConeV5}
\\(^{*}\\)\\ N.~Cheung,
\\emph{Scoped O.1 on the Cone, v5: Spectral Apex Reduction,
Constant-Profile Pole Records, and Ward-Identity Boundaries},
18 October 2026. Source \\loc{XVI-O1-CONE-v5.tex}
(SHA-256 \\loc{e00e49f5...a6985b}, full digest in
Appendix~\\ref{app:artifacts}), read in full; the base of this revision.

\\bibitem{CheungP}""", 1)
s = s.replace("\\end{thebibliography}", """\\bibitem{Kabat}
\\(^{\\ddagger}\\)\\ D.~Kabat,
``Black hole entropy and entropy of entanglement,''
\\emph{Nuclear Physics B} \\textbf{453} (1995), 281--299.
DOI: \\nolinkurl{10.1016/0550-3213(95)00443-V}.
arXiv:\\nolinkurl{hep-th/9503016}.
Spin-one horizon contact term; structural analogue only.

\\end{thebibliography}""")
open(R + 'v6build/XVI-O1-CONE-v6.pre.tex', 'w').write(s)
print('assembled', len(s.splitlines()))
