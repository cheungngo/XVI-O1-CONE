#!/bin/bash
# v2 apex batch: resonant set {1/3,1/2,2/3}, cheap extras 1/4, 2/5, generic controls, both branches, both primes; cap T fix
cd /workspace/XVI-O1-CONE
mkdir -p logs/v2apex
for a in 1/3 1/4 2/5 1/2 2/3 3/10 7071/10000; do for b in CR F; do for p in 0 1; do
 echo "== $a $b $p"; timeout 600 python3 code/apex_run.py $a $b $p 2>&1 | grep -v '^ ' | head -5
done; done; done
echo BATCH_DONE
