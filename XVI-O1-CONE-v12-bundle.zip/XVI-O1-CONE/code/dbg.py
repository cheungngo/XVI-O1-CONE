import sys, random
from fractions import Fraction as Fr
sys.path.insert(0,'.')
import apex_jets as AJ
from apex_jets import *
S=Setup(Fr(7071,10000),'CR'); random.seed(5); P=AJ.P
def rq(): return [random.randrange(1, 1000), random.randrange(1, 1000)]
hh=candidates(S,'h','h',4); hc=candidates(S,'h','c',5); kc=candidates(S,'K','c',4)
sm=[(rand_cfg(S,'h',6),rand_cfg(S,'c',6),rq()) for _ in range(80)]
Gb=[[eval_sym(c,a,b,q,False) for (a,b,q) in sm] for c in hc]
r0,_=rank_and_basis(Gb); print('hc basis rank',r0,len(hc))
bad=0
for i,c in enumerate(hh):
    img=[2*eval_sym(c,a,Ops(S,q).K2(b),q,True)%P for (a,b,q) in sm]
    r1,_=rank_and_basis(Gb+[img])
    if r1>r0:
        bad+=1
        if bad<4: print('HH cand not in span:',c[0],c[1],c[4],c[5])
print('HH bad',bad,'of',len(hh))
bad=0
for c in kc:
    img=[eval_sym(c,Ops(S,negq(q)).E(a),b,q,False) for (a,b,q) in sm]
    r1,_=rank_and_basis(Gb+[img])
    if r1>r0:
        bad+=1
        if bad<4: print('CK cand not in span:',c[0],c[1],c[4],c[5])
print('CK bad',bad,'of',len(kc))
