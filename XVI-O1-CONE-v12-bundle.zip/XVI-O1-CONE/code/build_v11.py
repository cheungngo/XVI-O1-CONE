#!/usr/bin/env python3
"""Build XVI-O1-CONE-v11.tex from the read-only v10 source plus asserted replacements/insertions (anchors occur once)."""
import json, hashlib
from fractions import Fraction
import mpmath as mp
B = '/workspace/XVI-O1-CONE'
v10 = open(f'{B}/XVI-O1-CONE-v10.tex', encoding='utf-8').read()
assert hashlib.sha256(v10.encode()).hexdigest().startswith('d21c8d84'), 'v10 bytes changed'
S = lambda n: open(f'{B}/v11src/{n}', encoding='utf-8').read()
s = v10
def rep(a, b, count=1):
    global s
    n = s.count(a); assert n == count, (n, a[:120]); s = s.replace(a, b)
def between(a, b, new):
    global s
    assert s.count(a) == 1, a[:80]; i = s.index(a); j = s.index(b, i) + len(b); s = s[:i] + new + s[j:]
rep('pdftitle={Scoped O.1 on the Prescribed Cone, v10},', 'pdftitle={Scoped O.1 on the Prescribed Cone, v11},')
rep(r'''\large Version 10; revision of \texttt{XVI-O1-CONE-v9.tex}:\\
closed \(\Delta J\), derived ghost normalizations, chamber ranks, and transverse jets}''',
    r'''\large Version 11; revision of \texttt{XVI-O1-CONE-v10.tex}:\\
derived F mode, machine-checked degree bound, corrected mixed traces, and the D04 mode sum}''')
rep(r'\date{18 October 2026}', r'\date{19 October 2026}')
between(r'\begin{abstract}', r'\end{abstract}', S('abstract.tex').strip())
sec = S('sec_v11.tex')
M = json.load(open(f'{B}/logs/v11/M10/m10.json')); PS = json.load(open(f'{B}/logs/v11/M10/m10_pslq.json'))
def ee(x):
    v = float(x)
    if v == 0: return '0'
    m, ex = ('%.1e' % v).split('e'); return r'\(%s\times10^{%d}\)' % (m, int(ex))
rows = []; errs = []
for tag in sorted(M, key=lambda t: (Fraction(t.split('|')[0]), t)):
    al, P, reg = tag.split('|'); v = M[tag]; regt = {'Rk': r'R_k', 'Rh': r'R_h'}[reg]
    if 'M10_FP' not in v:
        rows.append(r'\(%s\) & %s, \(%s\) & \emph{missing (not run)} & -- & --\\' % (al, P, regt)); continue
    errs.append(float(v['err_est']) / max(abs(float(v['M10_FP'])), 1e-300) if Fraction(al) != 1 or P == 'P0' else None)
    rows.append(r'\(%s\) & %s, \(%s\) & \(%s\) & %s & \(%s\)\\' % (al, P, regt, v['M10_FP'][:12], ee(v['err_est']), mp.nstr(mp.mpf(v['pole_coeff_1/eps']), 6)))
rel = [e for e in errs if e is not None]
digits = '%d--%d' % (int(-mp.log10(max(rel))), int(-mp.log10(min(rel)))) if rel else '0'
sec = sec.replace('@@M10TAB@@', '\n'.join(rows)).replace('@@M10DIGITS@@', str(digits))
sec = sec.replace('@@CHK_RK@@', ee(abs(float(M['1|P1|Rk']['M10_FP']) + 19/180) + float(M['1|P1|Rk']['err_est'])))
sec = sec.replace('@@CHK_RH@@', ee(abs(float(M['1|P1|Rh']['M10_FP']) - 11/180) + float(M['1|P1|Rh']['err_est'])))
triv = [t for t, r in PS.items() if isinstance(r, dict) and r['relation'] is not None and r['relation'][0] == 0]
withM = [t for t, r in PS.items() if isinstance(r, dict) and r['relation'] is not None and r['relation'][0] != 0]
none = [t for t, r in PS.items() if isinstance(r, dict) and r['relation'] is None]
fmt = lambda L: ', '.join(t.replace('|', ' ') for t in L)
txt = []
if triv: txt.append('relations among the basis elements alone (coefficient of \\(M_{10}\\) zero; e.g.\\ \\(1/\\alpha^2=2/\\alpha\\) at \\(\\alpha=\\tfrac12\\)) for ' + fmt(triv) + '; these are basis degeneracies')
if withM: txt.append('relations involving \\(M_{10}\\) for ' + fmt(withM) + '. With ten basis elements and a tolerance of about \\(10^{-8}\\), small-coefficient relations exist generically, so these are \\emph{not} credible and are not claimed')
if none: txt.append('no relation for ' + fmt(none))
sec = sec.replace('@@PSLQ@@', '; '.join(txt) + '. No closed form is claimed.')
sec = sec.replace('@@PHI0@@', json.load(open(f'{B}/logs/v11/M10/phi_corrected.json'))['phi(0)=F(1,0)'][:22])
SA = json.load(open(f'{B}/logs/v11/M10/m10_sanity.json'))
sec = sec.replace('@@SANITY@@', ('true for all %d entries' % SA['n_ok']) if SA['n_bad'] == 0 else ('true for %d of %d entries; the exception%s %s (\\loc{logs/v11/M10/m10_sanity.json}) %s' % (SA['n_ok'], SA['n_ok'] + SA['n_bad'], '' if SA['n_bad'] == 1 else 's', ', '.join('\\(F(%s,%s)\\)' % (b[0], b[1]) for b in SA['bad']), 'has both endpoint values zero, so its negative value is no contradiction' if [b[:2] for b in SA['bad']] == [['1', '0']] else 'are unexplained')))
sec = sec.replace('@@M10TEXT@@', open(f'{B}/logs/v11/M10/m10_text.tex').read().strip())
assert '@@' not in sec, sec[sec.index('@@')-50:sec.index('@@')+50]
rep(r'\section{Open obligations and the exact release}', sec + '\n' + r'\section{Open obligations and the exact release}')
between(r'''\begingroup\small
\begin{longtable}{@{}L{.22\linewidth}L{.40\linewidth}L{.31\linewidth}@{}}
\caption{Open obligations after v10.''', r'''\end{longtable}
\endgroup''', S('opentable.tex').strip())
rep(r'\begin{theorem}[Scoped v10 release]', r'\begin{theorem}[Scoped v11 release]')
rep(r'''\item \emph{(v10, conditional on (D).)} The rank is constant inside
chambers: 26 on \(N=34\) chambers and 29 on F above \(\tfrac12\)
(Theorem~\ref{thm:v10chamber}).''', r'''\item \emph{(v10; unconditional since v11.)} The rank is constant inside
chambers: 26 on \(N=34\) chambers and 29 on F above \(\tfrac12\)
(Theorem~\ref{thm:v10chamber}; (D) is Proposition~\ref{prop:v11D}).''')
rep(r'''\ref{sec:v10vector}. The D04 part, the jet Ward combinations and
\(e_5,e_6\) remain open.
\end{enumerate}''', r'''\ref{sec:v10vector}. The D04 part, the jet Ward combinations and
\(e_5,e_6\) remain open.

\item \emph{(v11, executed.)} \(I_{\rm F}\) is derived for \(0<\mu<2\)
(Theorem~\ref{thm:v11IF}), and \(\Delta J=-(\mu-1)B/W_1\).

\item \emph{(v11, executed.)} The degree bound (D) is machine-checked
(Proposition~\ref{prop:v11D}). The chamber-rank certificate is
\CPIR{} in the scope stated in Section~\ref{sec:v11D}, and the v8
four-point certificate remains \CPIR{} in its v8 scope.

\item \emph{(v11, partial.)} The mixed-trace evaluator is corrected
(Section~\ref{sec:v11bug}). \(M_{10}\) is evaluated in declared
pairings and regulators (Table~\ref{tab:v11M10}), so D04 is
scheme dependent. The weight \(\pm1,\pm2\) traces, the
dictionary, the 20 jet Ward combinations, the projections,
\(e_5,e_6\) and the transverse loop momentum remain open
(Section~\ref{sec:v11open}).
\end{enumerate}''')
rep(r'''Items (xv)--(xviii) are Corollary~\ref{cor:v10dJ},''', r'''Items (xix)--(xxi) are Theorem~\ref{thm:v11IF},
Proposition~\ref{prop:v11D} and Section~\ref{sec:v11M10}.
Items (xv)--(xviii) are Corollary~\ref{cor:v10dJ},''')
rep(r'''finite parts. No scope is labelled
\texttt{CLOSED\_PENDING\_INDEPENDENT\_REVIEW}. No independent
review was started; nothing was pushed, posted or written to the
site.}''', r'''finite parts. No scope is labelled
\texttt{CLOSED\_PENDING\_INDEPENDENT\_REVIEW}. No independent
review was started; nothing was pushed, posted or written to the
site.

v11 adds the items of Section~\ref{sec:whatv11}, each hashed in
Appendix~\ref{app:v11artifacts}, and withdraws the v10 \(\varphi\)
values (Section~\ref{sec:v11changes}). Two scopes carry
\texttt{CLOSED\_PENDING\_INDEPENDENT\_REVIEW}: the v8 four-point
rank certificate and the chamber ranks of Section~\ref{sec:v11D}.
Nothing else does. v11 claims no derived pairing or regulator for
D04, no weight-\(\pm1\) log coefficient, no jet Ward residual, and
no value of \(e_5,e_6\). No independent review was started; nothing
was pushed, posted or written to the site.}''')
rep(r'''v10: programs in \loc{code/v10/}, logs in \loc{logs/v10/}, hashes in
Appendix~\ref{app:v10artifacts}.''', r'''v10: programs in \loc{code/v10/}, logs in \loc{logs/v10/}, hashes in
Appendix~\ref{app:v10artifacts}.
v11: programs in \loc{code/v11/}, logs in \loc{logs/v11/}, hashes in
Appendix~\ref{app:v11artifacts}.''')
rep(r'''v10 was compiled with
\begin{verbatim}
pdflatex -halt-on-error XVI-O1-CONE-v10.tex
pdflatex -halt-on-error XVI-O1-CONE-v10.tex
\end{verbatim}''', r'''v11 was compiled with
\begin{verbatim}
pdflatex -halt-on-error XVI-O1-CONE-v11.tex   # repeated until stable
\end{verbatim}''')
rep(r'''No independent review of v8, v9 or v10 has taken place;''', r'''No independent review of v8, v9, v10 or v11 has taken place;''')
rep(r'\section{Source, version, and compilation declarations}', S('artifacts.tex') + '\n' + r'\section{Source, version, and compilation declarations}')
rep(r'''\item[] \textit{Marks (v10):} * read in full; \ddag{} confirmed online
(registry fetches of 18 October 2026,''', r'''\item[] \textit{Marks (v11):} * read in full; \ddag{} confirmed online
(registry fetches of 18 October 2026, re-checked 19 October 2026,''')
rep(r'\bibitem{CheungConeV8}', S('bib_v11.tex').strip() + '\n\n' + r'\bibitem{CheungConeV8}')
open(f'{B}/XVI-O1-CONE-v11.tex', 'w', encoding='utf-8').write(s)
print('written', len(s.splitlines()), 'lines; M10 digits', digits)
