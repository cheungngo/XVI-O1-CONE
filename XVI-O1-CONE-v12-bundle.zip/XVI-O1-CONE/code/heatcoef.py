# conical heat coefficient per label a(b) = (1/12)(1/al-al) - b(1-b)/(2 al), from r^2 R_b(x,x) (locality.py, verified 1e-14)
# Compare with Kabat (vector) and Fursaev-Miele eq.(3.47) at d=4 (spin 2), in units where scalar a0 = a(0).
from fractions import Fraction as F
import json
def a(b,al): return F(1,12)*(1/al-al) - b*(1-b)/(2*al)
out=[]
for al in [F(3,10),F(41,100),F(1,2),F(309,500),F(2,3),F(7071,10000),F(4,5),F(8501,10000)]:
    a0=a(0,al)
    vec=2*a0+a(al,al)+a(1-al,al)                  # Friedrichs vector (all alpha: nu1 channel only affects alpha>1/2 E0-vec, not used)
    kab=4*a0-(1-al)
    b2 = 2*al if al<=F(1,2) else 2*al-1           # Friedrichs label of helicity +2 jumps at alpha=1/2
    b2m= 1-2*al if al<=F(1,2) else 2-2*al
    tenF=4*a0+2*(a(al,al)+a(1-al,al))+a(b2,al)+a(b2m,al)
    tenCR=4*a0+2*(a(al,al)+a(1-al,al))+a(2*al,al)+a(1-2*al,al)
    fm=10*a0+6*(al-1)+2
    out.append({'alpha':str(al),'vec_minus_Kabat':str(vec-kab),'tenCR_minus_FM':str(tenCR-fm),'tenF_minus_FM':str(tenF-fm)})
    print(out[-1])
json.dump(out,open('logs/heatcoef.json','w'),indent=1)
