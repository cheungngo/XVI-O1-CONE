#!/usr/bin/env python3
"""Build XVI-O1-CONE-v8.tex from the read-only v7 source plus asserted replacements/insertions.
Every anchor must occur exactly once; v7 is never modified."""
import json, os, re, hashlib, glob
from fractions import Fraction
B = '/workspace/XVI-O1-CONE'
v7 = open(f'{B}/XVI-O1-CONE-v7.tex', encoding='utf-8').read()
assert hashlib.sha256(v7.encode()).hexdigest().startswith('d0ba7b9c'), 'v7 bytes changed'
S = lambda n: open(f'{B}/v8src/{n}', encoding='utf-8').read()
s = v7

def rep(a, b, count=1):
    global s
    n = s.count(a)
    assert n == count, (n, a[:120])
    s = s.replace(a, b)

def between(a, b, new):
    """replace from start of anchor a through end of the first b after it"""
    global s
    i = s.index(a); assert s.count(a) == 1, a[:80]
    j = s.index(b, i) + len(b)
    s = s[:i] + new + s[j:]

# ---------- preamble, title ----------
rep('pdftitle={Scoped O.1 on the Prescribed Cone, v7},', 'pdftitle={Scoped O.1 on the Prescribed Cone, v8},')
rep(r'\newcommand{\SUPPLIED}{\textsf{SUPPLIED}}',
    r'\newcommand{\SUPPLIED}{\textsf{SUPPLIED}}' + '\n' + r'\newcommand{\PARTIAL}{\textsf{PARTIAL}}' + '\n' +
    r'\newcommand{\CPIR}{\textsf{CLOSED\_PENDING\_}\allowbreak\textsf{INDEPENDENT\_REVIEW}}')
rep(r'''\large Version 7: proof-level consolidation and a source-audited
computational appendix}''',
    r'''\large Version 8; revision of \texttt{XVI-O1-CONE-v7.tex}:\\
executed replay, exact span certificates, and constant-profile maps}''')
between(r'\begin{abstract}', r'\end{abstract}', S('abstract.tex').strip())

# ---------- evidence classes ----------
rep(r'''It is supplied as source, not as an executed certificate.
''', r'''It is supplied as source, not as an executed certificate.
In v8 it was extracted unchanged and executed
(Section~\ref{sec:v8response}).

\item[Executed in v8.]
A statement whose evidence is a v8 run on the I-B audit box:
a named script under \loc{code/v8/}, its return code, and a log
under \loc{logs/v8/}, all hashed in Appendix~\ref{app:v8artifacts}.
Exact runs use \(\mathbb Q(\ii)\) arithmetic; numerical runs are
labelled corroboration. An executed statement about the declared
catalogue remains conditional on Assumption~\ref{ass:reduction}.
''')
rep(r'''The original coefficient values are retained. No new complete
cone graph value is claimed.
''', r'''The original coefficient values are retained. No new complete
cone graph value is claimed.
''' + S('whatv8.tex'))
rep(r'''independently re-established in this revision.
In all cases,''', r'''independently re-established from the v7 material alone.
v8 replays the frozen engine (read-only copies, tree hashes in
Section~\ref{sec:v8hash}) but does not certify completeness.
In all cases,''')

# ---------- integrity: response + hashes ----------
rep(r'\subsection{The coarse channel marker needs its own check}',
    S('response.tex') + '\n' + r'\subsection{The coarse channel marker needs its own check}')
H = json.load(open(f'{B}/logs/v8/tree_hashes_v8.json'))
def split(h): return r'\texttt{%s}\\' % h[:32] + '\n' + r'&&\texttt{%s}\\' % h[32:]
rows = '\n'.join(r'%s & before/after & %s' % (k, split(H['shell'][k])) + '\n' for k in ['XVI-P', 'XVI-Q', 'XVI-R'])
hashsec = r'''
\subsection{v8: recomputed frozen-tree digests}
\label{sec:v8hash}

The historical shell serialization was recomputed in v8
(locale \loc{C.UTF-8}) on the read-only trees, both before
any v8 run and after the last run:
\begin{center}
\scriptsize
\begin{tabular}{@{}lll@{}}
\toprule
Tree & When & SHA-256 (shell serialization)\\
\midrule
''' + rows + r'''\bottomrule
\end{tabular}
\end{center}
They equal the reported v6 labels above, before and after
(\loc{logs/v8/tree_hashes_v8.json}). The v7 Python manifest
serialization gives different digests, as v7 predicted:
''' + ', '.join(r'%s \texttt{%s}\ldots\texttt{%s} (%d files)' % (k, H['py'][k][0][:8], H['py'][k][0][-5:], H['py'][k][1]) for k in ['XVI-P', 'XVI-Q', 'XVI-R']) + r'''.
No XVI-P, XVI-Q or XVI-R file was edited.

'''
rep(r'\subsection{Computational scope of the embedded program}', hashsec + r'\subsection{Computational scope of the embedded program}')

# ---------- sec:missing pointers ----------
rep(r'''language of the tensor-core comparison computes D04.''', r'''language of the tensor-core comparison computes D04.
v8 status: still \OPEN; see Section~\ref{sec:v8map} and
Lemma~\ref{lem:v8duhamel} for the ingredients supplied.''')
rep(r'''coefficients are not supplied. Those coefficients remain open.''',
    r'''coefficients are not supplied. Those coefficients remain open.
v8 computes them under a declared slice-DRED prescription
(Section~\ref{sec:v8evan}); that is \CONDITIONAL, not an identification
with the frozen export.''')
rep(r'''That map and the unseen components are open, not zero.''',
    r'''That map and the unseen components are open, not zero.
v8 supplies the six constant-profile coordinates of the \(hh\) block
exactly (Section~\ref{sec:v8map}); twelve remain open.''')
rep(r'''the full matrix, its coefficient field, column completeness,
and the appropriate relation quotient.''', r'''the full matrix, its coefficient field, column completeness,
and the appropriate relation quotient.
v8 supplies these for the declared inventory at named angles and
branches (Section~\ref{sec:v8cert}).''')

# ---------- new results sections ----------
def F(x): return str(x)
certs = {}
for t in ['3_10_CR', '3_10_F', '7071_10000_CR', '7071_10000_F']:
    p = f'{B}/logs/v8/cert/apex_cert_{t}.json'
    if os.path.exists(p): certs[t] = json.load(open(p))
def lab(t):
    a, b = t.rsplit('_', 1); return r'\((%s,\%s)\)' % (a.replace('_', '/').replace('7071/10000', r'7071/10^4'), 'Fr' if b == 'F' else 'CR')
trows = []
for t, d in certs.items():
    g = d['gh0_dims']; st = d['ST']
    trows.append(r'%s & %d=%d+%d+%d+%d & %d & %d & %d & %s & %d & %d & %d & %d & %.0f\\' % (
        lab(t), d['N_total'], g['HH'], g['CB'], g['CK'], g['PP'], st['n_rows_complete'], st['rank'], st['Z_dim'],
        'yes' if d['B_subset_Z'] else 'NO', d['exact_dim_B'], d['H0_dim'], d['Ward_constrained_count'],
        d['Ward_combinations_supported_on_K'], d['seconds']))
missing = [t for t in ['3_10_CR', '3_10_F', '7071_10000_CR', '7071_10000_F'] if t not in certs]
hist = []
for f in sorted(glob.glob(f'{B}/logs/apex_*_p0.json')):
    d = json.load(open(f)); m = re.search(r'apex_(\d+)_(\d+)_(CR|F)_p0', f)
    a = '%s/%s' % (m.group(1), m.group(2)); g = d['gh0_candidate_dims']
    hist.append((Fraction(a), m.group(3), a, d['N_total'], d['Z_dim'], d['exact_dim_B'], d['H0_dim'], g))
hist.sort()
hrows = '\n'.join(r'%s & %s & %d & %d & %d & %d & %d\\' % (a, b, N, Z, Bd, H0, N - Z) for (_, b, a, N, Z, Bd, H0, g) in hist)
cert = r'''

%======================================================================
\section{v8: an exact complete span certificate}
\label{sec:v8cert}
%======================================================================

\subsection{What is certified}

The apex functionals of the historical inventory
(\loc{apex_jets.py}) are bilinear in finitely many jet atoms and
polynomial in the external momentum. v8 ports them mechanically to
exact Gaussian-rational arithmetic (\loc{code/v8/apex_exact.py};
the port reproduces every historical modular count) and evaluates
them on \emph{all} relevant unit atom pairs over a complete
\(6\times6\) momentum grid, enough to determine every polynomial of
the occurring degree. Therefore the evaluated columns are complete,
and the row spaces computed are the exact row spaces.

\begin{theorem}[Exact span certificate; executed]
\label{thm:v8cert}
For each \((\alpha,\text{branch})\) in Table~\ref{tab:v8cert}, over
\(\mathbb Q(\ii)\) and for the functionals as implemented in the
declared inventory:
the gauge-invariant candidate ranks, the ST rank, \(\dim Z\),
\(\dim B\), \(B\subset Z\) and \(\dim H^0=\dim Z-\dim B\) are as
displayed. Each rank is certified by a nonzero minor (hash and
indices in \loc{apex_cert_*.json}) and each kernel by verification
on every complete column.
\end{theorem}

\begin{center}
\scriptsize
\begin{longtable}{@{}lllllllllll@{}}
\caption{Complete exact certificates (v8).}\label{tab:v8cert}\\
\toprule
\((\alpha,\text{br})\) & \(N\) & ST rows & ST rank & \(\dim Z\) & \(B\subset Z\) & \(\dim B\) & \(\dim H^0\) & Ward & on \(K\) & s\\
\midrule
''' + '\n'.join(trows) + r'''
\bottomrule
\end{longtable}
\end{center}
''' + (('\\noindent Not completed in v8: ' + ', '.join(lab(t) for t in missing) + '. These are not inferred.\n') if missing else '') + r'''
Here ``Ward'' is the number \(N-\dim Z\) of Ward-constrained
combinations; at the 34-candidate points this is the v6 count
\(26\), now exact. The ghost-number \(+1\) cohomology vanishes at
the sampled exact point \((7071/10^4,\CR)\) (26/26 images closed;
\(H^1=0\)).

\subsection{The count 34 is angle and branch dependent}

The historical modular inventory, which the exact port reproduces
wherever both exist, gives:
\begin{center}
\scriptsize
\begin{tabular}{@{}lllllll@{}}
\toprule
\(\alpha\) & branch & \(N\) & \(\dim Z\) & \(\dim B\) & \(\dim H^0\) & \(N-\dim Z\)\\
\midrule
''' + hrows + r'''
\bottomrule
\end{tabular}
\end{center}
Thus \(N=34\), \(\dim Z=8\), \(N-\dim Z=26\) hold on CR at every
tested non-resonant angle and on F for \(\alpha<1/2\); F at
\(\alpha>1/2\) gives \(38\) with \(\dim H^0=3\) (an additional
F-branch singular exponent enters), and \(\alpha=1/2\), \(2/3\) are
resonant. The ``34-dimensional basis'' and ``26 Ward combinations''
of v6/v7 are therefore qualified statements; only the rows of
Table~\ref{tab:v8cert} are exact.

\subsection{Scope of the certificate}

The certificate concerns the declared inventory and its functionals,
at the listed rational angles. It does not prove a statement for
general \(\alpha\) (two points do not certify a rational function),
does not identify the inventory with the complete interacting basis,
and does not evaluate any graph. Within that scope it is
\CPIR.
'''
mapsec = S('sec_map.tex')
ev = json.load(open(f'{B}/logs/v8/cert/exact_values.json'))
if '7071_10000_F' in ev:
    e = ev['7071_10000_F']['solution']
    # e1, e3, e2+2e5, e4+e5 from parametric solution
    import sympy as sp
    e5 = sp.Symbol('e5'); es = [sp.sympify(x) for x in e]
    row = r'\((7071/10^4,\Fr)\) & \(%s\) & \(%s\) & \(%s\) & \(%s\)\\' % tuple(str(sp.simplify(v)) for v in (es[0], es[2], es[1] + 2*es[4], es[3] + es[4]))
    mapsec = mapsec.replace('%F7071ROW', row)
rep(r'''%======================================================================
\section{Open obligations and the exact release}''', cert + mapsec + S('sec_mixed.tex') + S('sec_evan.tex') + '\n' + r'''%======================================================================
\section{Open obligations and the exact release}''')

# ---------- open table ----------
between(r'''\begin{longtable}{@{}L{.27\linewidth}L{.31\linewidth}L{.35\linewidth}@{}}
\caption{The unchanged substantive open list''', r'\end{longtable}', S('opentable.tex').strip())
rep(r'\begin{theorem}[Scoped v7 release]', r'\begin{theorem}[Scoped v8 release]')
rep(r'''\item None of the obligations in Table~\ref{tab:open} is set to
zero or discharged by the companion comparisons.
\end{enumerate}''', r'''\item None of the obligations in Table~\ref{tab:open} is set to
zero or discharged by the companion comparisons.

\item \emph{(v8, executed.)} Theorem~\ref{thm:v8cert} holds on its
stated finite scope; on that scope the status is \CPIR.

\item \emph{(v8, executed, conditional on
Assumption~\ref{ass:reduction}.)} The \(hh\) catalogue sum satisfies
the two \(hh\)-supported Ward combinations exactly
(Proposition~\ref{prop:v8hhward}); four of the six exact values are
fixed in the stated basis; six of the eighteen \(hh\) engine
coordinates are mapped.

\item \emph{(v8.)} The v6 \(hh\) branch difference is conditional on
the hidden D01 mixed-channel term of Proposition~\ref{prop:v8hidden};
the evanescent coefficients of Section~\ref{sec:v8evan} are
conditional on the declared prescription.
\end{enumerate}''')
rep(r'''The complete O.1 requirements are not consequences of these
restricted statements.''', r'''Items (ix)--(xi) are Theorem~\ref{thm:v8cert},
Propositions~\ref{prop:v8hhward} and \ref{prop:v8hidden}, and the
executed records of Sections~\ref{sec:v8map} and \ref{sec:v8evan}.

The complete O.1 requirements are not consequences of these
restricted statements.''')
between(r'\scopebox{Submission boundary}{%', r'''relabelled unconditional graph theorems.}''', S('boundary.tex').strip())

# ---------- appendix ----------
rep(r'''A successful run of the embedded program would not, by itself,
provide items 3--5 or 7.
''', r'''A successful run of the embedded program would not, by itself,
provide items 3--5 or 7.
v8 ran it (Section~\ref{sec:v8response}) and separately supplies
item 7 on a finite scope (Section~\ref{sec:v8cert}); items 3--5 are
not supplied.
''' + open(f'{B}/v8src/artifacts.tex', encoding='utf-8').read())

# ---------- declarations ----------
rep(r'''No inaccessible frozen engine file is described as newly read
or run.''', r'''In v8 the frozen XVI-P/XVI-Q engine files were read and replayed
from read-only copies; nothing in those trees was edited
(Section~\ref{sec:v8hash}). v7 was read in full.''')
between(r'\paragraph{Code status.}', r'or machine verification is asserted in this document.', r'''\paragraph{Code status.}
v7: the embedded program is newly consolidated source.
v8: it was extracted unchanged and executed, together with the
v8 programs in \loc{code/v8/}; return codes, logs and SHA-256 values
are in Appendix~\ref{app:v8artifacts}. Software: Python~3 with SymPy
(versions in \loc{logs/v8/env.json}). No proof-assistant check is
asserted.''')
between(r'''This is a single-file pdfLaTeX source with an internal''', r'''missing glyphs, and overfull boxes before submission.''', r'''This is a single-file pdfLaTeX source with an internal
bibliography and inline listings. It requires no external figure,
bibliography database, code file, or shell escape for typesetting.
v8 was compiled with
\begin{verbatim}
pdflatex -halt-on-error XVI-O1-CONE-v8.tex
pdflatex -halt-on-error XVI-O1-CONE-v8.tex
\end{verbatim}
and the final log was checked for unresolved references and
citations.''')
rep(r'''Final submission requires the author's approval''', r'''No independent review of v8 has taken place; nothing was pushed
or posted. Final submission requires the author's approval''')

# ---------- bibliography ----------
rep(r'''\begin{thebibliography}{99}
\addcontentsline{toc}{section}{References}
%======================================================================
''', r'''\begin{thebibliography}{99}
\addcontentsline{toc}{section}{References}
%======================================================================
\item[] \textit{Marks (v8):} * read in full; \ddag{} confirmed online
(registry fetch of 18 October 2026, \url{https://enter.grok.me/browse});
\dag{} from memory or from a supplied description only.

\bibitem{CheungConeV7}
* N.~Cheung,
\emph{Scoped O.1 on the Prescribed Cone, Version 7},
18 October 2026. Source \loc{XVI-O1-CONE-v7.tex}
(SHA-256 \texttt{d0ba7b9c\ldots5d132}); the base of this revision.

''')
marks = json.load(open(f'{B}/v8src/bibmarks.json'))
for key, mk in marks.items():
    a = r'\bibitem{%s}' % key + '\n'
    rep(a, a + mk + ' ')
rep(r'''No new engine-file inspection is asserted here.''', r'''v8 inspected and replayed named engine files from a read-only copy.''')
open(f'{B}/XVI-O1-CONE-v8.tex', 'w', encoding='utf-8').write(s)
print('written', len(s.splitlines()), 'lines; certs', list(certs), 'missing', missing)
