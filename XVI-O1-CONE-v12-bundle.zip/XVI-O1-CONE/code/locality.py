"""Stage-1 regular-region locality checks (Euclidean cone C_alpha x R^2, I-B-G-S-v2 labels).
(a) coincidence: r^2 R_b(x,x) = (B2(b)/alpha^2 - 1/6)/(8 pi^2), R_b = W_b - W_flat(direct);
(b) smoothness of R_b at the diagonal: direction independence of value and gradient, bounded 2nd differences;
(c) bubble log-coefficient: J(rho)=2 pi^2 rho^4 G(x,x+rho n)^2 -> 1/(8 pi^2) with (J-J_flat)/rho^2 -> R_b(x,x).
Run: python3 locality.py <alpha>   (writes logs/locality_<alpha>.json)"""
import sys, json, mpmath as mp
sys.path.insert(0, '/workspace/XVI-O1-CONE/code')
from tensor import Gb
mp.mp.dps = 40
al = mp.mpf(sys.argv[1])
labels = {'b0': mp.mpf(0), 'b+1': al, 'b-1': 1 - al, 'b+2': 2 * al, 'b-2': 1 - 2 * al}
if al <= mp.mpf(1) / 2:   # curvature-regular = Friedrichs labels (fractional parts) when alpha<=1/2
    labels['b+2'] = 2 * al - mp.floor(2 * al); labels['b-2'] = (1 - 2 * al) - mp.floor(1 - 2 * al)
else:                     # also record the componentwise-Friedrichs label for comparison
    labels['b+2_F'] = 2 * al - 1; labels['b-2_F'] = 2 - 2 * al
r0 = mp.mpf('0.9'); th0 = mp.mpf('0.15')
x = (mp.mpf('0.1'), r0 * mp.cos(th0), r0 * mp.sin(th0), mp.mpf('-0.05'))
def Wf(x, y): return 1 / (4 * mp.pi**2 * sum((a - b)**2 for a, b in zip(x, y)))
def B2(b): return b * b - b + mp.mpf(1) / 6
dirs = [(1, 0, 0, 0), (0, 1, 0, 0), (0, 0, 1, 0), (0, 0, 0, 1), (1, 2, -1, 3), (-2, 1, 3, 1), (1, -1, -1, 2)]
dirs = [tuple(mp.mpf(c) / mp.sqrt(sum(mp.mpf(d)**2 for d in v)) for c in v) for v in dirs]
out = {'alpha': str(al), 'x': [mp.nstr(c, 8) for c in x], 'labels': {}}
for name, b in labels.items():
    R = lambda y: (Gb(b, al, x, y) - Wf(x, y)).real
    pred = (B2(b) / al**2 - mp.mpf(1) / 6) / (8 * mp.pi**2) / r0**2
    rec = {'b': mp.nstr(b, 12), 'pred_R(x,x)': mp.nstr(pred, 15)}
    # (a)+(b): value and directional derivative from symmetric differences at two scales
    vals = []; grads = []
    for n in dirs:
        h = mp.mpf('1e-6')
        yp = tuple(a + h * c for a, c in zip(x, n)); ym = tuple(a - h * c for a, c in zip(x, n))
        Rp, Rm = R(yp), R(ym)
        vals.append((Rp + Rm) / 2); grads.append((Rp - Rm) / (2 * h))
    rec['R0_spread_over_dirs'] = mp.nstr(max(vals) - min(vals), 5)
    rec['R0_relerr_vs_pred'] = mp.nstr(abs(sum(vals) / len(vals) - pred) / abs(pred) if pred != 0 else abs(sum(vals) / len(vals)), 5)
    g = grads[:4]   # axis gradient
    lin = [abs(grads[k] - sum(g[i] * dirs[k][i] for i in range(4))) for k in range(4, len(dirs))]
    rec['grad_linearity_residual_max'] = mp.nstr(max(lin), 5)
    rec['grad_norm'] = mp.nstr(mp.sqrt(sum(v * v for v in g)), 8)
    # (c) bubble log coefficient along the random directions
    J = []
    for rho in [mp.mpf('1e-1'), mp.mpf('1e-2'), mp.mpf('1e-3')]:
        row = []
        for n in dirs[4:]:
            y = tuple(a + rho * c for a, c in zip(x, n))
            G = Gb(b, al, x, y).real; Gf = Wf(x, y)
            Jc = 2 * mp.pi**2 * rho**4 * G * G; Jf = 2 * mp.pi**2 * rho**4 * Gf * Gf
            row.append({'J_flat': mp.nstr(Jf, 12), 'J_cone-1/(8pi^2)': mp.nstr(Jc - 1 / (8 * mp.pi**2), 6),
                        '(Jc-Jf)/rho^2 / R0': mp.nstr((Jc - Jf) / rho**2 / pred, 8) if pred != 0 else mp.nstr((Jc - Jf) / rho**2, 6)})
        J.append({'rho': mp.nstr(rho, 3), 'dirs': row})
    rec['bubble'] = J
    out['labels'][name] = rec
    print(name, rec['R0_relerr_vs_pred'], rec['R0_spread_over_dirs'], rec['grad_linearity_residual_max'], flush=True)
json.dump(out, open('/workspace/XVI-O1-CONE/logs/locality_%s.json' % mp.nstr(al, 6), 'w'), indent=1)
